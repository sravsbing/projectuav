"""Stage 5 experiment plan: which runs exist, and the rules that keep the comparisons fair.

Fairness rules (enforced by `check_plan`, not just documented):
  * every method that is compared within a phase gets the SAME number of trials (equal tuning budget);
  * every trial of every method uses the SAME number of epochs (scratch vs transfer included);
  * selection uses the VALIDATION split only (`train.select_on`); the test split is never opened here;
  * the paper-literal SG-VDNet setting is always one of the SG trials, so it is reported next to the selected one.
Everything produced from this plan is a validation-split plain keypoint error (original pixels, GT-box crops),
NOT the paper's IoP/RMSE (Stage 6) and NOT comparable to the published numbers.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence


@dataclass(frozen=True)
class Trial:
    method: str                    # e.g. "sg_vdnet", "pg_vdnet", "point_net", "sg_ir_transfer"
    name: str                      # unique within the method, e.g. "lr1e-3__literal"
    overrides: Dict[str, object]   # config overrides applied on top of the shared base
    literal: bool = False          # True = paper-literal loss setting (no warm-up, no loss rescale)
    tags: Dict[str, str] = field(default_factory=dict)

    @property
    def run_name(self) -> str:
        return f"{self.method}__{self.name}"


def _lr_name(lr: float) -> str:
    return f"lr{lr:g}"


def rgb_variants(epochs: int) -> Dict[str, List[tuple]]:
    """Three non-lr variants per architecture (equal count). Returns {arch: [(label, overrides, literal)]}."""
    warm = max(1, epochs // 10)
    return {
        "sg_vdnet": [
            ("literal", {}, True),                                              # lambda=0.1, pixel-mean MSE, no warm-up
            ("hmscale50", {"loss.hm_loss_scale": 50.0}, False),                 # DEVIATION (A8)
            (f"warmup{warm}", {"loss.sg_warmup_epochs": warm}, False),          # DEVIATION (A8)
        ],
        # The heatmap-only baseline is offered the SAME loss-scale knob, so a gain of SG over PG cannot come from
        # the baseline having been tuned less. (Warm-up is meaningless without SGL; scale 10 fills the third slot.)
        "pg_vdnet": [
            ("hmscale1", {}, True),
            ("hmscale10", {"loss.hm_loss_scale": 10.0}, False),
            ("hmscale50", {"loss.hm_loss_scale": 50.0}, False),
        ],
        "point_net": [
            ("wd0", {}, True),
            ("wd1e-4", {"train.weight_decay": 1e-4}, False),
            ("wd1e-3", {"train.weight_decay": 1e-3}, False),
        ],
    }


_ARCH_LOSS = {"sg_vdnet": "heatmap_mse_sgl", "pg_vdnet": "heatmap_mse", "point_net": "point_mse"}


def rgb_plan(epochs: int, lrs: Sequence[float] = (1e-3, 3e-4), archs: Sequence[str] = ("point_net", "pg_vdnet", "sg_vdnet"),
             pretrained_backbone: bool = False) -> List[Trial]:
    out = []
    for arch in archs:
        for label, ov, literal in rgb_variants(epochs)[arch]:
            for lr in lrs:
                o = {"model.arch": arch, "loss.type": _ARCH_LOSS[arch], "data.modality": "rgb",
                     "train.lr": float(lr), "model.pretrained_backbone": pretrained_backbone, **ov}
                out.append(Trial(arch, f"{_lr_name(lr)}__{label}", o, literal=literal and lr == lrs[0],
                                 tags={"phase": "rgb", "arch": arch, "variant": label}))
    return out


def ir_plan(winners: Dict[str, dict], lrs: Sequence[float] = (1e-3, 3e-4),
            archs: Sequence[str] = ("point_net", "pg_vdnet", "sg_vdnet"), include_imagenet_scratch: bool = True) -> List[Trial]:
    """IR runs. `winners[arch] = {"overrides": <RGB winner's non-lr overrides>, "ckpt": <RGB best.pt>}`.
    Every IR method uses the winner's loss settings (so scratch vs transfer differ ONLY in initialisation/freezing)
    and the same lr grid (equal budget)."""
    out = []
    for arch in archs:
        if arch not in winners:
            continue
        base = {k: v for k, v in winners[arch]["overrides"].items() if k != "train.lr"}
        base.update({"data.modality": "ir", "model.arch": arch, "loss.type": _ARCH_LOSS[arch]})
        kinds = {"ir_scratch_random": {"model.pretrained_backbone": False}}
        if include_imagenet_scratch:
            kinds["ir_scratch_imagenet"] = {"model.pretrained_backbone": True}
        if arch != "point_net":      # transfer ablation is defined for the heatmap networks (paper Table 5)
            kinds["ir_transfer"] = {"model.pretrained_backbone": False, "transfer.init_from": winners[arch]["ckpt"],
                                    "transfer.freeze_backbone": True, "transfer.trainable": ["head"]}
        for kind, ov in kinds.items():
            for lr in lrs:
                out.append(Trial(f"{arch}__{kind}", _lr_name(lr), {**base, **ov, "train.lr": float(lr)},
                                 tags={"phase": "ir", "arch": arch, "kind": kind}))
    return out


def check_plan(trials: Sequence[Trial], epochs: int, base_epochs_key: str = "train.epochs") -> None:
    """Raise if the plan breaks the fairness rules."""
    by_group: Dict[str, int] = {}
    for t in trials:
        if base_epochs_key in t.overrides and t.overrides[base_epochs_key] != epochs:
            raise ValueError(f"{t.run_name}: epochs must equal {epochs} for every trial (equal-epoch rule)")
        if t.overrides.get("transfer.init_from") and not t.overrides.get("transfer.freeze_backbone"):
            raise ValueError(f"{t.run_name}: transfer trial must freeze the backbone (paper protocol)")
        g = t.tags.get("phase", "") + ":" + t.tags.get("arch", "")
        if t.tags.get("phase") == "ir":
            g += ":" + t.tags.get("kind", "")
        by_group[g] = by_group.get(g, 0) + 1
    rgb = {g: n for g, n in by_group.items() if g.startswith("rgb:")}
    if len(set(rgb.values())) > 1:
        raise ValueError(f"unequal tuning budget across RGB methods: {rgb}")
    ir = {g: n for g, n in by_group.items() if g.startswith("ir:")}
    if len(set(ir.values())) > 1:
        raise ValueError(f"unequal tuning budget across IR methods: {ir}")
    names = [t.run_name for t in trials]
    if len(set(names)) != len(names):
        raise ValueError("duplicate trial names")
