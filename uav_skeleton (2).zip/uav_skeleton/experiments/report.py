"""Aggregate Stage 5 run records into measured tables (markdown + JSON). Validation split only; plain keypoint error."""
from __future__ import annotations

import math
import statistics as st
from typing import Dict, List, Sequence

HEADER = ("**Measured on the VALIDATION split; plain mean keypoint error in original-image pixels with ground-truth box crops. "
          "This is NOT the paper's IoP/RMSE (Stage 6) and must not be compared with the published tables.**\n")


def _ms(vals: Sequence[float]):
    vals = [v for v in vals if math.isfinite(v)]
    if not vals:
        return None, None
    return st.mean(vals), (st.stdev(vals) if len(vals) > 1 else None)


def _fmt(m, s, n):
    if m is None:
        return "n/a"
    return f"{m:.2f}" + (f" ± {s:.2f} (n={n})" if s is not None else " (n=1)")


def summarize(selection: Dict[str, dict], extra: Dict[str, List[dict]]) -> Dict[str, dict]:
    """selection from runner.select_winners; extra[method] = extra-seed records of the winner config."""
    out = {}
    for method, m in selection.items():
        w = m["winner"]
        if w is None:
            out[method] = {"status": "all trials failed", "n_failed": m["n_failed"]}
            continue
        vals = [w["best_val"]] + [r["best_val"] for r in extra.get(method, []) if r["status"] == "ok"]
        mean, sd = _ms(vals)
        lit = m["literal"]
        out[method] = {"winner_trial": w["trial"], "winner_best_val_px": w["best_val"], "winner_best_epoch": w["best_epoch"],
                       "seeds_mean_px": mean, "seeds_std_px": sd, "n_seeds": len(vals),
                       "literal_trial": lit["trial"] if lit else None, "literal_best_val_px": lit["best_val"] if lit else None,
                       "n_trials": m["n_trials"], "n_failed": m["n_failed"],
                       "per_keypoint_px_at_best": w["val_at_best"].get("val_kp_error_per_keypoint_px"),
                       "epochs": w["epochs_configured"]}
    return out


def _row(label, s):
    if s is None or "winner_trial" not in s:
        return f"| {label} | n/a (no successful trial) | | | |"
    lit = f"{s['literal_best_val_px']:.2f}" if s.get("literal_best_val_px") is not None else "n/a"
    return (f"| {label} | {_fmt(s['seeds_mean_px'], s['seeds_std_px'], s['n_seeds'])} | {s['winner_trial']} | {lit} | "
            f"{s['n_trials']} ok / {s['n_failed']} failed |")


def markdown(rgb: Dict[str, dict], ir: Dict[str, dict], notes: Sequence[str] = ()) -> str:
    cols = "| method | val kp error px (selected trial) | selected trial | paper-literal trial (px) | trials |\n|---|---|---|---|---|"
    L = ["# Stage 5 - measured validation results", "", HEADER]
    L += ["## Ablation 1 - point-MSE vs heatmap-MSE (no SGL)", "", cols,
          _row("RGB  point regression (point_net)", rgb.get("point_net")), _row("RGB  heatmap MSE (pg_vdnet)", rgb.get("pg_vdnet")),
          _row("IR scratch-random  point regression", ir.get("point_net__ir_scratch_random")),
          _row("IR scratch-random  heatmap MSE", ir.get("pg_vdnet__ir_scratch_random")), ""]
    L += ["## Ablation 2 - heatmap MSE vs heatmap MSE + SGL", "", cols,
          _row("RGB  heatmap MSE (pg_vdnet)", rgb.get("pg_vdnet")), _row("RGB  + SGL (sg_vdnet)", rgb.get("sg_vdnet")),
          _row("IR scratch-random  heatmap MSE", ir.get("pg_vdnet__ir_scratch_random")),
          _row("IR scratch-random  + SGL", ir.get("sg_vdnet__ir_scratch_random")), ""]
    L += ["## Ablation 3 - IR: scratch vs RGB-pretrained transfer (frozen backbone, equal epochs)", "", cols]
    for arch, nm in (("pg_vdnet", "heatmap MSE"), ("sg_vdnet", "+ SGL")):
        for kind, kn in (("ir_scratch_random", "scratch (random init)"), ("ir_scratch_imagenet", "scratch (ImageNet backbone)"),
                         ("ir_transfer", "transfer from RGB (backbone frozen)")):
            L.append(_row(f"IR {nm}: {kn}", ir.get(f"{arch}__{kind}")))
    L += ["", "## Notes", "",
          "- 'selected trial' = lowest validation error among the method's trials; every method in a comparison got the same number of "
          "trials and the same epochs. 'paper-literal' = lambda 0.1, pixel-mean heatmap MSE, no warm-up (for baselines: scale 1 / wd 0).",
          "- Selection and reporting use the same validation split, so the selected-trial numbers are optimistic by selection; "
          "only the Stage 6 test-split run is an unbiased estimate.",
          "- n>1 means extra seeds of the selected config (RGB checkpoints used for transfer come from the base seed only)."]
    L += [f"- {n}" for n in notes]
    return "\n".join(L) + "\n"
