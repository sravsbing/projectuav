"""Run a Stage 5 plan: one training run per trial, results saved as JSON, resumable, failures recorded (never hidden)."""
from __future__ import annotations

import json
import math
import os
import traceback
from typing import Dict, Iterable, List, Optional, Sequence

from experiments.plan import Trial
from training.config import load_config
from training.trainer import run_training


def result_path(out_dir: str, trial: Trial, seed: int) -> str:
    return os.path.join(out_dir, f"{trial.run_name}__seed{seed}.json")


def run_trial(trial: Trial, base: Sequence[str], out_dir: str, seed: int, phase: str, device: Optional[str] = None,
              verbose: bool = False) -> dict:
    """`base` = shared 'key=value' overrides (data.root, train.epochs, run.log_dir, ...). Skips finished trials."""
    path = result_path(out_dir, trial, seed)
    if os.path.exists(path):
        with open(path) as f:
            return json.load(f)
    ov = list(base) + [f"{k}={_fmt(v)}" for k, v in trial.overrides.items()]
    ov += [f"seed={seed}", f"run.name={phase}__{trial.run_name}__seed{seed}"]
    rec = {"method": trial.method, "trial": trial.name, "seed": seed, "phase": phase, "literal": trial.literal,
           "tags": trial.tags, "overrides": {k: v for k, v in trial.overrides.items()}, "base": list(base)}
    try:
        cfg = load_config(None, ov)
        s = run_training(cfg, device=device, verbose=verbose)
        hist = s.pop("history")
        best = next((h for h in hist if h["epoch"] == s["best_epoch"]), None)
        rec.update(status="ok", epochs_run=len(hist), epochs_configured=cfg["train"]["epochs"],
                   best_epoch=s["best_epoch"], best_val=s["best_value"], select_on=s["select_on"],
                   best_ckpt=s["best_ckpt"], val_at_best={k: v for k, v in (best or {}).items() if k.startswith("val_")},
                   splits_used=s["splits_used"], params=s["params"],
                   final_train_loss=hist[-1]["train_loss"] if hist else None)
    except Exception as e:            # recorded, not swallowed: e.g. ImageNet weights unreachable -> status=failed
        rec.update(status="failed", error=f"{type(e).__name__}: {e}", traceback=traceback.format_exc(limit=4))
    os.makedirs(out_dir, exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w") as f:
        json.dump(rec, f, indent=1, default=str)
    os.replace(tmp, path)
    return rec


def _fmt(v) -> str:
    return json.dumps(v) if isinstance(v, (list, dict, bool)) or v is None else repr(v) if isinstance(v, float) else str(v)


def run_plan(trials: Iterable[Trial], base: Sequence[str], out_dir: str, seed: int, phase: str,
             device: Optional[str] = None, verbose: bool = False) -> List[dict]:
    recs = []
    for t in trials:
        r = run_trial(t, base, out_dir, seed, phase, device, verbose)
        print(f"[{phase}] {t.run_name:55s} {r['status']:6s}"
              + (f" best_val={r['best_val']:.3f}px @ep{r['best_epoch']}" if r["status"] == "ok" else f"  {r['error'][:80]}"),
              flush=True)
        recs.append(r)
    return recs


def select_winners(recs: Sequence[dict]) -> Dict[str, dict]:
    """Per method: the OK trial with the lowest validation error (ties -> first). Also returns the literal trial."""
    out: Dict[str, dict] = {}
    for r in recs:
        if r["status"] != "ok" or not math.isfinite(r["best_val"]):
            continue
        m = out.setdefault(r["method"], {"winner": None, "literal": None, "n_trials": 0, "n_failed": 0})
        m["n_trials"] += 1
        if m["winner"] is None or r["best_val"] < m["winner"]["best_val"]:
            m["winner"] = r
        if r["literal"]:
            m["literal"] = r
    for r in recs:
        if r["status"] != "ok":
            out.setdefault(r["method"], {"winner": None, "literal": None, "n_trials": 0, "n_failed": 0})["n_failed"] += 1
    return out


def winners_for_ir(selection: Dict[str, dict]) -> Dict[str, dict]:
    """RGB winners -> the dict `ir_plan` expects (non-lr overrides + checkpoint)."""
    w = {}
    for arch, m in selection.items():
        if m["winner"] is None:
            continue
        r = m["winner"]
        w[arch] = {"overrides": {k: v for k, v in r["overrides"].items() if k != "train.lr"}, "ckpt": r["best_ckpt"]}
    return w
