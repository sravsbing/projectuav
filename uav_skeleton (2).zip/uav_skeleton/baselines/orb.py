"""ORB baseline (paper's classical comparison; details are assumption A14 - the paper does not give them).

Method: ORB feature matching against a reference database, with offset voting.
  Build (TRAIN images only):  normalise the box crop exactly like the networks do (square window, 256 px),
      detect ORB features, and for every feature store its 256-bit descriptor plus, for each labelled
      keypoint k, the offset  feature -> keypoint  expressed in the feature's own frame
      (rotated by -angle, divided by scale).  So a descriptor remembers "where the wing is, relative to me".
  Predict:  detect ORB features in the query crop, match each to the database (Hamming, k nearest,
      Lowe-style ratio test against the best match from a DIFFERENT training image, absolute distance cap),
      let each match vote for every keypoint (offset re-rotated/re-scaled by the QUERY feature's angle/scale),
      then take the densest cluster of votes per keypoint (median of the votes inside `cluster_radius`).
  A keypoint with fewer than `min_votes` supporting votes is returned as NaN with confidence 0: it is a
  MISS, never a fabricated point. Stage 6 counts it as a miss.

Why not simply describe the labelled pixel? ORB descriptors at a featureless wing tip are meaningless, and
OpenCV's compute() uses the angle you hand it (verified: it does NOT recompute it), so this baseline computes the
orientation itself where it needs to; the voting formulation avoids needing descriptors at the labelled points.

Only classical OpenCV ORB is used; nothing here is learned. Hyper-parameters are fields of ORBConfig and are
reported with any result; none were tuned on test data.
"""
from __future__ import annotations

import os
import pickle
from dataclasses import asdict, dataclass
from typing import Dict, List, Optional, Sequence

import cv2
import numpy as np

from data.annotations import Annotation
from data.dataset import load_image_rgb_u8
from data.keypoints import NUM_KEYPOINTS
from data.manifest import ManifestRow
from data.transforms import crop_pad_resize, square_crop_from_bbox, transform_keypoints
from models.postprocess import Skeleton, make_skeleton

PATCH = 31          # ORB patch size / edge threshold; features closer than this to the image border are dropped
PAD = PATCH + 1     # border added around the crop so features near the crop edge are still found


@dataclass
class ORBConfig:
    input_size: int = 256          # crop side in px (same normalisation as the networks)
    margin: float = 0.1
    nfeatures: int = 500
    scale_factor: float = 1.2
    nlevels: int = 8
    fast_threshold: int = 10       # lower than OpenCV's 20: crops are small and IR is low-contrast
    knn: int = 8                   # neighbours examined per query feature
    ratio: float = 0.85            # best / best-from-another-training-image
    max_hamming: int = 80          # absolute cap (of 256 bits) for a match to vote at all
    cluster_radius: float = 12.0   # crop pixels
    min_votes: int = 3
    max_db_features: int = 0       # 0 = keep all; >0 = random subsample (seeded) to bound memory/time
    seed: int = 42


def _orb(cfg: ORBConfig):
    return cv2.ORB_create(nfeatures=cfg.nfeatures, scaleFactor=cfg.scale_factor, nlevels=cfg.nlevels,
                          edgeThreshold=PATCH, patchSize=PATCH, fastThreshold=cfg.fast_threshold)


def features(gray_crop: np.ndarray, cfg: ORBConfig):
    """-> (xy (N,2) in crop pixel-centre coords, angle_rad (N,), scale (N,), desc (N,32) uint8)."""
    padded = cv2.copyMakeBorder(gray_crop, PAD, PAD, PAD, PAD, cv2.BORDER_REFLECT_101)
    kps, desc = _orb(cfg).detectAndCompute(padded, None)
    if not kps or desc is None:
        return (np.zeros((0, 2)), np.zeros(0), np.zeros(0), np.zeros((0, 32), np.uint8))
    xy = np.array([k.pt for k in kps], dtype=np.float64) - PAD
    ang = np.deg2rad(np.array([k.angle for k in kps], dtype=np.float64))
    scale = np.array([k.size for k in kps], dtype=np.float64) / PATCH
    return xy, ang, scale, desc


def _to_gray(rgb_u8: np.ndarray) -> np.ndarray:
    return cv2.cvtColor(np.ascontiguousarray(rgb_u8), cv2.COLOR_RGB2GRAY)


def _rot(v: np.ndarray, a: np.ndarray) -> np.ndarray:
    """Rotate row vectors v (N,2) by angles a (N,) (direction (cos a, sin a) in image coords)."""
    c, s = np.cos(a)[:, None], np.sin(a)[:, None]
    return np.stack([c[:, 0] * v[:, 0] - s[:, 0] * v[:, 1], s[:, 0] * v[:, 0] + c[:, 0] * v[:, 1]], axis=1)


class ReferenceDB:
    def __init__(self, cfg: ORBConfig):
        self.cfg = cfg
        self.desc = np.zeros((0, 32), np.uint8)
        self.offsets = np.zeros((0, NUM_KEYPOINTS, 2), np.float32)     # canonical-frame offsets, NaN = unlabelled
        self.source = np.zeros(0, np.int32)                            # index of the training image
        self.source_ids: List[str] = []
        self.modality: Optional[str] = None
        self._matcher = None

    def __len__(self) -> int:
        return len(self.desc)

    # ------------------------------------------------------------------ build
    def add_image(self, gray_crop: np.ndarray, kp_in: np.ndarray, vis: np.ndarray, sample_id: str) -> int:
        xy, ang, sc, desc = features(gray_crop, self.cfg)
        if len(xy) == 0:
            return 0
        off = np.full((len(xy), NUM_KEYPOINTS, 2), np.nan, np.float32)
        for k in range(NUM_KEYPOINTS):
            if vis[k] > 0:
                d = kp_in[k][None, :] - xy                                   # feature -> keypoint, crop px
                off[:, k] = (_rot(d, -ang) / sc[:, None]).astype(np.float32)  # into the feature's own frame
        sid = len(self.source_ids)
        self.source_ids.append(sample_id)
        self.desc = np.concatenate([self.desc, desc])
        self.offsets = np.concatenate([self.offsets, off])
        self.source = np.concatenate([self.source, np.full(len(xy), sid, np.int32)])
        self._matcher = None
        return len(xy)

    def finalize(self) -> None:
        n = self.cfg.max_db_features
        if n and len(self) > n:
            keep = np.sort(np.random.default_rng(self.cfg.seed).choice(len(self), n, replace=False))
            self.desc, self.offsets, self.source = self.desc[keep], self.offsets[keep], self.source[keep]
        self._matcher = None

    # ------------------------------------------------------------------ query
    def _bf(self):
        if self._matcher is None:
            self._matcher = cv2.BFMatcher(cv2.NORM_HAMMING)
            self._matcher.add([self.desc])
        return self._matcher

    def match(self, q_desc: np.ndarray):
        """-> list of (query_idx, db_idx) that pass the ratio test and distance cap."""
        if len(self) == 0 or len(q_desc) == 0:
            return []
        k = min(self.cfg.knn, len(self))
        out = []
        for m in self._bf().knnMatch(q_desc, k=k):
            if not m:
                continue
            best = m[0]
            if best.distance > self.cfg.max_hamming:
                continue
            # Lowe test against the best neighbour that comes from a different training image; neighbours from the
            # same image or from near-duplicate frames would otherwise veto every good match in a multi-image DB.
            other = next((n for n in m[1:] if self.source[n.trainIdx] != self.source[best.trainIdx]), None)
            if other is None or best.distance <= self.cfg.ratio * max(other.distance, 1e-9):
                out.append((best.queryIdx, best.trainIdx))
        return out

    # ------------------------------------------------------------------ io
    def save(self, path: str) -> None:
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        tmp = path + ".tmp"
        with open(tmp, "wb") as f:
            pickle.dump({"cfg": asdict(self.cfg), "desc": self.desc, "offsets": self.offsets, "source": self.source,
                         "source_ids": self.source_ids, "modality": self.modality}, f)
        os.replace(tmp, path)

    @classmethod
    def load(cls, path: str) -> "ReferenceDB":
        with open(path, "rb") as f:
            d = pickle.load(f)
        db = cls(ORBConfig(**d["cfg"]))
        db.desc, db.offsets, db.source = d["desc"], d["offsets"], d["source"]
        db.source_ids, db.modality = d["source_ids"], d["modality"]
        return db


def build_reference_db(root: str, rows: Sequence[ManifestRow], annotations: Dict[str, Annotation],
                       sample_ids: Sequence[str], modality: str, cfg: Optional[ORBConfig] = None,
                       allowed_ids: Optional[Sequence[str]] = None) -> ReferenceDB:
    """Build the DB from `sample_ids` (pass the TRAIN split only). `allowed_ids`, if given, is a hard whitelist:
    any sample outside it raises, so a caller that passes the train ids as `allowed_ids` cannot leak val/test."""
    cfg = cfg or ORBConfig()
    by_id = {r.sample_id: r for r in rows}
    allowed = set(allowed_ids) if allowed_ids is not None else None
    db = ReferenceDB(cfg)
    db.modality = modality
    for sid in sample_ids:
        if allowed is not None and sid not in allowed:
            raise ValueError(f"{sid} is not in the allowed (train) set - refusing to build the DB from it")
        r = by_id[sid]
        if r.modality != modality or sid not in annotations:
            continue
        if r.bbox is None:
            raise ValueError(f"{sid}: manifest row has no bbox")
        img = load_image_rgb_u8(os.path.join(root, r.image_path), r.modality)
        tf = square_crop_from_bbox(r.bbox, cfg.input_size, cfg.margin)
        gray = _to_gray(crop_pad_resize(img, tf))
        ann = annotations[sid]
        kp_in, vis = transform_keypoints(ann.keypoints, ann.visibility, tf)
        db.add_image(gray, kp_in, vis, sid)
    if len(db.source_ids) == 0:
        raise ValueError(f"no usable training images for modality {modality!r}")
    db.finalize()
    return db


class ORBBaseline:
    """Same call shape as VulnerabilityPipeline.predict, so Stage 6 evaluates all methods uniformly."""

    def __init__(self, db: ReferenceDB, detector=None):
        self.db, self.detector, self.cfg = db, detector, db.cfg

    def predict(self, image_rgb: np.ndarray, box_xyxy=None) -> Optional[Skeleton]:
        """None = no detection (no box). Otherwise a Skeleton whose unsupported keypoints are NaN / confidence 0."""
        if box_xyxy is None:
            if self.detector is None:
                raise ValueError("need a detector or an explicit box")
            det = self.detector.detect(image_rgb)
            if det is None:
                return None
            box_xyxy = det.box_xyxy
        cfg = self.cfg
        tf = square_crop_from_bbox(box_xyxy, cfg.input_size, cfg.margin)
        gray = _to_gray(crop_pad_resize(image_rgb, tf))
        xy, ang, sc, desc = features(gray, cfg)
        pairs = self.db.match(desc)
        kp_in = np.full((NUM_KEYPOINTS, 2), np.nan)
        conf = np.zeros(NUM_KEYPOINTS)
        if pairs:
            qi = np.array([p[0] for p in pairs])
            di = np.array([p[1] for p in pairs])
            for k in range(NUM_KEYPOINTS):
                off = self.db.offsets[di, k].astype(np.float64)
                ok = ~np.isnan(off[:, 0])
                if ok.sum() < cfg.min_votes:
                    continue
                votes = xy[qi[ok]] + _rot(off[ok] * sc[qi[ok]][:, None], ang[qi[ok]])
                p, n = _densest(votes, cfg.cluster_radius)
                if n >= cfg.min_votes:
                    kp_in[k], conf[k] = p, float(n)
        orig = np.full_like(kp_in, np.nan)
        got = ~np.isnan(kp_in[:, 0])
        if got.any():
            orig[got] = tf.to_original(kp_in[got])
        return make_skeleton(orig, conf, box_xyxy, kp_in)


def _densest(votes: np.ndarray, radius: float):
    """Vote with the most neighbours within `radius`; return (median of those neighbours, their count)."""
    d = np.linalg.norm(votes[:, None, :] - votes[None, :, :], axis=-1)
    inside = d <= radius
    j = int(np.argmax(inside.sum(1)))
    sel = votes[inside[j]]
    return np.median(sel, axis=0), len(sel)
