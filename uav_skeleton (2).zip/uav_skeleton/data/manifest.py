"""Sample manifest: one CSV row per image, the single index every other tool reads.

Columns (header required):
  sample_id*   unique string
  image_path*  relative to the dataset root
  modality*    rgb | ir
  group_id*    leakage unit (a flight sortie / continuous sequence). All splits are made on this.
  pair_id      links an RGB and an IR image of the same instant (optional)
  aircraft_id  UAV model/platform (optional, used for stratified splitting and per-aircraft metrics)
  view         free text, e.g. "bottom-up" (optional)
  width,height image size in pixels (optional; validator checks them)
  bbox_x1,bbox_y1,bbox_x2,bbox_y2   target box in original pixels (optional here, needed to train)
(* = required)

We do NOT assume RGB/IR pairs are pixel-aligned; pairing only says "same instant".
"""
from __future__ import annotations

import csv
import os
from collections import defaultdict
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

REQUIRED = ("sample_id", "image_path", "modality", "group_id")
COLUMNS = ("sample_id", "image_path", "modality", "group_id", "pair_id", "aircraft_id", "view",
           "width", "height", "bbox_x1", "bbox_y1", "bbox_x2", "bbox_y2")
MODALITIES = ("rgb", "ir")


@dataclass(frozen=True)
class ManifestRow:
    sample_id: str
    image_path: str
    modality: str
    group_id: str
    pair_id: Optional[str] = None
    aircraft_id: Optional[str] = None
    view: Optional[str] = None
    width: Optional[int] = None
    height: Optional[int] = None
    bbox: Optional[Tuple[float, float, float, float]] = None


def _opt(s: str) -> Optional[str]:
    s = (s or "").strip()
    return s or None


def read_manifest(path: str) -> List[ManifestRow]:
    rows: List[ManifestRow] = []
    with open(path, newline="", encoding="utf-8") as f:
        rd = csv.DictReader(f)
        missing = [c for c in REQUIRED if c not in (rd.fieldnames or [])]
        if missing:
            raise ValueError(f"{path}: missing required column(s) {missing}")
        for ln, r in enumerate(rd, 2):
            b = [_opt(r.get(k, "")) for k in ("bbox_x1", "bbox_y1", "bbox_x2", "bbox_y2")]
            if any(v is not None for v in b) and not all(v is not None for v in b):
                raise ValueError(f"{path}:{ln}: partial bbox")
            rows.append(ManifestRow(
                sample_id=r["sample_id"].strip(), image_path=r["image_path"].strip(),
                modality=r["modality"].strip().lower(), group_id=r["group_id"].strip(),
                pair_id=_opt(r.get("pair_id", "")), aircraft_id=_opt(r.get("aircraft_id", "")),
                view=_opt(r.get("view", "")),
                width=int(float(r["width"])) if _opt(r.get("width", "")) else None,
                height=int(float(r["height"])) if _opt(r.get("height", "")) else None,
                bbox=tuple(float(v) for v in b) if b[0] is not None else None,  # type: ignore
            ))
    return rows


def write_manifest(path: str, rows: List[ManifestRow]) -> None:
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(COLUMNS)
        for r in rows:
            bb = list(r.bbox) if r.bbox else ["", "", "", ""]
            w.writerow([r.sample_id, r.image_path, r.modality, r.group_id, r.pair_id or "",
                        r.aircraft_id or "", r.view or "", r.width or "", r.height or "", *bb])


def validate_manifest(rows: List[ManifestRow], root: Optional[str] = None,
                      check_files: bool = True) -> Tuple[List[str], List[str]]:
    errs: List[str] = []
    warns: List[str] = []
    seen = set()
    pair_members: Dict[str, List[ManifestRow]] = defaultdict(list)
    for r in rows:
        if r.sample_id in seen:
            errs.append(f"duplicate sample_id {r.sample_id}")
        seen.add(r.sample_id)
        if r.modality not in MODALITIES:
            errs.append(f"{r.sample_id}: modality {r.modality!r} not in {MODALITIES}")
        if check_files and root is not None and not os.path.isfile(os.path.join(root, r.image_path)):
            errs.append(f"{r.sample_id}: image not found: {r.image_path}")
        if r.bbox is not None:
            x1, y1, x2, y2 = r.bbox
            if not (x2 > x1 and y2 > y1):
                errs.append(f"{r.sample_id}: degenerate bbox {r.bbox}")
            elif r.width and r.height and (x1 < -1 or y1 < -1 or x2 > r.width + 1 or y2 > r.height + 1):
                errs.append(f"{r.sample_id}: bbox {r.bbox} outside {r.width}x{r.height} image")
        if r.pair_id:
            pair_members[r.pair_id].append(r)
    for pid, ms in pair_members.items():
        mods = [m.modality for m in ms]
        if len(set(mods)) != len(mods):
            errs.append(f"pair {pid}: more than one image of the same modality")
        if len({m.group_id for m in ms}) > 1:
            errs.append(f"pair {pid}: members belong to different groups (would leak across splits)")
    n_groups = len({r.group_id for r in rows})
    if rows and n_groups > 0.5 * len(rows):
        warns.append(f"{n_groups} groups for {len(rows)} samples: group_id looks per-image, not per-sortie; "
                     "adjacent video frames could leak across splits")
    return errs, warns


def pairs(rows: List[ManifestRow]) -> Dict[str, Dict[str, ManifestRow]]:
    out: Dict[str, Dict[str, ManifestRow]] = defaultdict(dict)
    for r in rows:
        if r.pair_id:
            out[r.pair_id][r.modality] = r
    return dict(out)
