"""Semantic vulnerability-region masks and point-to-region distance.

Paper Sec. 3.1/3.2: the aircraft is segmented into region units around the skeleton nodes (Fig. 6);
a predicted point is a hit if it lies in the region of the target node, otherwise the error is the
shortest straight-line distance from the region boundary (Fig. 7).

Storage: one single-channel label PNG per sample, 0 = background, k+1 = region of keypoint k
(data.keypoints order), same size as the ORIGINAL image. Coloured visualisation masks must be
converted to labels first. The paper's masks are not public; ours must be annotated (see
docs/DATASET.md). `disc_region` is only a documented FALLBACK that turns IoP into a plain
radius test around the labelled point - results using it must be labelled as such.
"""
from __future__ import annotations

from typing import Optional

import numpy as np


def load_region_labels(path: str) -> np.ndarray:
    import cv2
    m = cv2.imread(path, cv2.IMREAD_UNCHANGED)
    if m is None:
        raise FileNotFoundError(path)
    if m.ndim == 3:
        raise ValueError(f"{path}: region mask must be a single-channel label PNG, got {m.shape}")
    return m.astype(np.uint8)


def save_region_labels(path: str, labels: np.ndarray) -> None:
    import cv2
    if not cv2.imwrite(path, labels.astype(np.uint8)):
        raise IOError(f"cannot write {path}")


def region_for_keypoint(labels: np.ndarray, k: int) -> np.ndarray:
    return labels == (k + 1)


def disc_region(shape_hw, center_xy, radius: float) -> np.ndarray:
    h, w = shape_hw
    yy, xx = np.mgrid[0:h, 0:w]
    return (xx - center_xy[0]) ** 2 + (yy - center_xy[1]) ** 2 <= radius ** 2


def distance_to_region(region: np.ndarray, point_xy) -> float:
    """Exact Euclidean distance from `point_xy` to the union of region pixels.

    Each region pixel is the unit square centred on its integer coordinate (pixel-centre frame), so
    the distance is 0 for any point inside the region and otherwise the true shortest distance to
    its boundary (no half-pixel bias). Points outside the image are handled. Returns inf for an
    empty region.
    """
    ys, xs = np.nonzero(region)
    if len(xs) == 0:
        return float("inf")
    px, py = float(point_xy[0]), float(point_xy[1])
    dx = np.maximum(np.abs(xs - px) - 0.5, 0.0)
    dy = np.maximum(np.abs(ys - py) - 0.5, 0.0)
    return float(np.sqrt(dx * dx + dy * dy).min())
