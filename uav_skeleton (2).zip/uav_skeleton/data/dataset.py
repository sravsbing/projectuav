"""PyTorch dataset: manifest row + annotation -> network-ready sample.

Per item: GT box -> (optional jitter) -> square window -> crop/pad/resize -> normalised tensor,
keypoints mapped into network-input coords (visibility updated if a keypoint leaves the window),
Gaussian heatmaps, and the transform parameters needed to map predictions back to the original image.

Assumptions (see docs/PAPER_ANALYSIS.md): training crops come from the GT box, optionally jittered
to imitate detector error (`box_jitter`); at test time Stage 3 swaps in the YOLO box. IR images are
replicated to 3 channels so one ResNet-18 (3-channel stem) serves both modalities; 16-bit IR is
scaled by its dtype maximum (not per-image min/max, which would change contrast per sample).
"""
from __future__ import annotations

import os
from typing import Dict, List, Optional, Sequence

import numpy as np
import torch
from torch.utils.data import Dataset

from data.annotations import Annotation
from data.heatmaps import generate_heatmaps
from data.keypoints import LEFT_WING, RIGHT_WING, NUM_KEYPOINTS
from data.manifest import ManifestRow
from data.transforms import CropTransform, crop_pad_resize, square_crop_from_bbox, transform_keypoints

IMAGENET_MEAN = np.array([0.485, 0.456, 0.406], dtype=np.float32)
IMAGENET_STD = np.array([0.229, 0.224, 0.225], dtype=np.float32)

# Mirroring an aircraft swaps which physical wing is on which side of the image.
FLIP_PERMUTATION = list(range(NUM_KEYPOINTS))
FLIP_PERMUTATION[LEFT_WING], FLIP_PERMUTATION[RIGHT_WING] = RIGHT_WING, LEFT_WING


def load_image_rgb_u8(path: str, modality: str) -> np.ndarray:
    """-> HxWx3 uint8 (RGB order for rgb; replicated grey for ir)."""
    import cv2
    img = cv2.imread(path, cv2.IMREAD_UNCHANGED)
    if img is None:
        raise FileNotFoundError(path)
    if img.dtype == np.uint16:
        img = (img.astype(np.float32) / 65535.0 * 255.0).round().astype(np.uint8)
    elif img.dtype != np.uint8:
        raise ValueError(f"{path}: unsupported dtype {img.dtype}")
    if img.ndim == 2:
        img = np.repeat(img[..., None], 3, axis=-1)
    elif img.shape[2] == 4:
        img = img[..., :3]
    if img.shape[2] == 3 and modality == "rgb":
        img = img[..., ::-1]  # BGR -> RGB
    return np.ascontiguousarray(img)


def normalize_crop(crop_u8: np.ndarray) -> np.ndarray:
    """HxWx3 uint8 crop -> CHW float32, ImageNet-normalised (shared by training and inference)."""
    x = (crop_u8.astype(np.float32) / 255.0 - IMAGENET_MEAN) / IMAGENET_STD
    return np.ascontiguousarray(x.transpose(2, 0, 1))


def jitter_bbox(bbox, jitter: float, rng: np.random.Generator):
    x1, y1, x2, y2 = bbox
    w, h = x2 - x1, y2 - y1
    cx, cy = (x1 + x2) / 2 + rng.uniform(-jitter, jitter) * w, (y1 + y2) / 2 + rng.uniform(-jitter, jitter) * h
    w *= 1 + rng.uniform(-jitter, jitter)
    h *= 1 + rng.uniform(-jitter, jitter)
    return (cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2)


class SkeletonDataset(Dataset):
    def __init__(self, root: str, rows: Sequence[ManifestRow], annotations: Dict[str, Annotation],
                 sample_ids: Optional[Sequence[str]] = None, modality: Optional[str] = None,
                 input_size: int = 256, heatmap_size: int = 64, sigma: float = 2.0, margin: float = 0.1,
                 box_jitter: float = 0.0, hflip_prob: float = 0.0, seed: int = 42):
        by_id = {r.sample_id: r for r in rows}
        ids = list(sample_ids) if sample_ids is not None else [r.sample_id for r in rows]
        keep: List[str] = []
        for sid in ids:
            r = by_id[sid]
            if modality is not None and r.modality != modality:
                continue
            if sid not in annotations:
                continue                       # unlabelled images cannot train/evaluate keypoints
            if r.bbox is None:
                raise ValueError(f"{sid}: manifest has no bbox; run the box parsers / build_manifest first")
            keep.append(sid)
        self.root, self.by_id, self.anns, self.ids = root, by_id, annotations, keep
        self.input_size, self.heatmap_size, self.sigma, self.margin = input_size, heatmap_size, sigma, margin
        self.box_jitter, self.hflip_prob, self.seed, self.epoch = box_jitter, hflip_prob, seed, 0

    def set_epoch(self, epoch: int) -> None:
        self.epoch = epoch

    def __len__(self) -> int:
        return len(self.ids)

    def __getitem__(self, i: int) -> dict:
        sid = self.ids[i]
        r, ann = self.by_id[sid], self.anns[sid]
        rng = np.random.default_rng([self.seed, self.epoch, i])  # reproducible, worker-independent
        img = load_image_rgb_u8(os.path.join(self.root, r.image_path), r.modality)
        bbox = jitter_bbox(r.bbox, self.box_jitter, rng) if self.box_jitter > 0 else r.bbox
        tf = square_crop_from_bbox(bbox, self.input_size, self.margin)
        crop = crop_pad_resize(img, tf)
        kp_in, vis = transform_keypoints(ann.keypoints, ann.visibility, tf)
        if self.hflip_prob > 0 and rng.random() < self.hflip_prob:
            crop = crop[:, ::-1]
            kp_in = kp_in[FLIP_PERMUTATION].copy()
            kp_in[:, 0] = (self.input_size - 1) - kp_in[:, 0]
            vis = vis[FLIP_PERMUTATION]
            flipped = True
        else:
            flipped = False
        x = normalize_crop(np.ascontiguousarray(crop)).transpose(1, 2, 0)
        kp_t = torch.from_numpy(kp_in.astype(np.float32))
        vis_t = torch.from_numpy(vis.astype(np.float32))
        hm = generate_heatmaps(kp_t[None], vis_t[None], self.heatmap_size, self.input_size, self.sigma)[0]
        return {
            "image": torch.from_numpy(np.ascontiguousarray(x.transpose(2, 0, 1))),
            "heatmaps": hm, "keypoints_in": kp_t, "visibility": vis_t,
            "keypoints_norm": (kp_t + 0.5) / self.input_size,
            "crop": torch.tensor([tf.x0, tf.y0, tf.side], dtype=torch.float64),
            "flipped": flipped, "sample_id": sid, "modality": r.modality,
            "difficulty": ann.difficulty or "", "aircraft_id": r.aircraft_id or "",
        }

    def transform_of(self, item: dict) -> CropTransform:
        x0, y0, side = (float(v) for v in item["crop"])
        return CropTransform(x0, y0, side, self.input_size)
