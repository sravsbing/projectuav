"""GUI-independent state machine behind scripts/annotate.py (so the logic is unit-testable).

Workflow per image: click the 6 keypoints in KEYPOINT_NAMES order (or press 'm' to mark the current
one missing), choose easy/hard, commit. Existing labels load for review/editing. All clicks are in
ORIGINAL-image coordinates (the GUI maps zoomed-crop clicks back through CropTransform.to_original).
"""
from __future__ import annotations

from typing import Dict, List, Optional

import numpy as np

from data.annotations import Annotation, DIFFICULTIES
from data.keypoints import KEYPOINT_NAMES, NUM_KEYPOINTS


class AnnotationSession:
    def __init__(self, sample_ids: List[str], annotations: Dict[str, Annotation], annotator: str = "",
                 default_region_mask: Optional[Dict[str, str]] = None):
        if not sample_ids:
            raise ValueError("no samples to annotate")
        self.sample_ids = list(sample_ids)
        self.annotations = annotations
        self.annotator = annotator
        self.idx = 0
        self._load_current()

    # ---- navigation -------------------------------------------------------------------------
    @property
    def sample_id(self) -> str:
        return self.sample_ids[self.idx]

    def _load_current(self) -> None:
        a = self.annotations.get(self.sample_id)
        if a is None:
            self.kps = np.zeros((NUM_KEYPOINTS, 2))
            self.vis = np.zeros(NUM_KEYPOINTS, np.uint8)
            self.ptr, self.difficulty, self.notes = 0, None, ""
        else:
            self.kps, self.vis = a.keypoints.copy(), a.visibility.copy()
            self.ptr, self.difficulty, self.notes = NUM_KEYPOINTS, a.difficulty, a.notes

    def goto(self, i: int) -> None:
        self.idx = int(np.clip(i, 0, len(self.sample_ids) - 1))
        self._load_current()

    def next_unlabelled(self) -> bool:
        for j in range(self.idx + 1, len(self.sample_ids)):
            if self.sample_ids[j] not in self.annotations:
                self.goto(j)
                return True
        return False

    # ---- editing ----------------------------------------------------------------------------
    @property
    def next_keypoint_name(self) -> Optional[str]:
        return KEYPOINT_NAMES[self.ptr] if self.ptr < NUM_KEYPOINTS else None

    def click(self, x: float, y: float) -> None:
        if self.ptr >= NUM_KEYPOINTS:
            raise RuntimeError("all keypoints placed; undo or commit")
        self.kps[self.ptr] = (x, y)
        self.vis[self.ptr] = 1
        self.ptr += 1

    def mark_missing(self) -> None:
        if self.ptr >= NUM_KEYPOINTS:
            raise RuntimeError("all keypoints placed; undo or commit")
        self.kps[self.ptr] = (0.0, 0.0)
        self.vis[self.ptr] = 0
        self.ptr += 1

    def undo(self) -> None:
        if self.ptr > 0:
            self.ptr -= 1
            self.kps[self.ptr] = (0.0, 0.0)
            self.vis[self.ptr] = 0

    def set_difficulty(self, d: Optional[str]) -> None:
        if d is not None and d not in DIFFICULTIES:
            raise ValueError(f"difficulty must be one of {DIFFICULTIES}")
        self.difficulty = d

    def commit(self) -> Annotation:
        if self.ptr < NUM_KEYPOINTS:
            raise RuntimeError(f"{NUM_KEYPOINTS - self.ptr} keypoint(s) still unplaced "
                               f"(next: {self.next_keypoint_name})")
        old = self.annotations.get(self.sample_id)
        ann = Annotation(self.sample_id, self.kps.copy(), self.vis.copy(), self.difficulty,
                         old.region_mask if old else None, self.annotator or (old.annotator if old else None),
                         self.notes)
        self.annotations[self.sample_id] = ann
        return ann
