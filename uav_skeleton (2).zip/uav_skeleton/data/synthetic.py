"""SYNTHETIC toy aircraft dataset - for unit tests and pipeline smoke tests ONLY.

Draws stick-figure "aircraft" with analytically known keypoints. Nothing measured on this data says
anything about MMFW-UAV or the paper; every manifest it writes uses aircraft ids `synthetic_*`.
"""
from __future__ import annotations

import os
from typing import Dict, List

import numpy as np

from data.annotations import Annotation, write_annotations
from data.keypoints import KP
from data.manifest import ManifestRow, write_manifest
from data.regions import save_region_labels, disc_region


def _pose(rng, w, h):
    L = rng.uniform(90, 180)           # fuselage length
    span = rng.uniform(100, 200)       # wing span
    theta = rng.uniform(0, 2 * np.pi)
    d = np.array([np.cos(theta), np.sin(theta)])
    n = np.array([-d[1], d[0]])        # "left" direction (synthetic convention)
    ext = max(L, span) / 2 + 20
    c = np.array([rng.uniform(ext, w - ext), rng.uniform(ext, h - ext)])
    kp = np.zeros((6, 2))
    kp[KP["head"]] = c + d * 0.35 * L
    kp[KP["body"]] = c
    kp[KP["left_wing"]] = c + n * span / 2
    kp[KP["right_wing"]] = c - n * span / 2
    kp[KP["tail_joint"]] = c - d * 0.30 * L
    kp[KP["tail_unit"]] = c - d * 0.45 * L
    return kp


def _render(kp, w, h, modality, rng):
    import cv2
    P = lambda k: tuple(int(round(v)) for v in kp[KP[k]])
    if modality == "rgb":
        bg = int(rng.integers(170, 230))
        img = np.full((h, w, 3), bg, np.uint8)
        col, th = (30, 30, 30), 6
    else:
        img = np.full((h, w, 3), 40, np.uint8)
        col, th = (230, 230, 230), 6
    cv2.line(img, P("tail_unit"), P("head"), col, th)
    cv2.line(img, P("left_wing"), P("right_wing"), col, th)
    if modality == "ir":
        img = cv2.GaussianBlur(img, (0, 0), 2.0)
        noise = rng.normal(0, 4, img.shape[:2] + (1,))  # one intensity channel, like a thermal sensor
        img = np.clip(img + noise, 0, 255).astype(np.uint8)
    return img


def make_synthetic_dataset(root: str, n_groups: int = 6, frames_per_group: int = 4, seed: int = 0,
                           size=(640, 480), with_regions: bool = True) -> Dict[str, object]:
    """Write images, manifest.csv, annotations.jsonl (+ region PNGs) under `root`."""
    import cv2
    rng = np.random.default_rng(seed)
    w, h = size
    rows: List[ManifestRow] = []
    anns: Dict[str, Annotation] = {}
    for g in range(n_groups):
        aircraft = f"synthetic_{g % 3}"
        for f in range(frames_per_group):
            kp = _pose(rng, w, h)
            pid = f"g{g}_f{f}"
            x1, y1 = kp.min(0) - 12
            x2, y2 = kp.max(0) + 12
            bbox = (float(max(x1, 0)), float(max(y1, 0)), float(min(x2, w)), float(min(y2, h)))
            for mod in ("rgb", "ir"):
                sid = f"{pid}_{mod}"
                rel = os.path.join(mod, f"{sid}.png")
                os.makedirs(os.path.join(root, mod), exist_ok=True)
                cv2.imwrite(os.path.join(root, rel), _render(kp, w, h, mod, rng))
                rrel = None
                if with_regions:
                    labels = np.zeros((h, w), np.uint8)
                    for k in range(6):
                        labels[disc_region((h, w), kp[k], 12) & (labels == 0)] = k + 1
                    rrel = os.path.join("regions", f"{sid}.png")
                    os.makedirs(os.path.join(root, "regions"), exist_ok=True)
                    save_region_labels(os.path.join(root, rrel), labels)
                rows.append(ManifestRow(sid, rel, mod, f"sortie{g}", pid, aircraft, "synthetic", w, h, bbox))
                anns[sid] = Annotation(sid, kp.copy(), np.ones(6, np.uint8),
                                       difficulty="easy" if f % 2 == 0 else "hard",
                                       region_mask=rrel, annotator="synthetic")
    write_manifest(os.path.join(root, "manifest.csv"), rows)
    write_annotations(os.path.join(root, "annotations.jsonl"), anns)
    return {"rows": rows, "annotations": anns}
