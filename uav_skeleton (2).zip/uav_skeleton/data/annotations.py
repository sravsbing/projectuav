"""Keypoint annotation schema, JSONL I/O and validation.

One JSON object per line, keyed by `sample_id` (the manifest id):

  {"sample_id": "...",
   "keypoints": [[x,y] x 6],      # ORIGINAL-image pixel coords (pixel-centre frame),
                                  #   order = data.keypoints.KEYPOINT_NAMES
   "visibility": [0|1 x 6],       # 0 = missing/not labelled (coords ignored), 1 = labelled
   "difficulty": "easy"|"hard"|null,
   "region_mask": "relative/path.png"|null,   # label PNG: 0=bg, k+1 = region of keypoint k
   "annotator": str|null, "notes": str}

Left/right wing are the AIRCRAFT's own left/right (see docs/ANNOTATION_GUIDE.md).
"""
from __future__ import annotations

import json
import os
import tempfile
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np

from data.keypoints import NUM_KEYPOINTS

DIFFICULTIES = ("easy", "hard")


@dataclass
class Annotation:
    sample_id: str
    keypoints: np.ndarray                      # (K,2) float64
    visibility: np.ndarray                     # (K,) uint8
    difficulty: Optional[str] = None
    region_mask: Optional[str] = None
    annotator: Optional[str] = None
    notes: str = ""

    def to_json(self) -> str:
        return json.dumps({
            "sample_id": self.sample_id,
            "keypoints": np.asarray(self.keypoints, dtype=float).round(3).tolist(),
            "visibility": [int(v) for v in self.visibility],
            "difficulty": self.difficulty,
            "region_mask": self.region_mask,
            "annotator": self.annotator,
            "notes": self.notes,
        }, ensure_ascii=False)

    @staticmethod
    def from_dict(d: dict) -> "Annotation":
        return Annotation(
            sample_id=str(d["sample_id"]),
            keypoints=np.asarray(d["keypoints"], dtype=np.float64).reshape(-1, 2),
            visibility=np.asarray(d["visibility"], dtype=np.uint8).reshape(-1),
            difficulty=d.get("difficulty"),
            region_mask=d.get("region_mask"),
            annotator=d.get("annotator"),
            notes=d.get("notes", "") or "",
        )


def read_annotations(path: str) -> Dict[str, Annotation]:
    out: Dict[str, Annotation] = {}
    if not os.path.exists(path):
        return out
    with open(path, "r", encoding="utf-8") as f:
        for ln, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue
            try:
                ann = Annotation.from_dict(json.loads(line))
            except Exception as e:  # malformed line must be loud, never skipped silently
                raise ValueError(f"{path}:{ln}: cannot parse annotation ({e})") from e
            if ann.sample_id in out:
                raise ValueError(f"{path}:{ln}: duplicate sample_id {ann.sample_id!r}")
            out[ann.sample_id] = ann
    return out


def write_annotations(path: str, anns: Dict[str, Annotation]) -> None:
    """Atomic write (temp file + rename) so an interrupted session cannot corrupt labels."""
    d = os.path.dirname(os.path.abspath(path))
    os.makedirs(d, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=d, suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            for sid in sorted(anns):
                f.write(anns[sid].to_json() + "\n")
        os.replace(tmp, path)
    except BaseException:
        if os.path.exists(tmp):
            os.remove(tmp)
        raise


def validate_annotation(ann: Annotation, width: Optional[int] = None, height: Optional[int] = None,
                        bbox_xyxy: Optional[Sequence[float]] = None,
                        bbox_slack: float = 0.25) -> Tuple[List[str], List[str]]:
    """Return (errors, warnings). Errors make the sample unusable for training."""
    errs: List[str] = []
    warns: List[str] = []
    K = NUM_KEYPOINTS
    if ann.keypoints.shape != (K, 2):
        errs.append(f"keypoints shape {ann.keypoints.shape}, expected ({K},2)")
        return errs, warns
    if ann.visibility.shape != (K,):
        errs.append(f"visibility shape {ann.visibility.shape}, expected ({K},)")
        return errs, warns
    if not np.isfinite(ann.keypoints).all():
        errs.append("non-finite keypoint coordinate")
        return errs, warns
    if not np.isin(ann.visibility, (0, 1)).all():
        errs.append(f"visibility values must be 0/1, got {ann.visibility.tolist()}")
    if ann.difficulty is not None and ann.difficulty not in DIFFICULTIES:
        errs.append(f"difficulty {ann.difficulty!r} not in {DIFFICULTIES}")
    vis = ann.visibility.astype(bool)
    if width is not None and height is not None and vis.any():
        p = ann.keypoints[vis]
        out = (p[:, 0] < -0.5) | (p[:, 0] > width - 0.5) | (p[:, 1] < -0.5) | (p[:, 1] > height - 0.5)
        if out.any():
            errs.append(f"{int(out.sum())} labelled keypoint(s) outside the {width}x{height} image")
    if bbox_xyxy is not None and vis.any():
        x1, y1, x2, y2 = bbox_xyxy
        sx, sy = bbox_slack * (x2 - x1), bbox_slack * (y2 - y1)
        p = ann.keypoints[vis]
        out = (p[:, 0] < x1 - sx) | (p[:, 0] > x2 + sx) | (p[:, 1] < y1 - sy) | (p[:, 1] > y2 + sy)
        if out.any():
            warns.append(f"{int(out.sum())} labelled keypoint(s) far outside the target box")
    if vis.sum() >= 2:
        p = ann.keypoints[vis]
        d = np.linalg.norm(p[:, None] - p[None], axis=-1) + np.eye(len(p)) * 1e9
        if (d < 1.0).any():
            warns.append("two labelled keypoints coincide (<1 px apart)")
    if not vis.any():
        warns.append("no labelled keypoint")
    return errs, warns
