"""Keypoint schema shared by every module.

The ORDER BELOW IS THE SINGLE SOURCE OF TRUTH. Heatmap channel k always
corresponds to KEYPOINT_NAMES[k]; annotations, losses, metrics and
visualisation must all index through these constants and never use bare ints.
"""
from __future__ import annotations

KEYPOINT_NAMES = ("head", "body", "left_wing", "right_wing", "tail_joint", "tail_unit")
NUM_KEYPOINTS = len(KEYPOINT_NAMES)
KP = {name: i for i, name in enumerate(KEYPOINT_NAMES)}

HEAD = KP["head"]
BODY = KP["body"]
LEFT_WING = KP["left_wing"]
RIGHT_WING = KP["right_wing"]
TAIL_JOINT = KP["tail_joint"]
TAIL_UNIT = KP["tail_unit"]

# Paper Sec. 2.2.1.2: main axis head-body-tail and transverse axis wing-body-wing.
# The paper does not say whether tail_joint lies between body and tail_unit; we
# assume the chain body -> tail_joint -> tail_unit (documented assumption A4).
SKELETON_EDGES = (
    (HEAD, BODY),
    (BODY, TAIL_JOINT),
    (TAIL_JOINT, TAIL_UNIT),
    (BODY, LEFT_WING),
    (BODY, RIGHT_WING),
)

# Paper Eq. 3-4 uses P_t = "tail unit" for the longitudinal vector V_bt.
SGL_TAIL = TAIL_UNIT

# Visibility flags used in annotations.
VIS_MISSING = 0   # not labelled / outside crop -> excluded from every loss
VIS_VISIBLE = 1   # labelled (we do not distinguish occluded-but-labelled)
