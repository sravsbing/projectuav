"""Skip macOS archive debris that appears when a dataset zip was made on a Mac: `._*` AppleDouble files, `__MACOSX/` folders,
`.DS_Store`, plus Windows `Thumbs.db`. They carry image-like names (`._0001.jpg`) but are not images or annotations."""
from __future__ import annotations

import os
from typing import Iterator, List, Tuple

JUNK_FILES = {".ds_store", "thumbs.db", "desktop.ini"}
JUNK_DIRS = {"__macosx", ".git", ".ipynb_checkpoints"}


def is_junk_name(name: str) -> bool:
    n = name.lower()
    return n.startswith("._") or n in JUNK_FILES or n in JUNK_DIRS


def is_junk_path(path: str) -> bool:
    return any(is_junk_name(p) for p in path.replace("\\", "/").split("/") if p)


def walk_clean(root: str) -> Iterator[Tuple[str, List[str], List[str]]]:
    """os.walk that prunes junk directories and drops junk files. Sorted, so results are deterministic."""
    for dp, dn, fn in os.walk(root):
        dn[:] = sorted(d for d in dn if not is_junk_name(d))
        yield dp, dn, sorted(f for f in fn if not is_junk_name(f))
