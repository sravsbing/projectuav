"""Crop -> square pad -> resize transform with exact inverse for points.

Pipeline (paper Sec. 2.2.2.1): YOLOv8 box -> crop -> pad to square with a
background-like colour -> resize to the network input size S x S.

Coordinate conventions (documented, used everywhere):
  * Image/pixel coordinates: continuous (x, y), pixel *centres* at integers,
    so the top-left pixel centre is (0, 0).
  * Heatmap coordinates: heatmap cell i covers input pixels [i*s, (i+1)*s), so
    x_in = (x_hm + 0.5) * s - 0.5   and   x_hm = (x_in + 0.5) / s - 0.5.
  * Normalised coordinates: x_norm = (x_in + 0.5) / S in [0, 1] (S = input size).
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass(frozen=True)
class CropTransform:
    """Maps original-image points <-> network-input points (and back)."""

    x0: float      # left edge of the square window, original coords (pixel-centre frame)
    y0: float      # top edge of the square window, original coords (pixel-centre frame)
    side: float    # side length of the square crop in original pixels
    out_size: int  # network input size S

    @property
    def scale(self) -> float:
        return self.out_size / self.side

    def to_input(self, pts: np.ndarray) -> np.ndarray:
        """Original-image coords (...,2) -> network-input coords (...,2)."""
        pts = np.asarray(pts, dtype=np.float64)
        return (pts - np.array([self.x0, self.y0])) * self.scale - 0.5

    def to_original(self, pts: np.ndarray) -> np.ndarray:
        """Network-input coords (...,2) -> original-image coords (...,2)."""
        pts = np.asarray(pts, dtype=np.float64)
        return (pts + 0.5) / self.scale + np.array([self.x0, self.y0])


def square_crop_from_bbox(bbox_xyxy, out_size: int, margin: float = 0.1) -> CropTransform:
    """Square window centred on the box, side = max(w,h) * (1 + 2*margin).

    The window may extend past the image border; the image sampler pads those
    pixels (paper: padding colour similar to the background).
    """
    x1, y1, x2, y2 = (float(v) for v in bbox_xyxy)
    cx, cy = 0.5 * (x1 + x2), 0.5 * (y1 + y2)
    side = max(x2 - x1, y2 - y1) * (1.0 + 2.0 * margin)
    side = max(side, 1.0)
    return CropTransform(x0=cx - side / 2, y0=cy - side / 2, side=side, out_size=out_size)


def transform_keypoints(kps_xy: np.ndarray, vis: np.ndarray, tf: CropTransform):
    """Apply crop transform to keypoints and update visibility.

    A keypoint that falls outside the network input after the transform is set
    to VIS_MISSING (paper: visibility mask handles "field-of-view departure").
    Returns (kps_in (K,2) float32, vis_out (K,) uint8).
    """
    kps_in = tf.to_input(kps_xy).astype(np.float32)
    S = tf.out_size
    inside = (
        (kps_in[:, 0] >= -0.5) & (kps_in[:, 0] <= S - 0.5)
        & (kps_in[:, 1] >= -0.5) & (kps_in[:, 1] <= S - 0.5)
    )
    vis_out = ((np.asarray(vis) > 0) & inside).astype(np.uint8)
    return kps_in, vis_out


def crop_pad_resize(image: np.ndarray, tf: CropTransform, pad_value=None) -> np.ndarray:
    """Sample the square window from `image` (H,W[,C]) into S x S.

    Out-of-image pixels use `pad_value`; default = per-channel median of the
    image border (a cheap "background-like colour", assumption A3).
    Uses cv2 affine warp with bilinear interpolation.
    """
    import cv2  # local import keeps the core maths importable without OpenCV

    if pad_value is None:
        border = np.concatenate([image[0], image[-1], image[:, 0], image[:, -1]], axis=0)
        pad_value = np.median(border, axis=0)
    pad_value = np.atleast_1d(pad_value).astype(np.float64)
    s = tf.scale
    # Pixel-centre convention: out = (in - origin) * s - 0.5
    M = np.array([[s, 0.0, -tf.x0 * s - 0.5],
                  [0.0, s, -tf.y0 * s - 0.5]], dtype=np.float64)
    border_val = tuple(float(v) for v in (np.resize(pad_value, 4)))
    return cv2.warpAffine(image, M, (tf.out_size, tf.out_size), flags=cv2.INTER_LINEAR,
                          borderMode=cv2.BORDER_CONSTANT, borderValue=border_val)
