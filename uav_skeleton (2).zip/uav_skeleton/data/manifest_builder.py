"""Build manifest.csv from an on-disk layout described by regex rules.

The real MMFW-UAV folder structure has NOT been inspected yet (run scripts/inspect_dataset.py
first). Nothing here hard-codes it: you describe the layout with rules, e.g.

  --rule rgb "wide/**/*.jpg"  "(?P<group>sortie\\d+)/.*?(?P<pair>\\d{6})\\.jpg"

Each rule = (modality, glob relative to root, regex applied with re.search to the relative POSIX
path). Named groups: `group` (required: the leakage unit), `pair` (optional: instant shared by the
RGB and IR file), `aircraft` (optional). Files whose path does not match the regex are reported,
never silently dropped.
"""
from __future__ import annotations

import glob
import os
import re
from typing import Dict, List, Optional, Sequence, Tuple

from data.fs_filter import is_junk_path
from data.bbox_parsers import parse_center_txt, parse_voc_xml, single_box
from data.manifest import ManifestRow


def build_manifest(root: str, rules: Sequence[Tuple[str, str, str]], bbox_template: Optional[str] = None,
                   bbox_format: str = "voc", read_sizes: bool = False) -> Tuple[List[ManifestRow], Dict[str, list]]:
    """Return (rows, problems). `bbox_template` is a root-relative path with {stem} and {group}."""
    rows: List[ManifestRow] = []
    problems: Dict[str, list] = {"unmatched": [], "no_bbox": [], "bad_bbox": []}
    used = set()
    for modality, pattern, regex in rules:
        rx = re.compile(regex)
        files = sorted(glob.glob(os.path.join(root, pattern), recursive=True))
        for f in files:
            if not os.path.isfile(f):
                continue
            rel = os.path.relpath(f, root).replace(os.sep, "/")
            if is_junk_path(rel):
                continue
            m = rx.search(rel)
            if not m or "group" not in m.groupdict():
                problems["unmatched"].append(rel)
                continue
            gd = m.groupdict()
            stem = os.path.splitext(os.path.basename(rel))[0]
            pair = gd.get("pair")
            sid = f"{modality}_{pair or stem}_{gd['group']}" if pair else f"{modality}_{gd['group']}_{stem}"
            if sid in used:
                sid = f"{sid}__{len(used)}"
            used.add(sid)
            width = height = None
            if read_sizes:
                import cv2
                im = cv2.imread(f, cv2.IMREAD_UNCHANGED)
                if im is None:
                    problems["bad_bbox"].append((rel, "unreadable image"))
                    continue
                height, width = im.shape[:2]
            bbox = None
            if bbox_template:
                bp = os.path.join(root, bbox_template.format(stem=stem, group=gd["group"]))
                if not os.path.isfile(bp):
                    problems["no_bbox"].append(rel)
                else:
                    try:
                        if bbox_format == "voc":
                            boxes, wh = parse_voc_xml(bp)
                            if wh and width is None:
                                width, height = wh
                        else:
                            boxes = parse_center_txt(bp, width, height)
                        bbox = single_box(boxes, bp)
                    except Exception as e:
                        problems["bad_bbox"].append((rel, str(e)))
            rows.append(ManifestRow(sid, rel, modality, gd["group"], pair, gd.get("aircraft"), None,
                                    width, height, bbox))
    return rows, problems
