"""Evidence-only audit of a real dataset folder: what files exist, what the annotation files actually contain, whether images and
annotations match, and whether the dataset carries keypoints or masks. It reports facts and never fills gaps: no labels are created,
and a bounding box is never treated as a keypoint. Used by scripts/audit_dataset.py (run on the machine that holds the data)."""
from __future__ import annotations

import json
import os
import re
import xml.etree.ElementTree as ET
from collections import Counter, defaultdict
from typing import Dict, List, Optional

from data.fs_filter import walk_clean

IMG_EXT = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff"}
GEOM_HINTS = ("keypoint", "point", "polygon", "segment", "mask", "skeleton", "landmark", "part")
KP_KEYS = ("keypoints", "num_keypoints", "skeleton", "landmarks")
MASK_KEYS = ("segmentation", "mask", "rle")


def inventory(root: str) -> dict:
    files: Dict[str, List[str]] = {"images": [], "xml": [], "json": [], "txt": [], "other": []}
    for dp, _, fn in walk_clean(root):
        for f in fn:
            rel = os.path.relpath(os.path.join(dp, f), root).replace(os.sep, "/")
            e = os.path.splitext(f)[1].lower()
            files["images" if e in IMG_EXT else "xml" if e == ".xml" else "json" if e == ".json" else "txt" if e == ".txt" else "other"].append(rel)
    return files


def _tag(e) -> str:
    return e.tag.split("}")[-1]


def _too_big(path: str, max_bytes: Optional[int]) -> Optional[str]:
    try:
        n = os.path.getsize(path)
    except OSError as e:
        return f"OSError: {e}"
    return f"skipped: {n/1e6:.1f} MB exceeds the {max_bytes/1e6:.0f} MB per-file limit" if max_bytes and n > max_bytes else None


def scan_xml(path: str, max_bytes: Optional[int] = None) -> dict:
    out = {"ok": False, "tag_paths": [], "filename": None, "size": None, "objects": [], "geometry_tags": []}
    big = _too_big(path, max_bytes)
    if big:
        out["error"], out["skipped"] = big, True
        return out
    try:
        root = ET.parse(path).getroot()
    except Exception as e:
        out["error"] = f"{type(e).__name__}: {e}"
        return out
    paths = set()

    def walk(e, pre):
        p = f"{pre}/{_tag(e)}"
        paths.add(p)
        for c in e:
            walk(c, p)
    walk(root, "")
    out["tag_paths"] = sorted(paths)
    out["filename"] = root.findtext("filename")
    sz = root.find("size")
    if sz is not None:
        try:
            out["size"] = [int(float(sz.findtext("width"))), int(float(sz.findtext("height"))), int(float(sz.findtext("depth") or 0))]
        except (TypeError, ValueError):
            out["size"] = None
    for o in root.iter("object"):
        bb = o.find("bndbox")
        box = None
        if bb is not None:
            try:
                box = [float(bb.findtext(k)) for k in ("xmin", "ymin", "xmax", "ymax")]
            except (TypeError, ValueError):
                box = None
        out["objects"].append({"name": o.findtext("name"), "box": box})
    out["geometry_tags"] = sorted({p for p in paths if any(h in p.lower() for h in GEOM_HINTS) and "bndbox" not in p.lower()})
    out["ok"] = True
    return out


def scan_json(path: str, max_bytes: Optional[int] = None) -> dict:
    out = {"ok": False}
    big = _too_big(path, max_bytes)
    if big:
        out["error"], out["skipped"] = big, True
        return out
    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            d = json.load(f)
    except (Exception, MemoryError, RecursionError) as e:
        out["error"] = f"{type(e).__name__}: {e}"
        return out
    out["ok"] = True
    out["top_type"] = type(d).__name__
    out["top_keys"] = sorted(d.keys()) if isinstance(d, dict) else []
    found_kp, found_mask, shape_types, labels = set(), set(), Counter(), Counter()

    def walk(x, depth=0):
        if depth > 8:
            return
        if isinstance(x, dict):
            for k, v in x.items():
                kl = k.lower()
                if kl in KP_KEYS:
                    found_kp.add(k)
                if kl in MASK_KEYS:
                    found_mask.add(k)
                if kl == "shape_type" and isinstance(v, str):
                    shape_types[v] += 1
                if kl in ("label", "name", "category_name") and isinstance(v, str):
                    labels[v] += 1
                walk(v, depth + 1)
        elif isinstance(x, list):
            for v in x[:2000]:
                walk(v, depth + 1)
    walk(d)
    out.update(keypoint_fields=sorted(found_kp), mask_fields=sorted(found_mask), shape_types=dict(shape_types),
               labels=dict(labels.most_common(20)))
    if isinstance(d, dict):
        out["dimensions"] = {k: d[k] for k in ("imageWidth", "imageHeight", "width", "height") if k in d}
        out["image_ref"] = d.get("imagePath") or d.get("filename") or d.get("image")
    return out


def image_size(path: str):
    try:
        from PIL import Image
        with Image.open(path) as im:
            return im.size, im.mode
    except Exception:
        return None, None



DEFAULT_LIMITS = {"max_xml": 300, "max_json": 300, "max_images": 300, "per_group": 25, "max_file_mb": 50}


def sample_even(items: List[str], k: Optional[int]) -> List[str]:
    """Deterministic, evenly spaced sample that always includes the first and last item."""
    if k is None or len(items) <= k:
        return list(items)
    if k <= 1:
        return list(items[:1])
    return [items[round(i * (len(items) - 1) / (k - 1))] for i in range(k)]


def select(files: List[str], per_group: Optional[int], cap: Optional[int]) -> List[str]:
    """Representative sample: up to `per_group` evenly spaced files from EACH directory (= viewpoint/sensor folder), then, if the
    total exceeds `cap`, a round-robin across directories so every directory stays represented."""
    groups: Dict[str, List[str]] = defaultdict(list)
    for f in sorted(files):
        groups[os.path.dirname(f)].append(f)
    picked = {g: sample_even(v, per_group) for g, v in groups.items()}
    flat = [f for g in sorted(picked) for f in picked[g]]
    if cap is None or len(flat) <= cap:
        return flat
    out, i = [], 0
    while len(out) < cap:
        progressed = False
        for g in sorted(picked):
            if i < len(picked[g]) and len(out) < cap:
                out.append(picked[g][i])
                progressed = True
        if not progressed:
            break
        i += 1
    return out


def audit(root: str, max_size_checks: int = 300, max_json: Optional[int] = None, *, max_xml: Optional[int] = None,
          max_images: Optional[int] = None, per_group: Optional[int] = None, max_file_mb: Optional[float] = None,
          exhaustive: bool = False, report: Optional[dict] = None, on_stage=None, progress=None) -> dict:
    """Stages: inventory -> xml -> json -> matching -> modality -> capabilities. Each stage is isolated (an exception is recorded under
    `stage_errors`, the audit continues) and `on_stage(name, report)` is called after each so a caller can save partial results.
    `report` is filled in place, so an interrupted run still leaves everything finished so far.
    Sampled checks (opening files) are limited; filename-based checks are exhaustive. The report says which is which."""
    L = dict(DEFAULT_LIMITS)
    for k, v in (("max_json", max_json), ("max_xml", max_xml), ("max_images", max_images), ("per_group", per_group), ("max_file_mb", max_file_mb)):
        if v is not None:
            L[k] = v
    if exhaustive:
        L.update(max_xml=None, max_json=None, max_images=None, per_group=None, max_file_mb=None)
        max_size_checks = None
    max_bytes = int(L["max_file_mb"] * 1e6) if L["max_file_mb"] else None
    say = progress or (lambda m: None)
    rep: dict = report if report is not None else {}
    rep.update(root=root, status="running", limits={**L, "max_size_checks": max_size_checks, "exhaustive": exhaustive},
               stage_errors={}, scope={})
    inv: dict = {}
    xml_info: dict = {}
    json_info: dict = {}

    def stage(name, fn):
        say(f"[{name}] start")
        try:
            fn()
        except KeyboardInterrupt:
            rep["status"] = f"interrupted during {name}"
            if on_stage:
                on_stage(name, rep)
            raise
        except Exception as e:
            rep["stage_errors"][name] = f"{type(e).__name__}: {e}"
            say(f"[{name}] FAILED, continuing: {rep['stage_errors'][name]}")
        say(f"[{name}] done")
        if on_stage:
            on_stage(name, rep)

    def scan_many(kind, files, fn, store):
        for n, rel in enumerate(files, 1):
            if n == 1 or n % 25 == 0 or n == len(files):
                say(f"[{kind}] {n}/{len(files)}  {rel}")
            store[rel] = fn(os.path.join(root, rel), max_bytes)

    def s_inventory():
        say("[inventory] walking the folder tree (names only, junk filtered) ...")
        inv.update(inventory(root))
        rep["counts"] = {k: len(v) for k, v in inv.items()}
        by_dir = defaultdict(Counter)
        for k in ("images", "xml", "json", "txt"):
            for rel in inv[k]:
                by_dir[os.path.dirname(rel)][k] += 1
        rep["per_directory"] = {d: dict(c) for d, c in sorted(by_dir.items())}
        rep["scope"]["inventory"] = "EXHAUSTIVE (file names only; ._*, __MACOSX, .DS_Store, Thumbs.db excluded before anything is opened)"

    def s_xml():
        sel = select(inv["xml"], L["per_group"], L["max_xml"])
        scan_many("xml", sel, scan_xml, xml_info)
        ok = [v for v in xml_info.values() if v["ok"]]
        rep["scope"]["xml_content"] = f"SAMPLED {len(sel)} of {len(inv['xml'])} XML files (up to {L['per_group']} evenly spaced per directory)"
        rep["xml"] = {"sampled": len(sel), "of_total": len(inv["xml"]), "parsed_ok": len(ok),
                      "failed": {r: v["error"] for r, v in xml_info.items() if not v["ok"]},
                      "tag_paths": sorted({p for v in ok for p in v["tag_paths"]}),
                      "object_names": dict(Counter(o["name"] for v in ok for o in v["objects"])),
                      "objects_per_file": dict(Counter(len(v["objects"]) for v in ok)),
                      "files_without_box": sum(1 for v in ok if not any(o["box"] for o in v["objects"])),
                      "geometry_tags_beyond_bndbox": sorted({t for v in ok for t in v["geometry_tags"]}),
                      "image_sizes_declared": {str(k): n for k, n in Counter(tuple(v["size"][:2]) if v["size"] else None for v in ok).most_common(10)},
                      "sampled_per_directory": dict(Counter(os.path.dirname(r) for r in xml_info))}

    def s_json():
        sel = select(inv["json"], L["per_group"], L["max_json"])
        scan_many("json", sel, scan_json, json_info)
        ok = {r: v for r, v in json_info.items() if v["ok"]}
        rep["scope"]["json_content"] = f"SAMPLED {len(sel)} of {len(inv['json'])} JSON files (up to {L['per_group']} evenly spaced per directory)"
        rep["json"] = {"sampled": len(sel), "of_total": len(inv["json"]), "parsed_ok": len(ok),
                       "failed": {r: v["error"] for r, v in json_info.items() if not v["ok"]},
                       "top_key_sets": {" | ".join(k): n for k, n in Counter(tuple(v.get("top_keys", [])) for v in ok.values()).most_common(5)},
                       "keypoint_fields": sorted({k for v in ok.values() for k in v.get("keypoint_fields", [])}),
                       "mask_fields": sorted({k for v in ok.values() for k in v.get("mask_fields", [])}),
                       "shape_types": dict(sum((Counter(v.get("shape_types", {})) for v in ok.values()), Counter())),
                       "labels": dict(sum((Counter(v.get("labels", {})) for v in ok.values()), Counter()).most_common(20)),
                       "examples": {r: {k: v for k, v in ok[r].items() if k != "ok"} for r in list(ok)[:3]},
                       "sampled_per_directory": dict(Counter(os.path.dirname(r) for r in json_info))}

    def s_matching():
        def stem(r):
            return os.path.splitext(os.path.basename(r))[0]
        stems: Dict[str, List[str]] = defaultdict(list)
        xs: Dict[str, List[str]] = defaultdict(list)
        js: Dict[str, List[str]] = defaultdict(list)
        for r in inv["images"]:
            stems[stem(r)].append(r)
        for r in inv["xml"]:
            xs[stem(r)].append(r)
        for r in inv["json"]:
            js[stem(r)].append(r)
        noann = [r for r in inv["images"] if stem(r) not in xs and stem(r) not in js]
        xml_noimg = [r for r in inv["xml"] if stem(r) not in stems]
        json_noimg = [r for r in inv["json"] if stem(r) not in stems]
        dup_img = {k: v for k, v in stems.items() if len(v) > 1}
        dup_xml = {k: v for k, v in xs.items() if len(v) > 1}
        m = {"scope": "EXHAUSTIVE for every count in this block except where a key says 'sampled' (filename matching opens no files)",
             "rule": "image stem == xml stem / json stem, anywhere in the tree; stems are NOT assumed unique",
             "images_with_xml": sum(1 for r in inv["images"] if stem(r) in xs),
             "images_with_json": sum(1 for r in inv["images"] if stem(r) in js),
             "images_with_neither": len(noann), "images_with_neither_examples": noann[:20],
             "xml_without_image": len(xml_noimg), "xml_without_image_examples": xml_noimg[:20],
             "json_without_image": len(json_noimg), "json_without_image_examples": json_noimg[:20],
             "duplicate_image_stems": len(dup_img), "duplicate_image_stem_examples": dict(list(dup_img.items())[:10]),
             "duplicate_xml_stems": len(dup_xml), "duplicate_xml_stem_examples": dict(list(dup_xml.items())[:10]),
             "image_xml_pairs_in_same_directory": sum(1 for r in inv["images"] for x in xs.get(stem(r), []) if os.path.dirname(x) == os.path.dirname(r))}
        name_mm, size_mm, checked = [], [], 0
        for x, info in xml_info.items():                       # SAMPLED: only XML files that were opened
            if not info["ok"]:
                continue
            imgs = stems.get(stem(x), [])
            if info["filename"] and imgs and stem(info["filename"]) != stem(x):
                name_mm.append({"xml": x, "xml_filename": info["filename"], "image": imgs[0]})
            if info["size"] and imgs and (max_size_checks is None or checked < max_size_checks):
                sz, _ = image_size(os.path.join(root, imgs[0]))
                checked += 1
                if sz and (sz[0], sz[1]) != tuple(info["size"][:2]):
                    size_mm.append({"xml": x, "xml_size": info["size"][:2], "image": imgs[0], "image_size": list(sz)})
        bad = {x for x, v in xml_info.items() if v["ok"] and v["size"] for o in v["objects"] if o["box"] and
               (o["box"][0] < 0 or o["box"][1] < 0 or o["box"][2] > v["size"][0] or o["box"][3] > v["size"][1] or o["box"][2] <= o["box"][0] or o["box"][3] <= o["box"][1])}
        m.update(sampled_xml_filename_vs_image_mismatch=len(name_mm), sampled_xml_filename_mismatch_examples=name_mm[:10],
                 sampled_size_checks_done=checked, sampled_size_mismatch=len(size_mm), sampled_size_mismatch_examples=size_mm[:10],
                 sampled_xml_with_invalid_box=len(bad), sampled_xml_opened=len(xml_info))
        rep["matching"] = m
        rep["scope"]["matching"] = "filename matching EXHAUSTIVE; XML-filename / image-size / box-validity checks SAMPLED (only opened XML files)"

    def s_modality():
        dirs: Dict[str, List[str]] = defaultdict(list)
        for rel in inv["images"]:
            dirs[os.path.dirname(rel)].append(rel)
        sel = set(select(inv["images"], min(L["per_group"] or 12, 12), L["max_images"]))
        ev = {}
        for n, (d, lst) in enumerate(sorted(dirs.items()), 1):
            sample = [r for r in lst if r in sel]
            say(f"[images] directory {n}/{len(dirs)}  {d or '.'}  ({len(sample)} sampled of {len(lst)})")
            sizes, grey = Counter(), 0
            for rel in sample:
                sz, mode = image_size(os.path.join(root, rel))
                sizes[str(sz)] += 1
                if mode in ("L", "I;16"):
                    grey += 1
                elif mode in ("RGB", "RGBA"):
                    try:
                        import numpy as np
                        from PIL import Image
                        a = np.asarray(Image.open(os.path.join(root, rel)).convert("RGB"))[::8, ::8].astype(int)
                        grey += int(abs(a[..., 0] - a[..., 1]).mean() < 2 and abs(a[..., 1] - a[..., 2]).mean() < 2)
                    except Exception:
                        pass
            ev[d] = {"n_images": len(lst), "sampled": len(sample), "sampled_sizes": dict(sizes), "sampled_looking_greyscale": grey,
                     "stem_examples": [os.path.basename(x) for x in lst[:3]]}
        rep["modality_evidence"] = ev
        dir_stems = {d: {os.path.splitext(os.path.basename(x))[0] for x in lst} for d, lst in dirs.items()}
        ds = sorted(dir_stems)
        rep["stem_overlap_between_image_directories"] = {f"{ds[i]}  <->  {ds[j]}": len(dir_stems[ds[i]] & dir_stems[ds[j]])
                                                          for i in range(len(ds)) for j in range(i + 1, len(ds)) if dir_stems[ds[i]] & dir_stems[ds[j]]}
        nums = Counter(bool(re.fullmatch(r"\d+", os.path.splitext(os.path.basename(r))[0])) for r in inv["images"])
        rep["stem_numeric_only"] = {"numeric_only": nums[True], "other": nums[False]}
        rep["scope"]["modality_evidence"] = "SAMPLED images (headers/pixels); overlap of file names between directories is EXHAUSTIVE. Evidence only - it does not establish RGB/IR pairing."

    def s_capabilities():
        ok_x = [v for v in xml_info.values() if v["ok"]]
        n_boxes = sum(1 for v in ok_x for o in v["objects"] if o["box"])
        kp = rep.get("json", {}).get("keypoint_fields", [])
        shapes = rep.get("json", {}).get("shape_types", {})
        geom = rep.get("xml", {}).get("geometry_tags_beyond_bndbox", [])
        mask = bool(rep.get("json", {}).get("mask_fields")) or any(t in ("polygon", "mask") for t in shapes)
        rep["capabilities"] = {
            "evidence_scope": f"derived ONLY from the {len(xml_info)} XML and {len(json_info)} JSON files actually opened (sampled); "
                              f"absence in unopened files is not excluded - rerun with --exhaustive to confirm",
            "bounding_boxes_in_sampled_xml": n_boxes,
            "supports_aircraft_detection_training": n_boxes > 0,
            "keypoint_fields_found_in_sampled_json": kp,
            "json_point_shape_types": {k: v for k, v in shapes.items() if "point" in k.lower()},
            "xml_geometry_tags_beyond_bndbox": geom,
            "mask_or_polygon_found": mask or bool(geom),
            "supports_structural_pose_training_as_is": bool(kp),
            "note": "A bounding box is never converted into a keypoint. If no keypoint fields are listed above, the six skeleton "
                    "keypoints (head, body, wings, tail joint, tail unit) and vulnerability regions must be annotated separately."}

    for name, fn in (("inventory", s_inventory), ("xml", lambda: s_xml()), ("json", lambda: s_json()), ("matching", s_matching),
                     ("modality", s_modality), ("capabilities", s_capabilities)):
        if name != "inventory" and not inv:
            rep["stage_errors"][name] = "skipped: inventory failed"
            continue
        stage(name, fn)
    rep["status"] = "complete" if not rep["stage_errors"] else "complete_with_stage_errors"
    if on_stage:
        on_stage("final", rep)
    return rep
