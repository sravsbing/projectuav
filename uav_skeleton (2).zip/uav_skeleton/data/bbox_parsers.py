"""Bounding-box annotation parsers for the two formats the MMFW-UAV article says it ships:
Pascal VOC (xmin, ymin, xmax, ymax) and MS-COCO-style (xc, yc, w, h).

The article does not say whether the (xc, yc, w, h) text files are normalised (YOLO style) or in
pixels, so `parse_center_txt` auto-detects (all four values <= 1.0 => normalised) unless told, and
callers must confirm against image size with the validator.

No +-1 pixel correction is applied to VOC's 1-based inclusive convention; the <=1 px effect is
negligible for targets tens to hundreds of pixels wide.
"""
from __future__ import annotations

import xml.etree.ElementTree as ET
from typing import List, Optional, Tuple

Box = Tuple[float, float, float, float]


def parse_voc_xml(path: str) -> Tuple[List[Box], Optional[Tuple[int, int]]]:
    root = ET.parse(path).getroot()
    size = root.find("size")
    wh = None
    if size is not None and size.findtext("width") and size.findtext("height"):
        wh = (int(float(size.findtext("width"))), int(float(size.findtext("height"))))
    boxes: List[Box] = []
    for obj in root.findall("object"):
        bb = obj.find("bndbox")
        if bb is None:
            continue
        boxes.append(tuple(float(bb.findtext(k)) for k in ("xmin", "ymin", "xmax", "ymax")))  # type: ignore
    return boxes, wh


def parse_center_txt(path: str, width: Optional[int] = None, height: Optional[int] = None,
                     normalized: Optional[bool] = None) -> List[Box]:
    """Lines: `[class] xc yc w h`. Returns boxes as pixel xyxy."""
    boxes: List[Box] = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            parts = line.split()
            if not parts:
                continue
            vals = [float(v) for v in parts[-4:]]
            if len(vals) != 4:
                raise ValueError(f"{path}: need 4 numbers per line, got {line!r}")
            norm = normalized if normalized is not None else all(0.0 <= v <= 1.0 for v in vals)
            xc, yc, w, h = vals
            if norm:
                if width is None or height is None:
                    raise ValueError(f"{path}: normalised box needs image width/height")
                xc, w, yc, h = xc * width, w * width, yc * height, h * height
            boxes.append((xc - w / 2, yc - h / 2, xc + w / 2, yc + h / 2))
    return boxes


def single_box(boxes: List[Box], source: str = "") -> Box:
    """The dataset has one UAV per image; anything else is a data problem to surface."""
    if len(boxes) != 1:
        raise ValueError(f"{source}: expected exactly 1 box, found {len(boxes)}")
    return boxes[0]
