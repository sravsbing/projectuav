"""Gaussian heatmap generation, hard decoding and differentiable soft-argmax.

All functions are batched torch ops and share the heatmap<->input coordinate
convention defined in data/transforms.py.
"""
from __future__ import annotations

import torch


def input_to_heatmap(xy_in: torch.Tensor, stride: float) -> torch.Tensor:
    return (xy_in + 0.5) / stride - 0.5


def heatmap_to_input(xy_hm: torch.Tensor, stride: float) -> torch.Tensor:
    return (xy_hm + 0.5) * stride - 0.5


def generate_heatmaps(kps_in: torch.Tensor, vis: torch.Tensor, heatmap_size: int,
                      input_size: int, sigma: float) -> torch.Tensor:
    """Ground-truth Gaussian heatmaps.

    kps_in : (B,K,2) keypoints in network-input pixel coords.
    vis    : (B,K) bool/0-1; invisible keypoints get an all-zero map.
    sigma  : Gaussian std in *heatmap* pixels.
    Returns (B,K,H,W) with peak value 1.0 at the keypoint (for sub-pixel
    positions the peak is <1 at the nearest cell, exactly 1 at the true centre).
    """
    B, K, _ = kps_in.shape
    stride = input_size / heatmap_size
    c = input_to_heatmap(kps_in, stride)  # (B,K,2) in heatmap coords
    xs = torch.arange(heatmap_size, dtype=kps_in.dtype, device=kps_in.device)
    dx2 = (xs.view(1, 1, 1, -1) - c[..., 0].view(B, K, 1, 1)) ** 2   # (B,K,1,W)
    dy2 = (xs.view(1, 1, -1, 1) - c[..., 1].view(B, K, 1, 1)) ** 2   # (B,K,H,1)
    hm = torch.exp(-(dx2 + dy2) / (2.0 * sigma ** 2))
    return hm * vis.to(hm.dtype).view(B, K, 1, 1)


def soft_argmax(heatmaps: torch.Tensor, beta: float = 100.0) -> torch.Tensor:
    """Differentiable keypoint coords in *heatmap* coords, (B,K,2) as (x,y).

    softmax over the H*W cells with inverse temperature `beta`, then the
    expectation of the cell indices. beta is a documented hyper-parameter
    (assumption A6); heatmaps have peak ~1, so beta~100 gives a sharp softmax.
    """
    B, K, H, W = heatmaps.shape
    p = torch.softmax(beta * heatmaps.reshape(B, K, H * W), dim=-1).reshape(B, K, H, W)
    xs = torch.arange(W, dtype=heatmaps.dtype, device=heatmaps.device)
    ys = torch.arange(H, dtype=heatmaps.dtype, device=heatmaps.device)
    x = (p.sum(dim=2) * xs).sum(dim=-1)
    y = (p.sum(dim=3) * ys).sum(dim=-1)
    return torch.stack([x, y], dim=-1)


def decode_argmax(heatmaps: torch.Tensor, refine: bool = True):
    """Hard decode (non-differentiable) for inference.

    Returns (coords (B,K,2) in heatmap coords, conf (B,K) peak value).
    `refine` applies the usual 0.25-cell shift toward the higher neighbour.
    """
    B, K, H, W = heatmaps.shape
    flat = heatmaps.reshape(B, K, H * W)
    conf, idx = flat.max(dim=-1)
    x = (idx % W).to(heatmaps.dtype)
    y = (idx // W).to(heatmaps.dtype)
    if refine:
        xi, yi = x.long(), y.long()
        bi = torch.arange(B, device=heatmaps.device).view(B, 1).expand(B, K)
        ki = torch.arange(K, device=heatmaps.device).view(1, K).expand(B, K)

        def at(yy, xx):
            return heatmaps[bi, ki, yy.clamp(0, H - 1), xx.clamp(0, W - 1)]

        x = x + 0.25 * torch.sign(at(yi, xi + 1) - at(yi, xi - 1))
        y = y + 0.25 * torch.sign(at(yi + 1, xi) - at(yi - 1, xi))
    return torch.stack([x, y], dim=-1), conf


def heatmap_coords_to_normalized(xy_hm: torch.Tensor, stride: float, input_size: int) -> torch.Tensor:
    """Heatmap coords -> normalised [0,1] coords: x_norm = (x_in + 0.5) / S."""
    return (heatmap_to_input(xy_hm, stride) + 0.5) / input_size
