"""Leakage-free train/val/test splits.

Unit of assignment = `group_id` (a flight sortie / continuous sequence), never an individual frame:
neighbouring video frames are near-duplicates, so frame-level splits inflate test scores. RGB/IR
pairs share a group (validated in data.manifest), so a pair can never straddle splits, and the
IR test set is disjoint from the RGB training set at group level.

Groups are stratified by aircraft_id; an aircraft with >=3 groups is guaranteed to appear in every
split (so ratios are only approximate when groups are few). With fewer groups, `split_report` says
exactly which aircraft is missing from which split. NOTE: if MMFW-UAV has only a handful of sorties
per aircraft, sortie-level splitting gives coarse ratios; finer leakage-safe groups (e.g. temporal
blocks of a sortie separated by a gap) would then be needed - a decision for the data owner.
"""
from __future__ import annotations

import json
import random
from collections import defaultdict
from typing import Dict, List, Sequence

from data.manifest import ManifestRow

SPLITS = ("train", "val", "test")


def group_split(rows: Sequence[ManifestRow], fractions=(0.7, 0.1, 0.2), seed: int = 42) -> Dict[str, List[str]]:
    if abs(sum(fractions) - 1.0) > 1e-6 or len(fractions) != 3:
        raise ValueError("fractions must be 3 numbers summing to 1")
    groups: Dict[str, List[ManifestRow]] = defaultdict(list)
    for r in rows:
        groups[r.group_id].append(r)
    strata: Dict[str, List[str]] = defaultdict(list)
    for gid, rs in groups.items():
        ac = {r.aircraft_id for r in rs}
        strata[next(iter(ac)) or "unknown" if len(ac) == 1 else "mixed"].append(gid)

    rng = random.Random(seed)
    assign: Dict[str, str] = {}
    for stratum in sorted(strata):
        gids = sorted(strata[stratum])
        rng.shuffle(gids)                                        # random tie-break ...
        gids.sort(key=lambda g: -len(groups[g]))                 # ... then largest-first (stable)
        total = sum(len(groups[g]) for g in gids)
        got = {s: 0 for s in SPLITS}
        # Representation guarantee: with >=3 groups, seed one group per (non-zero-fraction) split first,
        # largest group -> largest fraction, so a small val fraction cannot round to an empty split.
        order = sorted((i for i in range(3) if fractions[i] > 0), key=lambda i: -fractions[i])
        seeded = gids[:len(order)] if len(gids) >= 3 else []
        for g, i in zip(seeded, order):
            assign[g] = SPLITS[i]
            got[SPLITS[i]] += len(groups[g])
        for g in gids[len(seeded):]:
            deficit = {s: fractions[i] * total - got[s] for i, s in enumerate(SPLITS)}
            s = max(SPLITS, key=lambda k: (deficit[k], -SPLITS.index(k)))
            assign[g] = s
            got[s] += len(groups[g])
    out = {s: [] for s in SPLITS}
    for r in rows:
        out[assign[r.group_id]].append(r.sample_id)
    for s in SPLITS:
        out[s].sort()
    return out


def verify_no_leakage(split_ids: Dict[str, List[str]], rows: Sequence[ManifestRow]) -> None:
    """Raise AssertionError on any sample/group/pair shared between splits."""
    by_id = {r.sample_id: r for r in rows}
    owner_group: Dict[str, str] = {}
    owner_pair: Dict[str, str] = {}
    seen = {}
    for s in SPLITS:
        for sid in split_ids.get(s, []):
            assert sid in by_id, f"unknown sample {sid} in split {s}"
            assert sid not in seen, f"sample {sid} in both {seen[sid]} and {s}"
            seen[sid] = s
            r = by_id[sid]
            assert owner_group.setdefault(r.group_id, s) == s, f"group {r.group_id} spans splits (leak)"
            if r.pair_id:
                assert owner_pair.setdefault(r.pair_id, s) == s, f"pair {r.pair_id} spans splits (leak)"


def split_report(split_ids: Dict[str, List[str]], rows: Sequence[ManifestRow]) -> dict:
    by_id = {r.sample_id: r for r in rows}
    rep: dict = {"counts": {}, "groups": {}, "by_modality": {}, "by_aircraft": {}, "warnings": []}
    aircraft = sorted({r.aircraft_id or "unknown" for r in rows})
    for s in SPLITS:
        rs = [by_id[i] for i in split_ids.get(s, [])]
        rep["counts"][s] = len(rs)
        rep["groups"][s] = len({r.group_id for r in rs})
        rep["by_modality"][s] = {m: sum(r.modality == m for r in rs) for m in ("rgb", "ir")}
        rep["by_aircraft"][s] = {a: sum((r.aircraft_id or "unknown") == a for r in rs) for a in aircraft}
        for a in aircraft:
            if rep["by_aircraft"][s][a] == 0:
                rep["warnings"].append(f"aircraft {a!r} has no samples in {s}")
        if not rs:
            rep["warnings"].append(f"split {s} is empty")
    return rep


def save_splits(path: str, split_ids: Dict[str, List[str]], meta: dict) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump({"meta": meta, "splits": split_ids}, f, indent=1)


def load_splits(path: str) -> Dict[str, List[str]]:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)["splits"]
