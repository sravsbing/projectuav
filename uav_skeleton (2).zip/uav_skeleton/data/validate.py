"""Whole-dataset validation: manifest + annotations + region masks + splits -> one report dict."""
from __future__ import annotations

import os
from collections import Counter
from typing import Dict, Optional

import numpy as np

from data.annotations import read_annotations, validate_annotation
from data.manifest import pairs, read_manifest, validate_manifest
from data.regions import load_region_labels
from data.splits import load_splits, split_report, verify_no_leakage


def validate_dataset(root: str, manifest_path: str, annotations_path: Optional[str] = None,
                     splits_path: Optional[str] = None, check_images: int = 0) -> Dict[str, object]:
    errors, warnings = [], []
    rows = read_manifest(manifest_path)
    e, w = validate_manifest(rows, root)
    errors += e
    warnings += w
    by_id = {r.sample_id: r for r in rows}
    rep: Dict[str, object] = {
        "n_samples": len(rows), "n_groups": len({r.group_id for r in rows}),
        "by_modality": dict(Counter(r.modality for r in rows)),
        "by_aircraft": dict(Counter(r.aircraft_id or "unknown" for r in rows)),
        "n_pairs_complete": sum(len(d) == 2 for d in pairs(rows).values()),
        "n_with_bbox": sum(r.bbox is not None for r in rows),
    }
    if check_images:
        import cv2
        for r in rows[:check_images]:
            im = cv2.imread(os.path.join(root, r.image_path), cv2.IMREAD_UNCHANGED)
            if im is None:
                errors.append(f"{r.sample_id}: image unreadable")
            elif r.width and r.height and (im.shape[1], im.shape[0]) != (r.width, r.height):
                errors.append(f"{r.sample_id}: manifest size {r.width}x{r.height} != file {im.shape[1]}x{im.shape[0]}")
        rep["images_decoded"] = min(check_images, len(rows))

    anns = {}
    if annotations_path:
        anns = read_annotations(annotations_path)
        for sid, a in anns.items():
            if sid not in by_id:
                errors.append(f"annotation for unknown sample {sid}")
                continue
            r = by_id[sid]
            ae, aw = validate_annotation(a, r.width, r.height, r.bbox)
            errors += [f"{sid}: {x}" for x in ae]
            warnings += [f"{sid}: {x}" for x in aw]
            if a.region_mask:
                p = os.path.join(root, a.region_mask)
                if not os.path.isfile(p):
                    errors.append(f"{sid}: region mask missing {a.region_mask}")
                elif check_images:
                    lab = load_region_labels(p)
                    if lab.max() > 6:
                        errors.append(f"{sid}: region label > 6")
                    if r.width and r.height and lab.shape != (r.height, r.width):
                        errors.append(f"{sid}: region mask size {lab.shape[::-1]} != image {r.width}x{r.height}")
        rep["annotations"] = {
            "n": len(anns), "coverage": round(len(anns) / max(len(rows), 1), 4),
            "difficulty": dict(Counter(a.difficulty or "unset" for a in anns.values())),
            "with_region_mask": sum(bool(a.region_mask) for a in anns.values()),
            "per_keypoint_labelled": np.sum([a.visibility for a in anns.values()], axis=0).astype(int).tolist()
            if anns else [],
        }
        # Diagnostic only: do RGB and IR labels of the same instant agree? (tells whether labels could be
        # shared across modalities - we never assume alignment)
        dists = []
        for d in pairs(rows).values():
            if "rgb" in d and "ir" in d and d["rgb"].sample_id in anns and d["ir"].sample_id in anns:
                a, b = anns[d["rgb"].sample_id], anns[d["ir"].sample_id]
                both = a.visibility.astype(bool) & b.visibility.astype(bool)
                if both.any():
                    dists.append(float(np.linalg.norm(a.keypoints[both] - b.keypoints[both], axis=1).mean()))
        if dists:
            rep["rgb_ir_label_offset_px"] = {"n_pairs": len(dists), "mean": round(float(np.mean(dists)), 2),
                                             "max": round(float(np.max(dists)), 2)}

    if splits_path:
        sp = load_splits(splits_path)
        try:
            verify_no_leakage(sp, rows)
        except AssertionError as ex:
            errors.append(f"split leakage: {ex}")
        sr = split_report(sp, rows)
        rep["splits"] = sr
        warnings += [f"splits: {x}" for x in sr["warnings"]]
        if anns:
            rep["annotated_per_split"] = {s: sum(i in anns for i in ids) for s, ids in sp.items()}

    rep["errors"], rep["warnings"] = errors, warnings
    rep["ok"] = not errors
    return rep
