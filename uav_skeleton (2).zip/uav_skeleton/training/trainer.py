"""Training loop shared by every experiment: PG-VDNet, SG-VDNet, point-MSE ablation, RGB pretraining,
IR from scratch and RGB->IR transfer. What differs between experiments is ONLY the config.

Protocol guarantees (reproducibility requirements, task section 8):
  * the TEST split is never read here - only `train` and `val` (model selection uses val only);
  * seeds, hyper-parameters, loss weights and paths all come from the resolved config, which is saved
    next to the logs; environment info (torch, device, thread count) is saved too;
  * checkpoints are written atomically (best.pt chosen on val, last.pt for resume).
"""
from __future__ import annotations

import json
import math
import os
import time
from typing import Dict, Optional, Tuple

import torch
import yaml
from torch.utils.data import DataLoader

from data.annotations import read_annotations
from data.dataset import SkeletonDataset
from data.heatmaps import heatmap_coords_to_normalized, soft_argmax
from data.manifest import read_manifest
from data.splits import load_splits
from evaluation.keypoint_error import keypoint_errors, summarize_errors
from losses.heatmap_loss import masked_heatmap_mse, masked_point_mse
from losses.structural import structural_geometric_loss, total_loss
from models.postprocess import decode_batch_original, inputs_to_original_torch
from models.vdnet import VDNet, build_model
from training.config import resolve_paths, validate_config
from training.utils import (environment_info, load_checkpoint, load_weights, save_checkpoint, set_seed,
                            worker_init_fn)


# ----------------------------------------------------------------------------------------------
# loss
# ----------------------------------------------------------------------------------------------
def compute_loss(model, out: torch.Tensor, batch: dict, cfg: dict,
                 sg_scale: float = 1.0) -> Tuple[torch.Tensor, Dict[str, torch.Tensor]]:
    """Returns (total, parts). parts always contains l_main, l_sg (value logged even when weight is 0)
    and sg_weight_used. Loss type was validated against the architecture in training.config.
    `sg_scale` in [0,1] multiplies the SGL weight (warm-up; 1.0 = paper-faithful constant weight)."""
    lc, S = cfg["loss"], cfg["model"]["input_size"]
    vis = batch["visibility"]
    if model.output_type == "points":
        l_main = masked_point_mse(out, batch["keypoints_norm"], vis)
        coords = out
        sg_w = 0.0
    else:
        l_main = masked_heatmap_mse(out, batch["heatmaps"], vis, lc["hm_loss_scale"])
        coords = heatmap_coords_to_normalized(soft_argmax(out, cfg["heatmap"]["softargmax_beta"]),
                                              S / out.shape[-1], S)
        sg_w = float(lc["sg_weight"]) * sg_scale if lc["type"] == "heatmap_mse_sgl" else 0.0
    if sg_w > 0:
        l_sg = structural_geometric_loss(coords, vis, lc["sgl_normalize_vectors"])
    else:
        with torch.no_grad():
            l_sg = structural_geometric_loss(coords.detach(), vis, lc["sgl_normalize_vectors"])
    return total_loss(l_main, l_sg, sg_w), {"l_main": l_main.detach(), "l_sg": l_sg.detach(),
                                            "sg_weight_used": torch.tensor(sg_w)}


# ----------------------------------------------------------------------------------------------
# data / model construction
# ----------------------------------------------------------------------------------------------
def build_datasets(cfg: dict) -> Tuple[SkeletonDataset, SkeletonDataset]:
    d, m, h = cfg["data"], cfg["model"], cfg["heatmap"]
    rows = read_manifest(d["manifest"])
    anns = read_annotations(d["annotations"])
    splits = load_splits(d["splits"])
    common = dict(root=d["root"], rows=rows, annotations=anns, modality=d["modality"],
                  input_size=m["input_size"], heatmap_size=VDNet.heatmap_size(m["input_size"]),
                  sigma=h["sigma"], margin=d["margin"], seed=cfg["seed"])
    tr = SkeletonDataset(sample_ids=splits["train"], box_jitter=cfg["train"]["box_jitter"],
                         hflip_prob=cfg["train"]["hflip_prob"], **common)
    va = SkeletonDataset(sample_ids=splits["val"], **common)      # no augmentation, GT-box crops
    if len(tr) == 0 or len(va) == 0:
        raise RuntimeError(f"empty split after filtering to annotated {d['modality']} samples: "
                           f"train={len(tr)} val={len(va)}")
    return tr, va


def build_optimizer(cfg: dict, params):
    t = cfg["train"]
    if t["optimizer"] == "adam":
        return torch.optim.Adam(params, lr=t["lr"], weight_decay=t["weight_decay"])
    if t["optimizer"] == "adamw":
        return torch.optim.AdamW(params, lr=t["lr"], weight_decay=t["weight_decay"])
    return torch.optim.SGD(params, lr=t["lr"], momentum=0.9, weight_decay=t["weight_decay"])


def prepare_model(cfg: dict, device: torch.device):
    m, tr = cfg["model"], cfg["transfer"]
    model = build_model(m["arch"], m["pretrained_backbone"], m["deconv_channels"])
    init_info = None
    if tr["init_from"]:
        ck = load_weights(model, tr["init_from"], expect_arch=model.name)
        init_info = {"path": tr["init_from"], "epoch": ck.get("epoch"), "metrics": ck.get("metrics")}
    if tr["freeze_backbone"]:
        model.set_trainable(tr["trainable"])
    if not model.trainable_parameters():
        raise RuntimeError("no trainable parameters after applying transfer.trainable")
    return model.to(device), init_info


# ----------------------------------------------------------------------------------------------
# epochs
# ----------------------------------------------------------------------------------------------
def _to_device(batch: dict, device) -> dict:
    return {k: (v.to(device) if torch.is_tensor(v) else v) for k, v in batch.items()}


def train_one_epoch(model, loader, optimizer, cfg, device, sg_scale: float = 1.0) -> dict:
    model.train()
    sums, n = {"loss": 0.0, "l_main": 0.0, "l_sg": 0.0}, 0
    clip = cfg["train"]["grad_clip"]
    for batch in loader:
        batch = _to_device(batch, device)
        out = model(batch["image"])
        loss, parts = compute_loss(model, out, batch, cfg, sg_scale)
        if not torch.isfinite(loss):
            raise FloatingPointError(f"non-finite loss {loss.item()} (check lr / loss scale)")
        optimizer.zero_grad(set_to_none=True)
        loss.backward()
        if clip:
            torch.nn.utils.clip_grad_norm_(model.trainable_parameters(), clip)
        optimizer.step()
        b = out.shape[0]
        n += b
        sums["loss"] += loss.item() * b
        sums["l_main"] += parts["l_main"].item() * b
        sums["l_sg"] += parts["l_sg"].item() * b
    return {f"train_{k}": v / max(n, 1) for k, v in sums.items()}


@torch.no_grad()
def evaluate(model, loader, cfg, device) -> dict:
    """Validation loss + mean keypoint error in ORIGINAL-image pixels (GT-box crops)."""
    model.eval()
    S = cfg["model"]["input_size"]
    tot, n, errs = 0.0, 0, []
    for batch in loader:
        batch = _to_device(batch, device)
        out = model(batch["image"])
        loss, _ = compute_loss(model, out, batch, cfg)
        pred_o, _, _ = decode_batch_original(out.double(), batch["crop"], S, model.output_type)
        gt_o = inputs_to_original_torch(batch["keypoints_in"].double(), batch["crop"], S)
        errs.append(keypoint_errors(pred_o, gt_o, batch["visibility"]))
        b = out.shape[0]
        n += b
        tot += loss.item() * b
    s = summarize_errors(torch.cat(errs))
    return {"val_loss": tot / max(n, 1), "val_kp_error_px": s["mean"], "val_kp_error_per_keypoint_px": s["per_keypoint"]}


# ----------------------------------------------------------------------------------------------
# main entry
# ----------------------------------------------------------------------------------------------
def run_training(cfg: dict, device: Optional[str] = None, verbose: bool = True) -> dict:
    validate_config(cfg)
    resolve_paths(cfg)
    dev = torch.device(device or ("cuda" if torch.cuda.is_available() else "cpu"))
    set_seed(cfg["seed"], cfg["deterministic"])
    run = cfg["run"]
    log_dir, ckpt_dir = os.path.join(run["log_dir"], run["name"]), os.path.join(run["ckpt_dir"], run["name"])
    os.makedirs(log_dir, exist_ok=True)
    os.makedirs(ckpt_dir, exist_ok=True)

    train_ds, val_ds = build_datasets(cfg)
    g = torch.Generator()
    g.manual_seed(cfg["seed"])
    t = cfg["train"]
    train_loader = DataLoader(train_ds, batch_size=t["batch_size"], shuffle=True, drop_last=False, generator=g,
                              num_workers=t["num_workers"], worker_init_fn=worker_init_fn(cfg["seed"]),
                              pin_memory=dev.type == "cuda")
    val_loader = DataLoader(val_ds, batch_size=t["batch_size"], shuffle=False, num_workers=t["num_workers"],
                            pin_memory=dev.type == "cuda")

    model, init_info = prepare_model(cfg, dev)
    optimizer = build_optimizer(cfg, model.trainable_parameters())
    scheduler = (torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=t["epochs"])
                 if t["scheduler"] == "cosine" else None)

    start_epoch, best = 0, {"value": math.inf, "epoch": -1}
    if t["resume"]:
        ck = load_checkpoint(t["resume"], map_location=dev)
        model.load_state_dict(ck["model"])
        optimizer.load_state_dict(ck["optimizer"])
        if scheduler is not None and "scheduler" in ck:
            scheduler.load_state_dict(ck["scheduler"])
        start_epoch, best = ck["epoch"] + 1, ck.get("best", best)
        model._refresh_frozen_bn()

    counts = model.count_parameters()
    env = environment_info(dev)
    env.update({"n_train": len(train_ds), "n_val": len(val_ds), "params": counts, "init_from": init_info,
                "splits_used": ["train", "val"], "seed": cfg["seed"]})
    with open(os.path.join(log_dir, "config.yaml"), "w") as f:
        yaml.safe_dump(cfg, f, sort_keys=False)
    with open(os.path.join(log_dir, "env.json"), "w") as f:
        json.dump(env, f, indent=1, default=str)
    if verbose:
        print(f"[{run['name']}] {model.name} | train={len(train_ds)} val={len(val_ds)} | device={dev} | "
              f"params total={counts['total']:,} trainable={counts['trainable']:,}", flush=True)

    metrics_path = os.path.join(log_dir, "metrics.jsonl")
    if start_epoch == 0 and os.path.exists(metrics_path):
        os.remove(metrics_path)
    key = t["select_on"]
    history = []
    for epoch in range(start_epoch, t["epochs"]):
        t0 = time.time()
        train_ds.set_epoch(epoch)
        warm = cfg["loss"]["sg_warmup_epochs"]
        sg_scale = 1.0 if warm <= 0 else min(1.0, epoch / warm)      # 0 at epoch 0 -> full weight at `warm`
        tr_m = train_one_epoch(model, train_loader, optimizer, cfg, dev, sg_scale)
        va_m = evaluate(model, val_loader, cfg, dev)
        lr = optimizer.param_groups[0]["lr"]
        if scheduler is not None:
            scheduler.step()
        rec = {"epoch": epoch, "lr": lr, "sg_scale": sg_scale, "seconds": round(time.time() - t0, 2), **tr_m, **va_m}
        history.append(rec)
        with open(metrics_path, "a") as f:
            f.write(json.dumps(rec) + "\n")
        score = va_m[key]
        improved = score < best["value"]
        if improved:
            best = {"value": score, "epoch": epoch}
            save_checkpoint(os.path.join(ckpt_dir, "best.pt"), model, cfg, epoch, rec)
        save_checkpoint(os.path.join(ckpt_dir, "last.pt"), model, cfg, epoch, rec, optimizer, scheduler,
                        extra={"best": best})
        if verbose:
            print(f"  ep {epoch:3d} loss {tr_m['train_loss']:.5f} (main {tr_m['train_l_main']:.5f} "
                  f"sg {tr_m['train_l_sg']:.5f}) | val {key}={score:.4f}{' *' if improved else ''} | "
                  f"{rec['seconds']}s", flush=True)

    return {"run": run["name"], "best_epoch": best["epoch"], "best_value": best["value"], "select_on": key,
            "best_ckpt": os.path.join(ckpt_dir, "best.pt"), "last_ckpt": os.path.join(ckpt_dir, "last.pt"),
            "log_dir": log_dir, "history": history, "params": counts, "splits_used": ["train", "val"]}
