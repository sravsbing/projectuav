"""YAML config loading, dotted CLI overrides, and validation. Unknown keys are errors, not ignored."""
from __future__ import annotations

import copy
import os
import re
from typing import Any, Dict, Iterable, Optional

import yaml

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEFAULT_CONFIG = os.path.join(ROOT, "configs", "default.yaml")

LOSS_TYPES = ("point_mse", "heatmap_mse", "heatmap_mse_sgl")
ARCHS = ("sg_vdnet", "pg_vdnet", "point_net")


def _fix_numbers(x):
    """Recursively turn YAML-1.1 numeric strings like '3e-4' into floats (see parse_value)."""
    if isinstance(x, dict):
        return {k: _fix_numbers(v) for k, v in x.items()}
    if isinstance(x, list):
        return [_fix_numbers(v) for v in x]
    if isinstance(x, str) and _NUM.match(x.strip()):
        return float(x)
    return x


def _load_yaml(path: str) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return _fix_numbers(yaml.safe_load(f) or {})


def _merge(base: dict, new: dict, path: str = "") -> dict:
    for k, v in new.items():
        if k not in base:
            raise KeyError(f"unknown config key {path}{k!r}")
        if isinstance(base[k], dict) and isinstance(v, dict):
            _merge(base[k], v, f"{path}{k}.")
        else:
            base[k] = v
    return base


_NUM = re.compile(r"^[+-]?(\d+\.?\d*|\.\d+)([eE][+-]?\d+)?$")


def parse_value(raw: str):
    """YAML value, except that PyYAML (YAML 1.1) reads `3e-4` as the STRING '3e-4' - treat any plain
    decimal/scientific number as a number so `train.lr=3e-4` means what it says."""
    v = yaml.safe_load(raw)
    if isinstance(v, str) and _NUM.match(v.strip()):
        return float(v)
    return v


def apply_overrides(cfg: dict, overrides: Iterable[str]) -> dict:
    """overrides like 'train.lr=3e-4', 'transfer.trainable=[head,backbone.layer4]', 'data.splits=null'."""
    for item in overrides:
        if "=" not in item:
            raise ValueError(f"override {item!r} must look like key.sub=value")
        key, raw = item.split("=", 1)
        node = cfg
        parts = key.split(".")
        for p in parts[:-1]:
            if p not in node or not isinstance(node[p], dict):
                raise KeyError(f"unknown config key {key!r}")
            node = node[p]
        if parts[-1] not in node:
            raise KeyError(f"unknown config key {key!r}")
        node[parts[-1]] = parse_value(raw)
    return cfg


def load_config(path: Optional[str] = None, overrides: Iterable[str] = ()) -> dict:
    cfg = _load_yaml(DEFAULT_CONFIG)
    if path and os.path.abspath(path) != DEFAULT_CONFIG:
        _merge(cfg, _load_yaml(path))
    apply_overrides(cfg, overrides)
    validate_config(cfg)
    return cfg


def validate_config(cfg: dict) -> None:
    m, l, t, tr = cfg["model"], cfg["loss"], cfg["train"], cfg["transfer"]
    if m["arch"] not in ARCHS:
        raise ValueError(f"model.arch {m['arch']!r} not in {ARCHS}")
    if l["type"] not in LOSS_TYPES:
        raise ValueError(f"loss.type {l['type']!r} not in {LOSS_TYPES}")
    if m["input_size"] % 32:
        raise ValueError("model.input_size must be a multiple of 32")
    # The architecture name must say what was trained: PG-VDNet never uses SGL, point_net only point MSE.
    if l["type"] == "point_mse" and m["arch"] != "point_net":
        raise ValueError("loss.type=point_mse requires model.arch=point_net (direct regression)")
    if m["arch"] == "point_net" and l["type"] != "point_mse":
        raise ValueError("model.arch=point_net requires loss.type=point_mse")
    if m["arch"] == "pg_vdnet" and l["type"] == "heatmap_mse_sgl":
        raise ValueError("pg_vdnet is the baseline WITHOUT the structural loss; use sg_vdnet for heatmap_mse_sgl")
    if l["sg_warmup_epochs"] < 0:
        raise ValueError("loss.sg_warmup_epochs must be >= 0")
    if l["type"] == "heatmap_mse_sgl" and not l["sg_weight"] > 0:
        raise ValueError("loss.type=heatmap_mse_sgl needs loss.sg_weight > 0")
    if cfg["data"]["modality"] not in ("rgb", "ir", None):
        raise ValueError("data.modality must be rgb, ir or null")
    if t["select_on"] not in ("val_kp_error_px", "val_loss"):
        raise ValueError("train.select_on must be val_kp_error_px or val_loss")
    if t["optimizer"] not in ("adam", "adamw", "sgd") or t["scheduler"] not in ("none", "cosine"):
        raise ValueError("bad train.optimizer / train.scheduler")
    if tr["freeze_backbone"] and not tr["trainable"]:
        raise ValueError("transfer.freeze_backbone=true needs a non-empty transfer.trainable list")


def resolve_paths(cfg: dict) -> dict:
    d = cfg["data"]
    root = d["root"]
    d["manifest"] = d["manifest"] or os.path.join(root, "manifest.csv")
    d["annotations"] = d["annotations"] or os.path.join(root, "annotations.jsonl")
    d["splits"] = d["splits"] or os.path.join(root, "splits.json")
    return cfg


def deepcopy_cfg(cfg: dict) -> dict:
    return copy.deepcopy(cfg)
