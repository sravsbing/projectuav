"""Seeding, checkpoint I/O and environment capture."""
from __future__ import annotations

import os
import platform
import random
import sys
from typing import Optional

import numpy as np
import torch


def set_seed(seed: int, deterministic: bool = False) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    if deterministic:
        torch.use_deterministic_algorithms(True, warn_only=True)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False


def worker_init_fn(base_seed: int):
    def _init(worker_id: int):
        s = base_seed + worker_id
        random.seed(s)
        np.random.seed(s)
        torch.manual_seed(s)
    return _init


def save_checkpoint(path: str, model, cfg: dict, epoch: int, metrics: dict, optimizer=None, scheduler=None,
                    extra: Optional[dict] = None) -> None:
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    ck = {"model": model.state_dict(), "arch": model.name, "cfg": cfg, "epoch": epoch, "metrics": metrics,
          "torch": torch.__version__}
    if optimizer is not None:
        ck["optimizer"] = optimizer.state_dict()
    if scheduler is not None:
        ck["scheduler"] = scheduler.state_dict()
    if extra:
        ck.update(extra)
    tmp = path + ".tmp"
    torch.save(ck, tmp)
    os.replace(tmp, path)          # a crash mid-save can never leave a half-written checkpoint


def load_checkpoint(path: str, map_location="cpu") -> dict:
    return torch.load(path, map_location=map_location, weights_only=False)


def load_weights(model, path: str, expect_arch: Optional[str] = None, strict: bool = True) -> dict:
    ck = load_checkpoint(path)
    if expect_arch and ck.get("arch") != expect_arch:
        raise ValueError(f"checkpoint arch {ck.get('arch')!r} != model arch {expect_arch!r}")
    model.load_state_dict(ck["model"], strict=strict)
    return ck


def environment_info(device: torch.device) -> dict:
    info = {"python": sys.version.split()[0], "platform": platform.platform(), "torch": torch.__version__,
            "device": str(device), "cpu_threads": torch.get_num_threads()}
    if device.type == "cuda":
        info["gpu"] = torch.cuda.get_device_name(device)
        info["cuda"] = torch.version.cuda
    try:
        import torchvision
        info["torchvision"] = torchvision.__version__
    except Exception:
        pass
    return info
