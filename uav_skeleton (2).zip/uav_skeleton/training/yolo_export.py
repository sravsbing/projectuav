"""Export manifest boxes + group splits to the Ultralytics YOLO dataset layout (single class).

  out_dir/images/{train,val,test}/<sample_id>.<ext>   (symlinks, copy fallback)
  out_dir/labels/{train,val,test}/<sample_id>.txt     "0 xc yc w h" normalised
  out_dir/data.yaml

The same leakage-free group splits as the keypoint network are used. The `test` images are exported
only so detection can be evaluated later; training reads `train` and `val` (val = checkpoint selection).
"""
from __future__ import annotations

import os
import shutil
from typing import Dict, List, Sequence

import yaml

from data.manifest import ManifestRow


def _size(root: str, r: ManifestRow):
    if r.width and r.height:
        return r.width, r.height
    import cv2
    im = cv2.imread(os.path.join(root, r.image_path), cv2.IMREAD_UNCHANGED)
    if im is None:
        raise FileNotFoundError(r.image_path)
    return im.shape[1], im.shape[0]


def export_yolo_dataset(root: str, rows: Sequence[ManifestRow], split_ids: Dict[str, List[str]], out_dir: str,
                        modalities=("rgb", "ir"), link: bool = True) -> dict:
    by_id = {r.sample_id: r for r in rows}
    counts = {}
    for split in ("train", "val", "test"):
        img_dir, lab_dir = (os.path.join(out_dir, d, split) for d in ("images", "labels"))
        os.makedirs(img_dir, exist_ok=True)
        os.makedirs(lab_dir, exist_ok=True)
        n = 0
        for sid in split_ids.get(split, []):
            r = by_id[sid]
            if r.modality not in modalities:
                continue
            if r.bbox is None:
                raise ValueError(f"{sid}: no bbox in manifest")
            w, h = _size(root, r)
            x1, y1, x2, y2 = r.bbox
            x1, x2 = max(0.0, x1), min(float(w), x2)
            y1, y2 = max(0.0, y1), min(float(h), y2)
            ext = os.path.splitext(r.image_path)[1]
            src = os.path.abspath(os.path.join(root, r.image_path))
            dst = os.path.join(img_dir, sid + ext)
            if not os.path.exists(dst):
                try:
                    if not link:
                        raise OSError
                    os.symlink(src, dst)
                except OSError:
                    shutil.copy2(src, dst)
            with open(os.path.join(lab_dir, sid + ".txt"), "w") as f:
                f.write(f"0 {(x1 + x2) / 2 / w:.6f} {(y1 + y2) / 2 / h:.6f} {(x2 - x1) / w:.6f} {(y2 - y1) / h:.6f}\n")
            n += 1
        counts[split] = n
    cfg = {"path": os.path.abspath(out_dir), "train": "images/train", "val": "images/val",
           "names": {0: "uav"}}
    if counts.get("test"):
        cfg["test"] = "images/test"
    ypath = os.path.join(out_dir, "data.yaml")
    with open(ypath, "w") as f:
        yaml.safe_dump(cfg, f, sort_keys=False)
    return {"yaml": ypath, "counts": counts}
