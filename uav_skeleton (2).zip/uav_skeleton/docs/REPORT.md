# Reproduction report (status of the code base; no real-data results yet)

Paper: Kim, Gong, Cho (2026), SG-VDNet. This is an independent re-implementation; no author code was used.

## What exists and is verified (synthetic data only, 100+ unit/integration tests)
Data tooling (manifest, annotation format/GUI, region masks, leakage-free group splits), SG-/PG-VDNet and point-MSE nets, structural
geometric loss (differentiable via soft-argmax), RGB->IR frozen-backbone transfer, YOLOv8 wrapper, trainer, ORB baseline, experiment
runner with equal-budget checks, the paper's metrics (IoP, region-boundary RMSE), Easy/Hard proxy, timing, comparison tables.

## What has NOT been done
- No real MMFW-UAV data has been downloaded, annotated, trained on or evaluated. **There are no measured results.** Published values live
  only in `results/reference/` and appear in comparison tables in a separate column.
- Keypoint labels, vulnerability-region masks and Easy/Hard labels are not in the public dataset (boxes only) and must be created.
- ImageNet-initialised variants could not be run in the sandbox (weights unreachable).

## Deviations and unknowns (see docs/PAPER_ANALYSIS.md, A1-A21)
Input/heatmap sizes, optimiser, epochs, sigma, crop margin, padding, ORB details, split protocol, Easy/Hard definition, region geometry,
FPS scope, "from scratch" meaning, RMSE normalisation, how 15 px and region masks combine: all assumed and logged.
Loss balance: the paper-literal SGL setting failed to train in a synthetic diagnostic (docs/LOSS_BALANCE.md); Stage 5 tunes the balance on
validation with equal budget for baselines and always reports the literal setting.

## Metric definitions used
IoP = % of labelled keypoints inside the target node's region (or within 15 px x width/640 in radius mode). RMSE = sqrt(mean d^2) over misses
that have a prediction, d = distance to the region boundary; also reported over all predicted keypoints. Undetected images / unsupported
ORB keypoints count as misses and are excluded from RMSE, with counts. Region mode is used only where real masks exist.

## Interpreting any future result
Compare trends (ordering of ORB < PG < SG, scratch < transfer), not absolute numbers: labels, masks, splits, difficulty and hardware differ
from the paper's. Selected-on-validation numbers are optimistic; only the single test run (`--allow-test`) is unbiased. Sortie-level
splitting on real data may be too coarse; finer temporal blocks are a decision for the data owner.

## Run order on a real dataset
1. docs/DATASET.md download + `inspect_dataset.py`; build manifest/splits. 2. Annotate keypoints + regions (docs/ANNOTATION_GUIDE.md).
3. `train_detector.py`. 4. `loss_balance_check.py`, then `run_experiments.py`. 5. `run_orb.py` for ORB DBs.
6. `evaluate.py` per method/modality on val; final once on test with `--allow-test`. 7. `make_comparison.py`.
