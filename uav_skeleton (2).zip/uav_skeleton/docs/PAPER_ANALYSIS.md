# Paper analysis and assumption register

Paper: Kim, Gong, Cho, "Vulnerability Detection in UAV via Structural Skeleton Inference with
RGB-to-IR Transfer Learning", J. Sens. Sci. Technol. 35(4), 281-290 (2026).

## Specified by the paper
| Item | Paper |
|---|---|
| Pipeline | YOLOv8 box -> crop -> pad to uniform square (background-like colour) -> ResNet-18 -> 3 transposed convs -> 6 Gaussian heatmaps -> decode -> skeleton -> original coords |
| Keypoints | head, body, left wing, right wing, tail joint, tail unit |
| Loss | L = L_hm + 0.1 L_sg; L_hm = (1/N) sum M (H_pred - H_gt)^2 with visibility mask; L_sg = max(0, V_bh.V_bt) + max(0, V_bwL.V_bwR) |
| Transfer | init from RGB weights, backbone frozen, head/higher layers fine-tuned, same epochs as scratch |
| Metrics | IoP hit within vulnerability region (15 px at 640x480); RMSE = shortest distance to region boundary for misses; FPS |
| Data | MMFW-UAV, six UAV models, bottom-up views only, low-quality IR removed, ~10,000 images, Easy/Hard split |
| Hardware | PyTorch, Ubuntu 24.04, NVIDIA RTX 50-series (exact GPU unstated) |

## Missing / ambiguous (assumption register)
| ID | Gap | Our choice |
|---|---|---|
| A1 | Input size, heatmap size, deconv widths | 256 -> 8x8 -> 64x64, 3x(deconv 4x4, s2, 256ch) |
| A2 | Optimiser, LR, epochs, batch, augmentation, seed, sigma | Adam 1e-3, 100 ep, bs 32, sigma 2 heatmap px; all configurable |
| A3 | Padding colour, crop margin | border-median colour, 10% margin |
| A4 | Whether tail joint lies between body and tail unit; edge list | chain body-tail_joint-tail_unit |
| A5 | Normalisation N in Eq. 2 | mean over pixels of visible channels |
| A6 | How SGL is differentiable (needs coordinates from heatmaps) | soft-argmax (beta=100) on predicted heatmaps, normalised coords |
| A7 | SGL when keypoints missing | term skipped for that sample; averaged over batch size |
| A8 | Loss scale balance (N in Eq. 2, lambda=0.1 vs SGL magnitude) | **evidence it matters**: on a synthetic memorisation task the literal setting collapses while x50 heatmap scale or an SGL warm-up learns (docs/LOSS_BALANCE.md). Defaults stay literal; `loss.hm_loss_scale` / `loss.sg_warmup_epochs` are documented, reported deviations |
| A9 | "Vulnerability region" geometry (masks per node, region size) | our own masks; paper's are not public |
| A10 | RMSE definition: distance to region boundary for misses only | implemented as defined; RMSE over misses vs over all samples is ambiguous, we report both, labelled |
| A11 | Easy/Hard criteria | not quantified; we will define by measurable proxies (bbox size, blur, occlusion) and say so |
| A12 | FPS scope (includes YOLO? preprocessing?), GPU | measured on our hardware, fully documented, never compared as equal to paper hardware |
| A13 | PG-VDNet: text says "point-guided", baseline uses Gaussian heatmaps but also "single-point regression" in Sec. 3.2 | follow the task statement: same net, heatmap MSE, no SGL; the Point-MSE ablation covers regression |
| A14 | ORB baseline reference DB, matching/ratio test, how many models | OpenCV ORB features of train-split crops (256 px, same normalisation as the nets); each stores the offset to every labelled keypoint in its own rotation/scale frame; query features match by Hamming (k=8, Lowe ratio vs best match from a *different* train image, cap 80/256 bits) and vote; densest vote cluster per keypoint, <3 votes = unpredicted (NaN, counted as a miss, never a fallback). One DB per modality. Paper's ORB details are unpublished; all parameters are `ORBConfig` fields. OpenCV `compute()` does not recompute a supplied angle (verified), hence the feature-detect-and-vote design |
| A16 | Split protocol (paper gives none) | split by sortie/group, never by frame, RGB/IR pairs kept together; one group per split guaranteed per aircraft when >=3 groups |
| A17 | Left/right wing handedness, wing point location | aircraft's own left/right, mid-span (docs/ANNOTATION_GUIDE.md) |
| A18 | What "from scratch" means for IR (random init vs ImageNet init) and whether the RGB model used ImageNet init | unstated; Stage 5 runs and labels both (`--rgb-pretrained-backbone` sets the RGB init), same epochs |
| A19 | Model selection metric before region masks exist | lowest validation mean keypoint error (original px, GT-box crops); IoP selection once Stage 6 is done |
| A20 | Heatmap output stride, deconv width, final 1x1 conv, BN | stride 4, 3x(ConvT k4 s2 + BN + ReLU, 256 ch) + 1x1 conv, SimpleBaseline-style init |
| A21 | Training crops: GT box vs detector box | GT box with optional jitter (`train.box_jitter`) to imitate detector error; inference uses the YOLO box; missed detections count as misses |
| A15 | YOLOv8 variant/training | yolov8n or s fine-tuned on MMFW-UAV boxes (config) |

## Inconsistencies noticed in the paper
- Sec. 2.2.2.3 says the longitudinal pair "must point in opposite directions" (negative dot) -
  consistent with the hinge, but the prose "body center behind head, tail behind body" is a
  stronger claim than the loss enforces (dot < 0 only).
- RMSE-reduction percentages in the text disagree with Table 2 (see results/reference).
- Table 5 "Heatmap MSE + SGL" IR Hard (60.2 / 17.98) differs from SG-VDNet IR Hard (61.5 / 17.28).
- "RMSE" is defined only for out-of-region points, so it is not a conventional RMSE over all test points.
- IoP is described with a 15-pixel radius *and* a region mask; how the two combine is not stated.
