# Stage 5 - experiment protocol

`python scripts/run_experiments.py --root R --epochs 100 --out results/measured/stage5` (GPU machine; resumable).

**Phases.** (1) RGB: point_net, pg_vdnet, sg_vdnet, each with 3 loss/regularisation variants x the lr grid (equal trial count, checked by
`experiments.plan.check_plan`). Winner per method = lowest *validation* keypoint error; the paper-literal trial is always one of them and is
reported beside the winner. (2) IR, using each RGB winner's non-lr settings: scratch (random init), scratch (ImageNet backbone, assumption A18 -
needs network; recorded as `failed` if unreachable), and transfer (RGB checkpoint, backbone frozen, head trainable, same epochs, same lr grid).
(3) `--extra-seeds` re-runs the selected configs; (4) tables in `summary.md/json`.

**Fairness.** Same epochs everywhere; same trial count per compared method; the heatmap-only baseline gets the same loss-scale knob as SG-VDNet,
so a gain from SGL cannot come from the baseline being tuned less. Deviations from the paper-literal loss (hm_loss_scale, warm-up) are labelled by
trial name. Only train/val are read; test stays closed until Stage 6.

**What the numbers are.** Plain validation keypoint error (px). Selected-trial numbers are optimistic (selected and reported on the same split).
They are not IoP/RMSE and not comparable with the paper. Nothing under `results/measured/` exists until you run this on real data.

**Known limits.** RGB checkpoints feeding transfer come from the base seed only. Single-keypoint-error selection is a proxy until Stage 6 adds IoP.
Wall-clock: 18 RGB + ~16 IR runs of 100 epochs; budget accordingly or cut `--lrs`.
