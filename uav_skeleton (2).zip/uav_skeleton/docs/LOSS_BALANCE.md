# Loss balance: a problem found while testing Stage 3

**Status: observed on a tiny SYNTHETIC task with my implementation. It is NOT a claim about the paper's
results or about MMFW-UAV.** The paper's real training recipe is unknown (assumptions A5, A6, A8).

## What was observed
`scripts/loss_balance_check.py` trains the real trainer on 8 synthetic stick-figure images (random-init
ResNet-18, train==val, 100 full-batch steps, 96 px crops). A network that learns should land near the
heatmap quantisation floor; "predict the crop centre" scores 49.0 px.

| variant | final keypoint error | learns? |
|---|---|---|
| A  heatmap MSE only | 1.70 px | yes |
| B  + SGL, lambda=0.1, pixel-mean MSE (**paper-literal as I implement it**) | 46.77 px | **no** |
| C  + SGL, heatmap term x50 | 1.70 px | yes |
| D  + SGL as cosine similarity | 70.93 px | no (worse) |
| E  + SGL, 30-epoch linear warm-up of lambda | 1.82 px | yes |

(Raw output: `results/diagnostics/loss_balance_synthetic.json`.) A fixed-batch loop with heatmap MSE alone
also memorised the batch at 1.6 px, so heatmap generation, decoding and the coordinate chain are correct;
the difference between A and B is the SGL term.

## Why it plausibly happens
- A pixel-averaged heatmap MSE for sigma~1.5-2 Gaussians is O(1e-2) and shrinks as the heatmaps are
  fitted, while `0.1 * max(0, v1.v2)` on normalised coordinates is O(1e-2) too - the two compete at the
  start, when the heatmaps are still flat.
- The hinge on a raw dot product has a **trivial minimiser**: put every keypoint at the same place (all
  vectors zero) and L_sg = 0. A flat heatmap does exactly that (its soft-argmax is the crop centre for
  every keypoint), so early SGL gradients reinforce collapse instead of localisation.
- Cosine (D) is bounded by 1 and scale-free, so it dominates even more.

## What the paper leaves open (so any fix is a documented deviation)
The paper gives lambda=0.1 "to balance the convergence scales" but not the normalisation N in Eq. 2, the
heatmap amplitude/sigma, the optimiser, or whether the backbone was ImageNet-pretrained. Any of these could
make the literal setting work for the authors (e.g. summing over pixels rather than averaging is a ~x500
change in the heatmap term; a pretrained backbone localises peaks within a few steps).

## How the code handles it
- Default config stays **paper-literal** (`loss.hm_loss_scale: 1.0`, `loss.sg_warmup_epochs: 0`) so nothing is
  silently changed, but **do not start long runs on that default without checking** - run
  `python scripts/loss_balance_check.py` first, and watch `val_kp_error_px` in the first epochs.
- Two documented, off-by-default knobs: `loss.hm_loss_scale` (equivalent to choosing N in Eq. 2) and
  `loss.sg_warmup_epochs` (ramp lambda 0 -> 0.1). Using either must be stated in any report.
- Stage 5 plan (fair comparison): choose the loss-balance setting for the SGL model on the **validation**
  split from a small fixed grid, give the heatmap-only baseline an equally sized tuning budget (learning
  rate etc.), keep epochs identical across compared runs, and report the literal-setting result alongside.
