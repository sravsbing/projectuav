# Annotation guide (our own labels - the paper's are not public)

Every labeller must follow the same definitions, otherwise keypoint error mostly measures
labeller disagreement. Where the paper is silent I state a rule and mark it **[our rule]**.

## Keypoints (always this order)
| # | name | place the click on |
|---|---|---|
| 0 | head | nose / forward-most point of the fuselage (the sensor area, paper Table 1) |
| 1 | body | centre of the fuselage where wing root meets it (flight computer / battery area) |
| 2 | left_wing | **the aircraft's own LEFT** wing, mid-span point **[our rule]** |
| 3 | right_wing | the aircraft's own RIGHT wing, mid-span point **[our rule]** |
| 4 | tail_joint | where the tail boom/fuselage meets the empennage **[our rule]** |
| 5 | tail_unit | centre of the horizontal/vertical stabiliser assembly (rear-most control surfaces) |

- "Wing mid-span" is our choice; the paper only says "wing". Wing-tip would make L/R points far more
  sensitive to blur, so mid-span is used. Decide once, keep it.
- Left/right is the aircraft's own handedness. Seen from below, nose pointing away from you, the
  aircraft's left wing appears on your **right**. If the nose direction is unclear, press `m` (missing)
  for left/right rather than guessing; SGL is symmetric in L/R but per-keypoint metrics are not.
- Click the geometric centre of the part, not an edge.

## Visibility
- `1` = you can place it (including when you infer it confidently from the rest of the airframe
  because of blur or partial occlusion - add a note). `0` = cannot be placed or outside the frame.
- Do not label a keypoint you would only be guessing at; wrong labels hurt more than missing ones.

## Difficulty (Easy / Hard) **[our rule - the paper gives no numbers]**
The paper says Easy/Hard reflects "degree of target deformation and image quality". Until we define
objective proxies in Stage 6, label per image:
- **hard**: any of - strong motion blur or low contrast, target long side < ~60 px in the original,
  foreshortened/oblique pose that hides the fuselage axis, or any keypoint occluded.
- **easy**: otherwise.
Record who labelled and keep a re-label sample (>=5% of images, second labeller) to measure agreement.

## Excluded images (paper Sec. 3.1)
Bottom-up viewpoints only; drop IR frames where the airframe structure is not discernible even to the
eye. Excluded images should be removed from the manifest (not just left unlabelled) with the reason
logged, so the exclusion rule is auditable.

## Region masks (needed for the paper's IoP / region-RMSE)
One single-channel PNG per image, 0 = background, `k+1` = region of keypoint `k`, same size as the
original image (convert any colour mask to labels first). The paper does not define region size/shape.
**[our rule, to be decided with the data owner]**: regions are the physical component (head/nose cap,
fuselage centre, each wing section, tail boom section, empennage) painted over the airframe. If no
masks are produced, `data.regions.disc_region` gives a disc around the labelled point, which turns
IoP into a plain radius test - results must then be labelled "disc-region IoP", not comparable to the
paper's.

## Tooling
```bash
python scripts/annotate.py --root R --manifest R/manifest.csv --annotations R/annotations.jsonl \
       --annotator <name> --modality rgb --only-unlabelled
python scripts/visualize_annotations.py ... --n 24 --regions --out results/figures/check.png   # QA
python scripts/validate_dataset.py ...                                                          # gate
```
