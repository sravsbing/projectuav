# MMFW-UAV dataset: source, access, and what is NOT in it

## Legitimate source (verified from search results, not downloaded)
- Paper: Liu et al., "MMFW-UAV dataset: multi-sensor and multi-view fixed-wing UAV dataset for
  air-to-air vision tasks", *Scientific Data* 12:185 (2025), DOI 10.1038/s41597-025-04482-2
  (https://www.nature.com/articles/s41597-025-04482-2, open access via PMC11782645).
- Data host: **Science Data Bank**. The article states the dataset is publicly available there.
  A 2025 survey lists the persistent identifier as DOI **10.57760/sciencedb.07839**
  (resolve via https://doi.org/10.57760/sciencedb.07839). I have NOT opened that page or downloaded
  anything in this session; confirm the DOI resolves and read the licence before use.
- Repository layout (per the article): `README.md`, a `Tools` directory, and `MMFW-UAV-DATASET`.

## What the public dataset provides (per secondary descriptions)
- Three sensors: 48 MP RGB zoom, 12 MP RGB wide, and a thermal (IR) camera; temporally/spatially
  aligned multimodal pairs; one fixed-wing UAV per image.
- Annotations: **axis-aligned bounding boxes only**, VOC and COCO formats, single class.

## What it does NOT provide (must be created by us)
1. **Six-keypoint skeleton labels** (head, body, left/right wing, tail joint, tail unit).
2. **Semantic vulnerability-region masks** used for IoP/RMSE.
3. Easy/Hard difficulty labels and the "bottom-up viewpoint" selection / IR quality filter.
The paper hand-labelled ~10,000 images itself, and I found no evidence these labels were released.
Therefore **the paper's exact test set cannot be reproduced**; our numbers will be on our own
labels and splits.

## Discrepancies to resolve once the data is in hand
- Counts differ between sources (147,417 images in one third-party description; 169,872 "retained"
  in the article text). Trust only what `scripts/validate_dataset.py` counts on disk.
- The paper says "six UAV models"; the dataset descriptions mention twelve sorties / twelve UAVs.
  The model-to-image mapping must be read from the dataset README.
- Whether RGB/IR pairs share pixel alignment (needed to reuse labels across modalities) must be
  checked empirically; we will not assume it.

## Plan if the data is unavailable
Code accepts a root path later (`configs/default.yaml: data.root`); unit tests use synthetic data.
No result will be reported until real data and our own annotations exist.

## Source page check (ScienceDB record, fetched 2026-10-25)
https://www.scidb.cn/en/detail?dataSetId=edb443cfcfa142019499bbfd68542cc9 - "MMFW-UAV Dataset", DOI 10.57760/sciencedb.07839; licence not stated on the page.
States 147,441 fixed-wing UAV images (zoom, wide-range and thermal sensors; top-down, horizontal, bottom-up views), "49,147 sets of 1-1-1 images"
(i.e. one zoom + one wide + one thermal image per set - a claim to VERIFY against the files, not an established pairing rule).
The page lists no files, folder layout or annotation formats. Counts now disagree three ways across sources (147,417 / 169,872 / 147,441);
use only what `scripts/audit_dataset.py` finds in the files you actually have. Your local copy (6,663 JPGs in the three view folders)
is far smaller than 147,441, so it is a subset or a different release - the audit will say which sensors it contains.
