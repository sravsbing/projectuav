# UAV skeleton vulnerability detection - reproduction attempt

Independent re-implementation of Kim et al. (2026). **Not the authors' code.** Published numbers
live in `results/reference/` and are never mixed with measured output (`results/measured/`).

## Status
| Stage | Content | State |
|---|---|---|
| 1 | keypoint schema, crop transforms, heatmaps, soft-argmax, masked heatmap MSE, point MSE, SGL | done, tested |
| 2 | manifest/pairing, annotation format + validation, bbox parsers, region masks, leakage-free splits, torch Dataset, visualisation, annotation tool, CLI scripts | done, tested on **synthetic** data only |
| 3 | ResNet-18 + 3 transposed-conv heatmap net (SG/PG-VDNet), point-regression ablation net, backbone freezing for transfer, YOLOv8 wrapper + export + fine-tune script, trainer (config, seeds, checkpoints, logs, resume), inference pipeline | done; 79 tests pass; trained only on **synthetic** data |
| 4 | ORB baseline (`baselines/orb.py`, `scripts/run_orb.py`): train-only reference DB, offset voting, NaN = miss | done; tests pass; exercised on **synthetic** data only |
| 5 | experiment runner: RGB tuning, IR scratch / ImageNet-scratch / frozen-backbone transfer, 3 ablations, equal-budget checks, resumable (`scripts/run_experiments.py`, `docs/EXPERIMENTS.md`) | done; tests pass; smoke-run on **synthetic** data only (no real experiment run) |
| 6 | IoP / region-boundary RMSE, per-keypoint/difficulty/aircraft breakdowns, failure overlays, FPS protocol, measured-vs-published tables (`scripts/evaluate.py`, `make_comparison.py`, `docs/REPORT.md`) | done; tests pass; exercised on **synthetic** data only |

No experiment has been run and no real data has been touched; there are no measured results.
**Read `docs/LOSS_BALANCE.md` before any real training run:** the paper-literal SGL setting failed to train in a synthetic diagnostic.
`data/synthetic.py` generates stick-figure aircraft for tests only - never report numbers from it.

## Setup
```bash
pip install -r requirements.txt
python -m pytest tests -q
```

## Data workflow (once MMFW-UAV is downloaded; see docs/DATASET.md)
```bash
R=/path/to/MMFW-UAV
python scripts/inspect_dataset.py --root $R --depth 3 --out results/dataset_inspection.json  # learn the layout
python scripts/build_manifest.py  --root $R --out $R/manifest.csv --rule ... --bbox-template ...  # rules from the inspection
python scripts/make_splits.py     --manifest $R/manifest.csv --out $R/splits.json --seed 42
python scripts/annotate.py        --root $R --manifest $R/manifest.csv --annotations $R/annotations.jsonl --annotator NAME
python scripts/visualize_annotations.py --root $R --manifest $R/manifest.csv --annotations $R/annotations.jsonl --n 24 --out results/figures/check.png
python scripts/validate_dataset.py --root $R --manifest $R/manifest.csv --annotations $R/annotations.jsonl --splits $R/splits.json --check-images 200
```
Docs: `docs/PAPER_ANALYSIS.md` (assumption register), `docs/DATASET.md`, `docs/ANNOTATION_GUIDE.md`.

## Training / inference (Stage 3)
```bash
python scripts/loss_balance_check.py                      # ~4 min CPU: can this loss setting learn at all?
python scripts/train.py --set data.root=$R run.name=sg_rgb data.modality=rgb model.pretrained_backbone=true
python scripts/train_detector.py --root $R --manifest $R/manifest.csv --splits $R/splits.json --out-dir results/yolo_data
python scripts/predict.py --checkpoint checkpoints/sg_rgb/best.pt --yolo-weights checkpoints/yolo/uav_detector/weights/best.pt \
       --root $R --images <relative image paths> --out results/predictions
python -m pytest tests -q -m "not slow"                   # fast tests (~1 min);  drop the -m for the full suite (~5 min CPU)
```
`model.pretrained_backbone=true` needs access to download.pytorch.org (blocked in the sandbox this was built in).

## ORB baseline (Stage 4)
```bash
python scripts/run_orb.py --root $R --modality rgb --eval-split val --out results/orb_rgb_val   # GT boxes; add --yolo-weights W for detector boxes
python scripts/run_orb.py --root $R --modality ir  --eval-split val --out results/orb_ir_val
# final only: --eval-split test --allow-test
```
The printed error is plain Euclidean keypoint error, not IoP/RMSE (Stage 6). Unpredicted keypoints are reported separately.
Known limitation (seen on synthetic data, not a paper claim): ORB generalises poorly across poses of untextured shapes -
held-out synthetic error was no better than predicting the box centre, while rotated/scaled copies of *training* images are
recovered almost exactly. Real-data behaviour is unknown until MMFW-UAV is annotated.

## Experiments (Stage 5)
```bash
python scripts/run_experiments.py --root $R --dry-run                      # show the plan
python scripts/run_experiments.py --root $R --epochs 100 --out results/measured/stage5 --extra-seeds 1 2
```
See `docs/EXPERIMENTS.md`. Output is validation keypoint error only; IoP/RMSE/FPS come in Stage 6.

## Evaluation (Stage 6)
```bash
python scripts/evaluate.py --root $R --method net --checkpoint CK --modality ir --split val --use-gt-box --out results/measured/eval/sg_ir
python scripts/evaluate.py --root $R --method orb --orb-db results/orb_ir/reference_db.pkl --modality ir --split val --use-gt-box --out results/measured/eval/orb_ir
python scripts/make_comparison.py --out results/measured/comparison.md --eval sg_vdnet:ir:results/measured/eval/sg_ir --eval orb:ir:results/measured/eval/orb_ir
```
Final test numbers: add `--split test --allow-test` once. See `docs/REPORT.md` for definitions and limits.
