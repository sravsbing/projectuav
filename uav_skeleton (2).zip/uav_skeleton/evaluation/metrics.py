"""The paper's metrics (Sec. 3.2), as precisely as the paper allows. Assumptions A9/A10 in docs/PAPER_ANALYSIS.md.

Per labelled keypoint (visibility>0) of a test image:
  * HIT (region mode): the predicted point lies inside the labelled vulnerability region of THAT keypoint.
  * HIT (radius mode): Euclidean distance to the labelled point <= 15 px at 640x480 (scaled by image_width/640).
    The paper states both a 15 px radius and region masks without saying how they combine; both are reported, labelled,
    and region mode is primary only when real region masks exist.
  * MISS: not a hit, or no prediction (image undetected / keypoint unsupported).
  * Region distance d (misses with a prediction): shortest distance from the point to the region boundary
    (`data.regions.distance_to_region`, exact). In radius mode d = max(0, error - radius).
  * "RMSE" (paper definition) = sqrt(mean(d^2)) over MISSES that have a prediction. Because that is not an ordinary RMSE
    we also report it over ALL predicted keypoints (hits contribute 0) and the number of unpredicted keypoints.
Unpredicted keypoints have no distance: they count as misses for IoP and are excluded from the RMSEs, with their count reported.
"""
from __future__ import annotations

import math
from typing import Dict, Optional, Sequence

import numpy as np

from data.regions import distance_to_region, region_for_keypoint

RADIUS_PX_AT_640 = 15.0


def radius_px(image_width: int) -> float:
    return RADIUS_PX_AT_640 * image_width / 640.0


def keypoint_outcome(pred_xy, gt_xy, k: int, labels: Optional[np.ndarray], image_width: int) -> dict:
    """One keypoint -> dict(err_px, hit_radius, dist_radius, hit_region, dist_region). pred NaN -> predicted=False."""
    has_region = labels is not None
    if pred_xy is None or not np.all(np.isfinite(pred_xy)):
        return {"predicted": False, "err_px": math.nan, "hit_radius": False, "dist_radius": math.nan,
                "hit_region": False, "dist_region": math.nan, "has_region": has_region}
    err = float(np.hypot(pred_xy[0] - gt_xy[0], pred_xy[1] - gt_xy[1]))
    r = radius_px(image_width)
    out = {"predicted": True, "err_px": err, "hit_radius": err <= r, "dist_radius": max(0.0, err - r),
           "hit_region": False, "dist_region": math.nan, "has_region": has_region}
    if labels is not None:
        d = distance_to_region(region_for_keypoint(labels, k), pred_xy)
        out["dist_region"] = d
        out["hit_region"] = d == 0.0
    return out


def aggregate(records: Sequence[dict], mode: str) -> dict:
    """records: per-keypoint dicts from `keypoint_outcome` (+ any keys). mode: 'region' | 'radius'."""
    hit, dist = f"hit_{mode}", f"dist_{mode}"
    recs = list(records)
    if mode == "region":
        recs = [r for r in recs if r["has_region"]]       # keypoints of images without a region mask are not scored
    n = len(recs)
    if n == 0:
        return {"n": 0, "iop_percent": None, "rmse_misses_px": None, "rmse_all_predicted_px": None,
                "n_hits": 0, "n_misses": 0, "n_unpredicted": 0, "n_missed_with_prediction": 0}
    hits = sum(1 for r in recs if r[hit])
    pred = [r for r in recs if r["predicted"]]
    miss_d = np.array([r[dist] for r in pred if not r[hit]], dtype=float)
    all_d = np.array([r[dist] for r in pred], dtype=float)
    rm = lambda d: float(np.sqrt(np.mean(d ** 2))) if len(d) else None
    return {"n": n, "iop_percent": 100.0 * hits / n, "rmse_misses_px": rm(miss_d), "rmse_all_predicted_px": rm(all_d),
            "n_hits": hits, "n_misses": n - hits, "n_unpredicted": n - len(pred), "n_missed_with_prediction": len(miss_d)}


def group_by(records: Sequence[dict], key: str) -> Dict[str, list]:
    out: Dict[str, list] = {}
    for r in records:
        out.setdefault(str(r.get(key)), []).append(r)
    return out
