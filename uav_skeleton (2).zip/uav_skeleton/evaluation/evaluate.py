"""Run a method over a split and score it with the paper's metrics. Works for VulnerabilityPipeline and ORBBaseline
(anything with predict(image_rgb, box_xyxy=None) -> Skeleton | None)."""
from __future__ import annotations

import csv
import os
from typing import Dict, List, Optional, Sequence

import numpy as np

from data.annotations import Annotation
from data.dataset import load_image_rgb_u8
from data.keypoints import KEYPOINT_NAMES, NUM_KEYPOINTS
from data.manifest import ManifestRow
from data.regions import load_region_labels
from evaluation.difficulty import classify
from evaluation.metrics import aggregate, group_by, keypoint_outcome

CSV_FIELDS = ["sample_id", "modality", "aircraft_id", "difficulty", "difficulty_source", "difficulty_reasons", "keypoint",
              "detected", "predicted", "gt_x", "gt_y", "pred_x", "pred_y", "err_px", "hit_radius", "dist_radius",
              "hit_region", "dist_region", "has_region"]


def evaluate_split(method, root: str, rows: Sequence[ManifestRow], annotations: Dict[str, Annotation],
                   sample_ids: Sequence[str], modality: str, thresholds: dict, use_gt_box: bool,
                   max_images: Optional[int] = None) -> dict:
    """Returns {"records": [per-keypoint dicts], "images": {sid: info}}. With use_gt_box the manifest box replaces the
    detector (isolates the keypoint model; must be labelled so). Otherwise the method's own detector is used and a missed
    detection makes ALL labelled keypoints of the image misses."""
    by = {r.sample_id: r for r in rows}
    ids = [s for s in sample_ids if by[s].modality == modality and s in annotations]
    if max_images:
        ids = ids[:max_images]
    records: List[dict] = []
    images: Dict[str, dict] = {}
    for sid in ids:
        r, ann = by[sid], annotations[sid]
        img = load_image_rgb_u8(os.path.join(root, r.image_path), r.modality)
        diff = classify(r, ann, img, thresholds)
        sk = method.predict(img, r.bbox if use_gt_box else None)
        labels = load_region_labels(os.path.join(root, ann.region_mask)) if ann.region_mask else None
        w = r.width or img.shape[1]
        images[sid] = {"detected": sk is not None, "box": None if sk is None else list(sk.box)}
        for k in range(NUM_KEYPOINTS):
            if ann.visibility[k] <= 0:
                continue
            pred = None if sk is None else sk.keypoints[k]
            o = keypoint_outcome(pred, ann.keypoints[k], k, labels, w)
            o.update(sample_id=sid, modality=r.modality, aircraft_id=r.aircraft_id or "", difficulty=diff["label"],
                     difficulty_source=diff["source"], difficulty_reasons="|".join(diff["reasons"]),
                     keypoint=KEYPOINT_NAMES[k], detected=sk is not None, gt_x=float(ann.keypoints[k][0]),
                     gt_y=float(ann.keypoints[k][1]),
                     pred_x=float(pred[0]) if o["predicted"] else float("nan"),
                     pred_y=float(pred[1]) if o["predicted"] else float("nan"))
            records.append(o)
    return {"records": records, "images": images}


def summarize(records: Sequence[dict], modes=("region", "radius")) -> dict:
    """Overall + per keypoint + per difficulty + per aircraft, for each mode that is scoreable."""
    out = {"n_images": len({r["sample_id"] for r in records}),
           "difficulty_sources": sorted({r["difficulty_source"] for r in records}),
           "n_images_undetected": len({r["sample_id"] for r in records if not r["detected"]})}
    for mode in modes:
        if mode == "region" and not any(r["has_region"] for r in records):
            out[mode] = None                       # no region masks -> not computable, never silently replaced
            continue
        out[mode] = {"overall": aggregate(records, mode),
                     "per_keypoint": {k: aggregate(v, mode) for k, v in group_by(records, "keypoint").items()},
                     "per_difficulty": {k: aggregate(v, mode) for k, v in group_by(records, "difficulty").items()},
                     "per_aircraft": {k: aggregate(v, mode) for k, v in group_by(records, "aircraft_id").items()}}
    return out


def write_csv(path: str, records: Sequence[dict]) -> None:
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=CSV_FIELDS, extrasaction="ignore")
        w.writeheader()
        for r in records:
            w.writerow(r)


def worst_cases(records: Sequence[dict], n: int = 12, mode: str = "region") -> List[str]:
    """sample_ids with the largest (worst keypoint) region/radius distance; undetected images rank first."""
    key = "dist_region" if mode == "region" else "dist_radius"
    score: Dict[str, float] = {}
    for r in records:
        v = float("inf") if not r["predicted"] else (0.0 if np.isnan(r[key]) else r[key])
        score[r["sample_id"]] = max(score.get(r["sample_id"], 0.0), v)
    return [s for s, _ in sorted(score.items(), key=lambda kv: -kv[1])[:n] if _ > 0]
