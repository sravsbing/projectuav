"""Measured-vs-published comparison tables. Published numbers are read from results/reference/published_results.json and are
only ever placed in their own column; measured values come exclusively from our evaluation summaries."""
from __future__ import annotations

import json
import os
from typing import Dict, Optional

REF = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "results", "reference", "published_results.json")
METHOD_KEYS = {"orb": "ORB", "pg_vdnet": "PG-VDNet", "sg_vdnet": "SG-VDNet"}

CAVEAT = ("> Measured values come from OUR labels, OUR vulnerability-region masks, OUR Easy/Hard definition, OUR split and OUR hardware; "
          "the paper's are unpublished. Differences therefore mix method effects with protocol differences and are **not** a "
          "reproduction verdict. Published values are copied from the paper's tables.\n")


def load_reference(path: str = REF) -> dict:
    with open(path) as f:
        return json.load(f)


def _cell(summary: Optional[dict], mode: str, diff: str, field: str):
    try:
        return summary[mode]["per_difficulty"][diff][field]
    except (KeyError, TypeError):
        return None


def _f(v, d=1):
    return "n/a" if v is None else f"{v:.{d}f}"


def accuracy_table(measured: Dict[str, Dict[str, dict]], mode: str = "region", rmse_field: str = "rmse_misses_px",
                   ref: Optional[dict] = None) -> str:
    """measured[method_key][modality] = evaluation.evaluate.summarize(...). Rows: method x modality x difficulty."""
    ref = ref or load_reference()
    L = [f"### IoP hit rate (%) and RMSE (px), mode = {mode}, RMSE over {rmse_field}", "",
         "| method | modality | difficulty | IoP measured | IoP published | RMSE measured | RMSE published | n keypoints | unpredicted |",
         "|---|---|---|---|---|---|---|---|---|"]
    for mk, name in METHOD_KEYS.items():
        for mod in ("rgb", "ir"):
            s = measured.get(mk, {}).get(mod)
            for diff in ("easy", "hard"):
                key = f"{mod}_{diff}"
                pub_i = ref["iop_hit_rate_percent"][name][key]
                pub_r = ref["rmse_px"][name][key]
                agg = s[mode]["per_difficulty"].get(diff) if s and s.get(mode) else None
                L.append(f"| {name} | {mod.upper()} | {diff} | {_f(agg and agg['iop_percent'])} | {pub_i} | "
                         f"{_f(agg and agg[rmse_field], 2)} | {pub_r} | {agg['n'] if agg else 'n/a'} | {agg['n_unpredicted'] if agg else 'n/a'} |")
    return "\n".join(L) + "\n"


def speed_table(measured: Dict[str, dict], ref: Optional[dict] = None) -> str:
    ref = ref or load_reference()
    L = ["### Speed (not comparable across hardware)", "",
         "| method | FPS measured | latency ms measured | scope / hardware | FPS published | latency ms published |", "|---|---|---|---|---|---|"]
    for mk, name in METHOD_KEYS.items():
        m = measured.get(mk)
        hw = "n/a" if not m else f"{m['scope']}; {m['hardware'].get('gpu', 'CPU ' + str(m['hardware']['cpu_threads']) + ' threads')}"
        L.append(f"| {name} | {_f(m and m['fps_from_mean'])} | {_f(m and m['latency_ms_mean'], 2)} | {hw} | "
                 f"{ref['speed'][name]['fps']} | {ref['speed'][name]['latency_ms']} |")
    return "\n".join(L) + "\n"
