"""Latency / FPS with a documented procedure. Numbers are for THIS hardware only and are never comparable to the paper's
(RTX 50-series, unstated model, unstated scope)."""
from __future__ import annotations

import platform
import time
from typing import Callable, Sequence

import numpy as np


def _sync():
    try:
        import torch
        if torch.cuda.is_available():
            torch.cuda.synchronize()
    except Exception:
        pass


def time_callable(fn: Callable[[], object], warmup: int = 10, repeats: int = 100) -> dict:
    for _ in range(warmup):
        fn()
    _sync()
    ts = []
    for _ in range(repeats):
        t0 = time.perf_counter()
        fn()
        _sync()
        ts.append((time.perf_counter() - t0) * 1000.0)
    a = np.array(ts)
    return {"latency_ms_mean": float(a.mean()), "latency_ms_median": float(np.median(a)), "latency_ms_p95": float(np.percentile(a, 95)),
            "fps_from_mean": float(1000.0 / a.mean()), "repeats": repeats, "warmup": warmup}


def hardware_info() -> dict:
    import torch
    d = {"platform": platform.platform(), "python": platform.python_version(), "torch": torch.__version__,
         "cpu_threads": torch.get_num_threads(), "cuda": torch.cuda.is_available()}
    if torch.cuda.is_available():
        d["gpu"] = torch.cuda.get_device_name(0)
    return d


def benchmark(method, images: Sequence[np.ndarray], boxes: Sequence, scope: str, warmup: int = 10, repeats: int = 100) -> dict:
    """Batch size 1, images cycled, image already decoded in RAM (disk I/O excluded). `scope` is a free-text label of what
    method.predict includes (e.g. 'GT box + crop + network + decode' or 'YOLOv8 + crop + network + decode')."""
    i = {"k": 0}

    def one():
        j = i["k"] % len(images)
        i["k"] += 1
        method.predict(images[j], boxes[j])
    r = time_callable(one, warmup, repeats)
    r.update(scope=scope, batch_size=1, hardware=hardware_info(),
             procedure="perf_counter around method.predict; warm-up discarded; images decoded beforehand; cuda synced if present")
    return r
