"""Easy / Hard split. The paper does not define it (assumption A11), so we use, in this order:
  1. the annotator's own `difficulty` label if the annotation has one (docs/ANNOTATION_GUIDE.md rules), else
  2. an OBJECTIVE PROXY: hard if ANY of
       - small target: max box side < `small_frac` x image width,
       - partial labels: fewer than 6 labelled (visible) keypoints,
       - blurry/low-contrast: Laplacian variance of the grey box crop below the `blur_quantile` of the TRAIN split.
Thresholds are computed from the train split only. Every report states which source produced each label.
"""
from __future__ import annotations

from typing import Dict, Optional, Sequence

import cv2
import numpy as np

from data.dataset import load_image_rgb_u8
from data.keypoints import NUM_KEYPOINTS


def sharpness(image_rgb: np.ndarray, box_xyxy) -> float:
    x1, y1, x2, y2 = (int(round(v)) for v in box_xyxy)
    h, w = image_rgb.shape[:2]
    crop = image_rgb[max(0, y1):min(h, y2), max(0, x1):min(w, x2)]
    if crop.size == 0:
        return 0.0
    return float(cv2.Laplacian(cv2.cvtColor(np.ascontiguousarray(crop), cv2.COLOR_RGB2GRAY), cv2.CV_64F).var())


def fit_thresholds(root: str, rows, train_ids: Sequence[str], modality: str, blur_quantile: float = 0.25,
                   small_frac: float = 0.25, max_images: int = 500, seed: int = 0) -> dict:
    import os
    by = {r.sample_id: r for r in rows}
    ids = [s for s in train_ids if by[s].modality == modality and by[s].bbox is not None]
    if len(ids) > max_images:
        ids = list(np.random.default_rng(seed).choice(ids, max_images, replace=False))
    vals = [sharpness(load_image_rgb_u8(os.path.join(root, by[s].image_path), modality), by[s].bbox) for s in ids]
    if not vals:
        raise ValueError(f"no train images with boxes for modality {modality!r}")
    return {"blur_threshold": float(np.quantile(vals, blur_quantile)), "blur_quantile": blur_quantile,
            "small_frac": small_frac, "n_images": len(vals), "modality": modality}


def classify(row, ann, image_rgb: np.ndarray, th: dict) -> Dict[str, object]:
    """-> {'label': 'easy'|'hard', 'source': 'annotation'|'proxy', 'reasons': [...]}"""
    if ann.difficulty in ("easy", "hard"):
        return {"label": ann.difficulty, "source": "annotation", "reasons": []}
    reasons = []
    x1, y1, x2, y2 = row.bbox
    w = row.width or image_rgb.shape[1]
    if max(x2 - x1, y2 - y1) < th["small_frac"] * w:
        reasons.append("small_target")
    if int((np.asarray(ann.visibility) > 0).sum()) < NUM_KEYPOINTS:
        reasons.append("partial_labels")
    if sharpness(image_rgb, row.bbox) < th["blur_threshold"]:
        reasons.append("blurry")
    return {"label": "hard" if reasons else "easy", "source": "proxy", "reasons": reasons}
