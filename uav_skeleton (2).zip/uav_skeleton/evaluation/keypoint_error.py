"""Plain keypoint Euclidean error (pixels) - used for validation/model selection in Stage 3.

NOT the paper's metrics: the paper's IoP / region-boundary RMSE need vulnerability-region masks and
are implemented in Stage 6. This is an ordinary point-to-point distance to the labelled keypoint.
"""
from __future__ import annotations

import torch


def keypoint_errors(pred_xy: torch.Tensor, gt_xy: torch.Tensor, vis: torch.Tensor) -> torch.Tensor:
    """(B,K,2),(B,K,2),(B,K) -> (B,K) Euclidean error, NaN where the keypoint is not labelled."""
    err = (pred_xy - gt_xy).norm(dim=-1)
    return torch.where(vis.bool(), err, torch.full_like(err, float("nan")))


def summarize_errors(err: torch.Tensor) -> dict:
    """Mean over labelled keypoints, overall and per keypoint (NaN-safe)."""
    valid = ~torch.isnan(err)
    n = valid.sum()
    overall = float(err[valid].mean()) if n > 0 else float("nan")
    per_kp = []
    for k in range(err.shape[1]):
        v = valid[:, k]
        per_kp.append(float(err[v, k].mean()) if v.any() else float("nan"))
    return {"mean": overall, "per_keypoint": per_kp, "n": int(n)}
