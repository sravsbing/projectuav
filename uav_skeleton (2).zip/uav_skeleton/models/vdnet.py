"""SG-VDNet / PG-VDNet heatmap network and the direct point-regression ablation network.

Architecture (paper Sec. 2.2.2.2, Fig. 5):
    square crop SxS -> ResNet-18 (conv7x7 stem, BN, ReLU, maxpool, 4 residual stages; stride 32)
    -> 3 x transposed-convolution stages (each x2 upsampling) -> 6-channel heatmap (stride 4).

Unspecified in the paper and chosen by us (docs/PAPER_ANALYSIS.md, A1):
  * each transposed-conv stage = ConvTranspose2d(k=4, s=2, p=1) + BN + ReLU, 256 channels
  * a final 1x1 conv maps 256 -> 6 heatmap channels (no output activation)
  * output stride 4, i.e. a 256x256 crop gives 6x64x64 heatmaps

PG-VDNet and SG-VDNet are the SAME network (the paper's difference is the training loss: heatmap MSE
vs heatmap MSE + SGL). They are separate classes only so that checkpoints/configs say which method
they are; `default_sg_weight` records the paper's setting.
"""
from __future__ import annotations

import torch
import torch.nn as nn
import torchvision

from data.keypoints import NUM_KEYPOINTS

OUTPUT_STRIDE = 4          # 32 (ResNet-18) / 2^3 (three transposed convs)


def _resnet18(pretrained: bool) -> nn.Module:
    if not pretrained:
        return torchvision.models.resnet18(weights=None)
    try:
        return torchvision.models.resnet18(weights=torchvision.models.ResNet18_Weights.IMAGENET1K_V1)
    except Exception as e:  # never silently fall back to random init: that would corrupt an experiment
        raise RuntimeError("could not load ImageNet ResNet-18 weights (offline / blocked download?). "
                           "Set model.pretrained_backbone=false explicitly or provide network access.") from e


class ResNet18Backbone(nn.Module):
    """ResNet-18 up to layer4 (no pooling / classifier). Output: (B, 512, S/32, S/32)."""

    out_channels = 512

    def __init__(self, pretrained: bool = False):
        super().__init__()
        m = _resnet18(pretrained)
        self.stem = nn.Sequential(m.conv1, m.bn1, m.relu, m.maxpool)
        self.layer1, self.layer2, self.layer3, self.layer4 = m.layer1, m.layer2, m.layer3, m.layer4

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.layer4(self.layer3(self.layer2(self.layer1(self.stem(x)))))


class FreezableMixin:
    """Backbone freezing for RGB->IR transfer (paper Sec. 2.2.3: backbone strictly frozen).

    A frozen BatchNorm must also stop updating its running statistics, otherwise "frozen" weights
    would still drift during IR fine-tuning. `train()` therefore keeps every fully-frozen BN in eval.
    """

    def set_trainable(self, prefixes) -> None:
        """Only parameters whose name starts with one of `prefixes` stay trainable (e.g. ("head",),
        ("head", "backbone.layer4")). Everything else is frozen."""
        prefixes = tuple(prefixes)
        for name, p in self.named_parameters():
            p.requires_grad = any(name == q or name.startswith(q + ".") for q in prefixes)
        self._refresh_frozen_bn()

    def _refresh_frozen_bn(self) -> None:
        self._frozen_bn = [m for m in self.modules()
                           if isinstance(m, nn.modules.batchnorm._BatchNorm)
                           and not any(p.requires_grad for p in m.parameters())]
        for m in self._frozen_bn:
            m.eval()

    def train(self, mode: bool = True):
        super().train(mode)
        for m in getattr(self, "_frozen_bn", []):
            m.eval()
        return self

    def trainable_parameters(self):
        return [p for p in self.parameters() if p.requires_grad]

    def count_parameters(self) -> dict:
        tot = sum(p.numel() for p in self.parameters())
        tr = sum(p.numel() for p in self.parameters() if p.requires_grad)
        return {"total": tot, "trainable": tr}


class DeconvHead(nn.Module):
    def __init__(self, in_ch: int = 512, mid: int = 256, num_keypoints: int = NUM_KEYPOINTS, n_stages: int = 3):
        super().__init__()
        layers, c = [], in_ch
        for _ in range(n_stages):
            layers += [nn.ConvTranspose2d(c, mid, kernel_size=4, stride=2, padding=1, bias=False),
                       nn.BatchNorm2d(mid), nn.ReLU(inplace=True)]
            c = mid
        self.deconv = nn.Sequential(*layers)
        self.final = nn.Conv2d(mid, num_keypoints, kernel_size=1)
        for m in self.modules():                       # SimpleBaseline-style init
            if isinstance(m, (nn.ConvTranspose2d, nn.Conv2d)):
                nn.init.normal_(m.weight, std=0.001)
                if getattr(m, "bias", None) is not None:
                    nn.init.zeros_(m.bias)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.final(self.deconv(x))


class VDNet(FreezableMixin, nn.Module):
    """Heatmap keypoint network. forward: (B,3,S,S) -> (B,K,S/4,S/4)."""

    name = "vdnet"
    default_sg_weight = 0.0
    output_type = "heatmap"

    def __init__(self, num_keypoints: int = NUM_KEYPOINTS, pretrained_backbone: bool = False,
                 deconv_channels: int = 256):
        super().__init__()
        self.num_keypoints = num_keypoints
        self.backbone = ResNet18Backbone(pretrained_backbone)
        self.head = DeconvHead(self.backbone.out_channels, deconv_channels, num_keypoints)
        self._refresh_frozen_bn()

    @staticmethod
    def heatmap_size(input_size: int) -> int:
        if input_size % 32:
            raise ValueError("input_size must be a multiple of 32")
        return input_size // OUTPUT_STRIDE

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.head(self.backbone(x))


class PGVDNet(VDNet):
    """Paper baseline: Gaussian-heatmap keypoint net trained WITHOUT the structural loss."""
    name = "pg_vdnet"
    default_sg_weight = 0.0


class SGVDNet(VDNet):
    """Proposed method: same net, trained with L_hm + 0.1 * L_sg."""
    name = "sg_vdnet"
    default_sg_weight = 0.1


class PointRegressionNet(FreezableMixin, nn.Module):
    """Direct coordinate regression (paper Table 5 'Point MSE'): ResNet-18 -> global pool -> FC(2K).

    Output: normalised coords (B,K,2) in [0,1] image-crop units, initialised at the crop centre.
    """

    name = "point_net"
    default_sg_weight = 0.0
    output_type = "points"

    def __init__(self, num_keypoints: int = NUM_KEYPOINTS, pretrained_backbone: bool = False, **_):
        super().__init__()
        self.num_keypoints = num_keypoints
        self.backbone = ResNet18Backbone(pretrained_backbone)
        self.head = nn.Sequential(nn.AdaptiveAvgPool2d(1), nn.Flatten(), nn.Linear(512, 2 * num_keypoints))
        nn.init.zeros_(self.head[-1].weight)
        nn.init.constant_(self.head[-1].bias, 0.5)
        self._refresh_frozen_bn()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.head(self.backbone(x)).view(x.shape[0], self.num_keypoints, 2)


ARCHS = {"pg_vdnet": PGVDNet, "sg_vdnet": SGVDNet, "point_net": PointRegressionNet}


def build_model(arch: str, pretrained_backbone: bool = False, deconv_channels: int = 256) -> nn.Module:
    if arch not in ARCHS:
        raise ValueError(f"unknown arch {arch!r}; choose from {sorted(ARCHS)}")
    if arch == "point_net":
        return PointRegressionNet(pretrained_backbone=pretrained_backbone)
    return ARCHS[arch](pretrained_backbone=pretrained_backbone, deconv_channels=deconv_channels)
