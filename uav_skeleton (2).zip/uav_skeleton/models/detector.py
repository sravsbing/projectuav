"""UAV detection stage (paper Sec. 2.2.2.1): YOLOv8 box -> crop for the keypoint network.

`Detector.detect(image_rgb_uint8)` returns a `Detection` or None. A missed detection is returned as
None and must be COUNTED AS A MISS by the evaluation - there is deliberately no silent fallback to
the full image or to the ground-truth box.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Protocol, Tuple

import numpy as np


@dataclass(frozen=True)
class Detection:
    box_xyxy: Tuple[float, float, float, float]
    conf: float


class Detector(Protocol):
    def detect(self, image_rgb: np.ndarray) -> Optional[Detection]: ...


class FixedBoxDetector:
    """Oracle detector: always returns the given box. For tests and for the 'GT-box' upper-bound
    evaluation of the keypoint network in isolation (must be labelled as such in any report)."""

    def __init__(self, box_xyxy, conf: float = 1.0):
        self.det = Detection(tuple(float(v) for v in box_xyxy), conf)

    def detect(self, image_rgb: np.ndarray) -> Optional[Detection]:
        return self.det


class YoloV8Detector:
    """Thin wrapper around ultralytics YOLOv8. Single-class UAV detector; picks the most confident box.

    `weights` is a path to a fine-tuned .pt (see scripts/train_detector.py). Ultralytics expects BGR
    numpy arrays, so RGB input is flipped here.
    """

    def __init__(self, weights: str, conf: float = 0.25, iou: float = 0.7, imgsz: int = 640,
                 device: Optional[str] = None):
        from ultralytics import YOLO
        self.model = YOLO(weights)
        self.conf, self.iou, self.imgsz, self.device = conf, iou, imgsz, device

    def detect(self, image_rgb: np.ndarray) -> Optional[Detection]:
        bgr = np.ascontiguousarray(image_rgb[..., ::-1])
        res = self.model.predict(bgr, conf=self.conf, iou=self.iou, imgsz=self.imgsz,
                                 device=self.device, verbose=False)[0]
        return self._best(res)

    @staticmethod
    def _best(result) -> Optional[Detection]:
        boxes = result.boxes
        if boxes is None or len(boxes) == 0:
            return None
        i = int(boxes.conf.argmax())
        return Detection(tuple(float(v) for v in boxes.xyxy[i].cpu().numpy()), float(boxes.conf[i]))
