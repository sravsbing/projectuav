"""End-to-end inference: image -> detector box -> square crop -> network -> skeleton in original coords."""
from __future__ import annotations

from typing import Optional

import numpy as np
import torch

from data.dataset import normalize_crop
from data.transforms import crop_pad_resize, square_crop_from_bbox
from models.detector import Detector
from models.postprocess import Skeleton, decode_batch_original, make_skeleton


class VulnerabilityPipeline:
    def __init__(self, model: torch.nn.Module, detector: Detector, input_size: int = 256,
                 margin: float = 0.1, device: Optional[str] = None, refine: bool = True):
        self.model = model.eval()
        self.detector = detector
        self.input_size, self.margin, self.refine = input_size, margin, refine
        self.device = torch.device(device or ("cuda" if torch.cuda.is_available() else "cpu"))
        self.model.to(self.device)

    @torch.no_grad()
    def predict(self, image_rgb: np.ndarray, box_xyxy=None) -> Optional[Skeleton]:
        """`box_xyxy` overrides the detector (GT-box evaluation). Returns None if nothing detected."""
        if box_xyxy is None:
            det = self.detector.detect(image_rgb)
            if det is None:
                return None
            box_xyxy = det.box_xyxy
        tf = square_crop_from_bbox(box_xyxy, self.input_size, self.margin)
        x = torch.from_numpy(normalize_crop(crop_pad_resize(image_rgb, tf)))[None].to(self.device)
        out = self.model(x)
        crop = torch.tensor([[tf.x0, tf.y0, tf.side]], dtype=torch.float64, device=self.device)
        xy_o, conf, xy_in = decode_batch_original(out.double() if out.dtype != torch.float64 else out, crop,
                                                  self.input_size, self.model.output_type, self.refine)
        return make_skeleton(xy_o[0].cpu().numpy(), conf[0].cpu().numpy(), box_xyxy, xy_in[0].cpu().numpy())
