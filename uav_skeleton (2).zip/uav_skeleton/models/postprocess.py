"""Decode network output -> keypoints in the ORIGINAL image, and build the skeleton graph.

Chain (paper Sec. 2.2.2.2 post-processing): heatmap -> peak (argmax + quarter-cell refinement) ->
network-input coords -> inverse crop transform -> original-image coords; nodes joined through an
adjacency matrix built from data.keypoints.SKELETON_EDGES.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Tuple

import numpy as np
import torch

from data.heatmaps import decode_argmax, heatmap_to_input
from data.keypoints import NUM_KEYPOINTS, SKELETON_EDGES
from models.vdnet import OUTPUT_STRIDE


def adjacency_matrix() -> np.ndarray:
    a = np.zeros((NUM_KEYPOINTS, NUM_KEYPOINTS), dtype=np.uint8)
    for i, j in SKELETON_EDGES:
        a[i, j] = a[j, i] = 1
    return a


@dataclass
class Skeleton:
    keypoints: np.ndarray            # (K,2) ORIGINAL-image pixel coords (pixel-centre frame)
    confidence: np.ndarray           # (K,) heatmap peak (heatmap nets) or 1.0 (point net)
    adjacency: np.ndarray            # (K,K) uint8
    box: Tuple[float, float, float, float]   # detector box used for the crop
    keypoints_input: Optional[np.ndarray] = None   # (K,2) in network-input coords


def inputs_to_original_torch(xy_in: torch.Tensor, crop: torch.Tensor, input_size: int) -> torch.Tensor:
    """xy_in (B,K,2) input coords; crop (B,3)=(x0,y0,side). Same maths as CropTransform.to_original."""
    crop = crop.to(xy_in.dtype)
    scale = (input_size / crop[:, 2]).view(-1, 1, 1)
    return (xy_in + 0.5) / scale + crop[:, :2].view(-1, 1, 2)


def original_to_inputs_torch(xy_orig: torch.Tensor, crop: torch.Tensor, input_size: int) -> torch.Tensor:
    crop = crop.to(xy_orig.dtype)
    scale = (input_size / crop[:, 2]).view(-1, 1, 1)
    return (xy_orig - crop[:, :2].view(-1, 1, 2)) * scale - 0.5


def decode_heatmaps_to_input(heatmaps: torch.Tensor, input_size: int, refine: bool = True):
    """-> (xy_in (B,K,2) in network-input pixels, conf (B,K))."""
    stride = input_size / heatmaps.shape[-1]
    xy_hm, conf = decode_argmax(heatmaps, refine=refine)
    return heatmap_to_input(xy_hm, stride), conf


def decode_points_to_input(norm: torch.Tensor, input_size: int) -> torch.Tensor:
    """Point-net output (normalised, x_norm=(x_in+0.5)/S) -> input pixel coords."""
    return norm * input_size - 0.5


def decode_batch_original(output: torch.Tensor, crop: torch.Tensor, input_size: int,
                          output_type: str = "heatmap", refine: bool = True):
    """Network output -> (xy_original (B,K,2), conf (B,K), xy_input (B,K,2))."""
    if output_type == "heatmap":
        xy_in, conf = decode_heatmaps_to_input(output, input_size, refine)
    elif output_type == "points":
        xy_in, conf = decode_points_to_input(output, input_size), torch.ones(output.shape[:2], device=output.device)
    else:
        raise ValueError(output_type)
    return inputs_to_original_torch(xy_in, crop, input_size), conf, xy_in


def make_skeleton(xy_original: np.ndarray, conf: np.ndarray, box, xy_input: Optional[np.ndarray] = None) -> Skeleton:
    return Skeleton(np.asarray(xy_original, dtype=np.float64), np.asarray(conf, dtype=np.float64),
                    adjacency_matrix(), tuple(float(v) for v in box), xy_input)
