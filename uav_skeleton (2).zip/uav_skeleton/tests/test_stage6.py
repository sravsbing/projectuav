import json
import math
import os
import subprocess
import sys

import numpy as np
import pytest

from baselines.orb import ORBBaseline, build_reference_db
from data.annotations import read_annotations
from data.manifest import read_manifest
from data.splits import group_split, save_splits
from data.synthetic import make_synthetic_dataset
from evaluation.compare import accuracy_table, load_reference, speed_table
from evaluation.difficulty import classify, fit_thresholds
from evaluation.evaluate import evaluate_split, summarize, worst_cases
from evaluation.metrics import aggregate, keypoint_outcome, radius_px
from evaluation.timing import benchmark, time_callable
from models.postprocess import make_skeleton


def _labels():
    L = np.zeros((100, 100), np.uint8)
    L[40:61, 40:61] = 1                      # keypoint 0 region: x,y in [40,60]
    return L


def test_hit_inside_region_and_distance_outside_is_exact():
    L = _labels()
    assert keypoint_outcome(np.array([50., 50.]), np.array([50., 50.]), 0, L, 640)["hit_region"]
    o = keypoint_outcome(np.array([70., 50.]), np.array([50., 50.]), 0, L, 640)
    assert not o["hit_region"] and o["dist_region"] == pytest.approx(9.5)       # boundary of pixel 60 is at x=60.5
    o = keypoint_outcome(np.array([70., 70.]), np.array([50., 50.]), 0, L, 640)
    assert o["dist_region"] == pytest.approx(math.hypot(9.5, 9.5))
    assert keypoint_outcome(np.array([50., 50.]), np.array([50., 50.]), 1, L, 640)["dist_region"] > 0   # wrong node's region


def test_radius_mode_scales_with_image_width():
    assert radius_px(640) == 15 and radius_px(1280) == 30
    assert keypoint_outcome(np.array([14.9, 0.]), np.array([0., 0.]), 0, None, 640)["hit_radius"]
    o = keypoint_outcome(np.array([20., 0.]), np.array([0., 0.]), 0, None, 640)
    assert not o["hit_radius"] and o["dist_radius"] == pytest.approx(5.0)
    assert keypoint_outcome(np.array([20., 0.]), np.array([0., 0.]), 0, None, 1280)["hit_radius"]


def test_aggregate_rmse_is_over_misses_and_unpredicted_are_misses():
    L = _labels()
    recs = [keypoint_outcome(np.array(p, float), np.array([50., 50.]), 0, L, 640) for p in ([50, 50], [70.5, 50], [50, 80.5])]
    recs.append(keypoint_outcome(None, np.array([50., 50.]), 0, L, 640))
    a = aggregate(recs, "region")
    assert a["n"] == 4 and a["iop_percent"] == 25.0 and a["n_unpredicted"] == 1 and a["n_missed_with_prediction"] == 2
    assert a["rmse_misses_px"] == pytest.approx(math.sqrt((10 ** 2 + 20 ** 2) / 2))
    assert a["rmse_all_predicted_px"] == pytest.approx(math.sqrt((10 ** 2 + 20 ** 2) / 3))     # hit counts as 0
    assert aggregate([], "region")["iop_percent"] is None


def test_region_mode_ignores_keypoints_without_masks():
    r = [keypoint_outcome(np.array([5., 5.]), np.array([5., 5.]), 0, None, 640)]
    assert aggregate(r, "region")["n"] == 0 and aggregate(r, "radius")["iop_percent"] == 100.0


@pytest.fixture(scope="module")
def env(tmp_path_factory):
    d = str(tmp_path_factory.mktemp("s6"))
    make_synthetic_dataset(d, n_groups=12, frames_per_group=4, seed=1)
    rows = read_manifest(os.path.join(d, "manifest.csv"))
    ann = read_annotations(os.path.join(d, "annotations.jsonl"))
    sp = group_split(rows, seed=1)
    save_splits(os.path.join(d, "splits.json"), sp, {"seed": 1})
    th = fit_thresholds(d, rows, sp["train"], "rgb")
    return d, rows, ann, sp, th, {r.sample_id: r for r in rows}


class Oracle:
    def __init__(self, ann, by, dx=0.0, miss=False):
        self.ann, self.by, self.dx, self.miss, self.cur = ann, by, dx, miss, None

    def predict(self, img, box):
        sid = next(s for s, r in self.by.items() if tuple(r.bbox) == tuple(box))
        if self.miss:
            return None
        kp = self.ann[sid].keypoints + self.dx
        return make_skeleton(kp, np.ones(6), box)


def test_oracle_scores_100_and_offsets_and_undetected_are_misses(env):
    d, rows, ann, sp, th, by = env
    perfect = summarize(evaluate_split(Oracle(ann, by), d, rows, ann, sp["val"], "rgb", th, True)["records"])
    assert perfect["region"]["overall"]["iop_percent"] == 100.0 and perfect["radius"]["overall"]["iop_percent"] == 100.0
    off = evaluate_split(Oracle(ann, by, dx=40.0), d, rows, ann, sp["val"], "rgb", th, True)["records"]
    s = summarize(off)
    assert s["region"]["overall"]["iop_percent"] < 5 and s["region"]["overall"]["rmse_misses_px"] > 20
    gone = summarize(evaluate_split(Oracle(ann, by, miss=True), d, rows, ann, sp["val"], "rgb", th, True)["records"])
    g = gone["region"]["overall"]
    assert g["iop_percent"] == 0.0 and g["n_unpredicted"] == g["n"] and g["rmse_misses_px"] is None
    assert gone["n_images_undetected"] == gone["n_images"]
    assert worst_cases(off, 3)[0] in {r["sample_id"] for r in off}


def test_summary_has_breakdowns_and_no_regions_means_not_computable(env, tmp_path):
    d, rows, ann, sp, th, by = env
    recs = evaluate_split(Oracle(ann, by), d, rows, ann, sp["val"], "rgb", th, True)["records"]
    s = summarize(recs)
    assert set(s["region"]["per_keypoint"]) == {"head", "body", "left_wing", "right_wing", "tail_joint", "tail_unit"}
    assert set(s["region"]["per_difficulty"]) <= {"easy", "hard"} and s["region"]["per_aircraft"]
    for r in recs:
        r["has_region"] = False
    assert summarize(recs)["region"] is None                      # reported as not computable, never replaced silently


def test_difficulty_annotation_wins_proxy_is_objective_and_train_only(env):
    d, rows, ann, sp, th, by = env
    sid = sp["val"][0]
    r, a = by[sid], ann[sid]
    img = np.full((480, 640, 3), 128, np.uint8)
    import dataclasses
    a_hard = dataclasses.replace(a, difficulty="hard")
    assert classify(r, a_hard, img, th) == {"label": "hard", "source": "annotation", "reasons": []}
    a_none = dataclasses.replace(a, difficulty=None)
    c = classify(r, a_none, img, th)
    assert c["source"] == "proxy" and "blurry" in c["reasons"] and c["label"] == "hard"      # flat image = no sharpness
    a_partial = dataclasses.replace(a_none, visibility=np.array([1, 1, 1, 1, 1, 0.]))
    assert "partial_labels" in classify(r, a_partial, img, th)["reasons"]
    assert th["n_images"] > 0 and th["modality"] == "rgb"


def test_orb_runs_through_evaluator_and_counts_unpredicted(env):
    d, rows, ann, sp, th, by = env
    db = build_reference_db(d, rows, ann, sp["train"], "rgb")
    res = evaluate_split(ORBBaseline(db), d, rows, ann, sp["val"], "rgb", th, True, max_images=6)
    s = summarize(res["records"])
    assert s["region"]["overall"]["n"] > 0 and 0 <= s["region"]["overall"]["iop_percent"] <= 100


def test_comparison_keeps_published_separate_and_marks_missing_as_na():
    t = accuracy_table({})
    assert "n/a" in t and "94.2" in t                           # published present in its own column, measured n/a
    row = [l for l in t.splitlines() if l.startswith("| SG-VDNet | RGB | easy")][0].split("|")
    assert row[4].strip() == "n/a" and row[5].strip() == "94.2"
    assert "n/a" in speed_table({})
    fake = {"sg_vdnet": {"rgb": {"region": {"per_difficulty": {"easy": {"iop_percent": 50.0, "rmse_misses_px": 12.3, "n": 10, "n_unpredicted": 1}}}}}}
    row = [l for l in accuracy_table(fake).splitlines() if l.startswith("| SG-VDNet | RGB | easy")][0].split("|")
    assert row[4].strip() == "50.0" and row[5].strip() == "94.2"


def test_timing_procedure_fields():
    r = time_callable(lambda: sum(range(100)), warmup=2, repeats=5)
    assert r["repeats"] == 5 and r["fps_from_mean"] > 0 and r["latency_ms_p95"] >= 0
    img = np.zeros((10, 10, 3), np.uint8)

    class M:
        def predict(self, i, b): return None
    b = benchmark(M(), [img], [(0, 0, 5, 5)], "test scope", warmup=1, repeats=3)
    assert b["scope"] == "test scope" and b["batch_size"] == 1 and "torch" in b["hardware"]


def test_cli_guards_and_smoke(env, tmp_path):
    d, rows, ann, sp, th, by = env
    script = os.path.join(os.path.dirname(__file__), "..", "scripts", "evaluate.py")
    db = build_reference_db(d, rows, ann, sp["train"], "rgb")
    dbp = str(tmp_path / "db.pkl")
    db.save(dbp)
    base = [sys.executable, script, "--root", d, "--method", "orb", "--orb-db", dbp, "--modality", "rgb", "--use-gt-box",
            "--max-images", "5", "--timing-repeats", "3", "--out", str(tmp_path / "o")]
    bad = subprocess.run(base + ["--split", "test"], capture_output=True, text=True)
    assert bad.returncode != 0 and "reserved" in (bad.stderr + bad.stdout)
    ok = subprocess.run(base + ["--split", "val"], capture_output=True, text=True)
    assert ok.returncode == 0, ok.stderr
    out = tmp_path / "o"
    s = json.load(open(out / "summary.json"))
    assert s["box_source"] == "ground-truth manifest box" and s["region_mode_available"]
    assert (out / "per_keypoint.csv").exists() and (out / "timing.json").exists()
