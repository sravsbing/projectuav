import os

import cv2
import numpy as np
import pytest

from baselines.orb import ORBBaseline, ORBConfig, ReferenceDB, build_reference_db, features
from data.annotations import read_annotations
from data.dataset import load_image_rgb_u8
from data.manifest import read_manifest
from data.splits import group_split
from data.synthetic import make_synthetic_dataset


@pytest.fixture(scope="module")
def env(tmp_path_factory):
    d = str(tmp_path_factory.mktemp("orb"))
    make_synthetic_dataset(d, n_groups=12, frames_per_group=4, seed=1)
    rows = read_manifest(os.path.join(d, "manifest.csv"))
    ann = read_annotations(os.path.join(d, "annotations.jsonl"))
    sp = group_split(rows, seed=1)
    db = build_reference_db(d, rows, ann, sp["train"], "rgb", allowed_ids=sp["train"])
    return d, rows, ann, sp, db, {r.sample_id: r for r in rows}


def _err(sk, gt, vis):
    return [np.linalg.norm(sk.keypoints[k] - gt[k]) for k in range(6) if vis[k] > 0 and not np.isnan(sk.keypoints[k, 0])]


def test_orientation_is_not_recomputed_by_opencv_compute():
    """The premise behind computing angles ourselves (see baselines/orb.py docstring)."""
    img = np.random.default_rng(0).integers(0, 255, (200, 200), dtype=np.uint8)
    k, _ = cv2.ORB_create(edgeThreshold=31, patchSize=31).compute(img, [cv2.KeyPoint(100, 100, 31, 77.0)])
    assert k[0].angle == 77.0


def test_self_match_recovers_training_labels(env):
    d, rows, ann, sp, db, by = env
    m, n = ORBBaseline(db), 0
    for sid in [s for s in sp["train"] if by[s].modality == "rgb"][:6]:
        r = by[sid]
        sk = m.predict(load_image_rgb_u8(os.path.join(d, r.image_path), "rgb"), r.bbox)
        e = _err(sk, ann[sid].keypoints, ann[sid].visibility)
        assert len(e) == 6 and max(e) < 0.5
        n += 1
    assert n


@pytest.mark.parametrize("deg", [90, 180])
def test_rotation_invariance_of_voting(env, deg):
    d, rows, ann, sp, db, by = env
    m = ORBBaseline(db)
    for sid in [s for s in sp["train"] if by[s].modality == "rgb"][:4]:
        r = by[sid]
        img = load_image_rgb_u8(os.path.join(d, r.image_path), "rgb")
        cx, cy = (r.bbox[0] + r.bbox[2]) / 2, (r.bbox[1] + r.bbox[3]) / 2
        M = cv2.getRotationMatrix2D((cx, cy), deg, 1.0)
        img2 = cv2.warpAffine(img, M, img.shape[1::-1], borderMode=cv2.BORDER_REPLICATE)
        P = lambda p: (M[:, :2] @ np.asarray(p, float).T).T + M[:, 2]
        c = P(np.array([[r.bbox[0], r.bbox[1]], [r.bbox[2], r.bbox[3]]]))
        box = (c[:, 0].min(), c[:, 1].min(), c[:, 0].max(), c[:, 1].max())
        e = _err(m.predict(img2, box), P(ann[sid].keypoints), ann[sid].visibility)
        assert len(e) >= 5 and np.median(e) < 3.0


def test_unsupported_keypoints_are_nan_not_fabricated(env):
    d, rows, ann, sp, db, by = env
    blank = np.full((480, 640, 3), 128, np.uint8)               # no features at all
    sk = ORBBaseline(db).predict(blank, (200, 150, 400, 330))
    assert sk is not None and np.isnan(sk.keypoints).all() and (sk.confidence == 0).all()


def test_db_refuses_samples_outside_the_allowed_train_set(env):
    d, rows, ann, sp, db, by = env
    with pytest.raises(ValueError, match="not in the allowed"):
        build_reference_db(d, rows, ann, sp["train"][:2] + sp["test"][:1], "rgb", allowed_ids=sp["train"])


def test_db_contains_only_train_images_and_one_modality(env):
    d, rows, ann, sp, db, by = env
    assert set(db.source_ids) <= set(sp["train"])
    assert all(by[s].modality == "rgb" for s in db.source_ids)


def test_save_load_roundtrip_and_subsampling(env, tmp_path):
    d, rows, ann, sp, db, by = env
    p = str(tmp_path / "db.pkl")
    db.save(p)
    db2 = ReferenceDB.load(p)
    assert len(db2) == len(db) and db2.cfg == db.cfg and db2.source_ids == db.source_ids
    small = build_reference_db(d, rows, ann, sp["train"], "rgb", ORBConfig(max_db_features=500, seed=3))
    again = build_reference_db(d, rows, ann, sp["train"], "rgb", ORBConfig(max_db_features=500, seed=3))
    assert len(small) == 500 and np.array_equal(small.desc, again.desc)


def test_detector_paths(env):
    d, rows, ann, sp, db, by = env
    img = np.full((480, 640, 3), 128, np.uint8)
    with pytest.raises(ValueError):
        ORBBaseline(db).predict(img)
    class NoDet:
        def detect(self, im): return None
    assert ORBBaseline(db, NoDet()).predict(img) is None


def test_features_empty_image_is_safe():
    xy, ang, sc, desc = features(np.full((256, 256), 100, np.uint8), ORBConfig())
    assert len(xy) == len(ang) == len(sc) == len(desc) == 0
