"""Audit tests use a tiny SYNTHETIC folder that mimics only the *shape* of the reported MMFW-UAV layout
(nested folder with an apostrophe, Bottom_Up/Horizontal/Top_Down, JSON/JSON, macOS debris). It says nothing about the real data."""
import json
import os
import subprocess
import sys

import numpy as np
import pytest

pytest.importorskip("PIL")
from PIL import Image

from data.audit import audit, inventory, scan_json, scan_xml
from data.fs_filter import is_junk_name, is_junk_path, walk_clean
from data.manifest_builder import build_manifest


def _img(path, size=(64, 48), grey=False):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    a = np.random.default_rng(0).integers(0, 255, (size[1], size[0], 3), dtype=np.uint8)
    if grey:
        a[..., 1] = a[..., 0]; a[..., 2] = a[..., 0]
    Image.fromarray(a).save(path)


def _xml(path, fn, w=64, h=48, box=(5, 6, 30, 40), name="UAV", extra=""):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    open(path, "w").write(f"<annotation><filename>{fn}</filename><size><width>{w}</width><height>{h}</height><depth>3</depth></size>"
                          f"<object><name>{name}</name><bndbox><xmin>{box[0]}</xmin><ymin>{box[1]}</ymin><xmax>{box[2]}</xmax><ymax>{box[3]}</ymax></bndbox>{extra}</object></annotation>")


@pytest.fixture()
def tree(tmp_path):
    r = str(tmp_path / "MMFW-UAV")
    bu = os.path.join(r, "Fixed-wing-UAV-A'", "Fixed-wing-UAV-A'", "Bottom_Up")
    for i in (1, 2, 3):
        _img(os.path.join(bu, f"{i:04d}.jpg"))
        _xml(os.path.join(bu, f"{i:04d}.xml"), f"{i:04d}.jpg")
    _xml(os.path.join(bu, "0003.xml"), "9999.jpg")                                     # filename mismatch
    _img(os.path.join(bu, "0004.jpg"))                                                 # image without annotation
    _xml(os.path.join(bu, "0077.xml"), "0077.jpg")                                     # xml without image
    open(os.path.join(bu, "0005.xml"), "w").write("<annotation><oops>")               # invalid xml
    _img(os.path.join(bu, "0006.jpg")); _xml(os.path.join(bu, "0006.xml"), "0006.jpg", w=99)   # size mismatch
    _img(os.path.join(bu, "0008.jpg")); _xml(os.path.join(bu, "0008.xml"), "0008.jpg", box=(5, 6, 200, 40))   # box beyond image width
    _img(os.path.join(r, "Horizontal", "0001.jpg"), grey=True)                         # duplicate stem in another folder
    _img(os.path.join(r, "Top_Down", "0100.jpg"))
    js = os.path.join(r, "JSON", "JSON")
    os.makedirs(js)
    json.dump({"imagePath": "0001.jpg", "shapes": [{"label": "head", "shape_type": "point", "points": [[1, 2]]}], "imageWidth": 64, "imageHeight": 48},
              open(os.path.join(js, "0001.json"), "w"))
    json.dump({"images": [], "annotations": [{"bbox": [1, 2, 3, 4], "keypoints": [1, 2, 2]}], "categories": [{"name": "uav"}]},
              open(os.path.join(js, "coco.json"), "w"))
    for junk in (os.path.join(bu, "._0001.jpg"), os.path.join(bu, "._0001.xml"), os.path.join(bu, ".DS_Store"),
                 os.path.join(r, "__MACOSX", "Fixed-wing-UAV-A'", "._0002.jpg"), os.path.join(r, "__MACOSX", "x", "._0009.xml")):
        os.makedirs(os.path.dirname(junk), exist_ok=True)
        open(junk, "wb").write(b"\x00\x05\x16\x07junk")
    return r


def test_junk_name_rules():
    assert all(is_junk_name(n) for n in ("._0001.jpg", ".DS_Store", "__MACOSX", "Thumbs.db"))
    assert not any(is_junk_name(n) for n in ("0001.jpg", "Bottom_Up", "_underscore.jpg", "a._b.jpg"))
    assert is_junk_path("a/__MACOSX/b/0001.jpg") and is_junk_path("a\\b\\._x.xml") and not is_junk_path("a/b/c.jpg")


def test_inventory_and_walk_exclude_junk(tree):
    inv = inventory(tree)
    allp = inv["images"] + inv["xml"] + inv["json"] + inv["other"]
    assert not any("._" in os.path.basename(p) or "__MACOSX" in p or ".DS_Store" in p for p in allp)
    assert len(inv["images"]) == 8 and len(inv["xml"]) == 7 and len(inv["json"]) == 2
    assert not any(is_junk_name(d) for _, dn, _ in walk_clean(tree) for d in dn)


def test_audit_counts_matching_and_problems(tree):
    rep = audit(tree)
    m = rep["matching"]
    assert list(rep["xml"]["failed"]) == ["Fixed-wing-UAV-A'/Fixed-wing-UAV-A'/Bottom_Up/0005.xml"]
    assert m["duplicate_image_stems"] == 1 and "0001" in m["duplicate_image_stem_examples"]
    assert m["xml_without_image"] == 2          # 0077 (no image) and the invalid 0005 (no 0005 image either)
    assert m["images_with_neither"] >= 2        # 0004 and 0100
    assert m["sampled_xml_filename_vs_image_mismatch"] == 1 and m["sampled_xml_filename_mismatch_examples"][0]["xml_filename"] == "9999.jpg"
    assert m["sampled_size_mismatch"] == 1 and m["sampled_size_mismatch_examples"][0]["xml_size"] == [99, 48]
    assert rep["xml"]["object_names"] == {"UAV": 6}
    assert rep["xml"]["files_without_box"] == 0 and m["sampled_xml_with_invalid_box"] == 1


def test_audit_reports_keypoints_only_when_present(tree):
    rep = audit(tree)
    assert rep["json"]["keypoint_fields"] == ["keypoints"] and rep["json"]["shape_types"] == {"point": 1}
    assert rep["capabilities"]["supports_structural_pose_training_as_is"]
    # box-only dataset: JSON removed -> no keypoint claim, and the note forbids box->keypoint conversion
    for f in os.listdir(os.path.join(tree, "JSON", "JSON")):
        os.remove(os.path.join(tree, "JSON", "JSON", f))
    rep2 = audit(tree)
    c = rep2["capabilities"]
    assert c["supports_aircraft_detection_training"] and not c["supports_structural_pose_training_as_is"]
    assert c["keypoint_fields_found_in_sampled_json"] == [] and "never converted" in c["note"]


def test_xml_extra_geometry_tags_are_detected(tmp_path):
    p = str(tmp_path / "a.xml")
    _xml(p, "a.jpg", extra="<keypoints><head>1,2</head></keypoints><polygon><pt>1</pt></polygon>")
    s = scan_xml(p)
    assert any("keypoints" in t for t in s["geometry_tags"]) and any("polygon" in t for t in s["geometry_tags"])
    assert s["objects"][0]["box"] == [5, 6, 30, 40]


def test_scan_json_survives_garbage(tmp_path):
    p = tmp_path / "bad.json"
    p.write_text("{not json")
    assert scan_json(str(p))["ok"] is False


def test_modality_evidence_is_reported_not_decided(tree):
    rep = audit(tree)
    ev = rep["modality_evidence"]
    hz = next(v for k, v in ev.items() if k.endswith("Horizontal"))
    assert hz["sampled_looking_greyscale"] == 1
    assert rep["stem_overlap_between_image_directories"]            # Horizontal/0001 vs Bottom_Up/0001
    assert "paired" not in json.dumps(rep["capabilities"]).lower()


def test_manifest_builder_skips_junk(tree):
    rows, problems = build_manifest(tree, [("rgb", "**/*.jpg", r"(?P<group>Bottom_Up|Horizontal|Top_Down)/")])
    assert rows and not any("._" in r.image_path or "__MACOSX" in r.image_path for r in rows)


def test_cli_runs_and_inspect_ignores_junk(tree, tmp_path):
    out = str(tmp_path / "rep.json")
    here = os.path.join(os.path.dirname(__file__), "..", "scripts")
    r = subprocess.run([sys.executable, os.path.join(here, "audit_dataset.py"), "--root", tree, "--out", out], capture_output=True, text=True)
    assert r.returncode == 0, r.stderr
    assert json.load(open(out))["counts"]["images"] == 8
    r = subprocess.run([sys.executable, os.path.join(here, "inspect_dataset.py"), "--root", tree, "--depth", "4"], capture_output=True, text=True)
    assert r.returncode == 0 and "ignored 5 junk" in r.stdout and "._" not in r.stdout.replace("._*", "")


# ------------------------------------------------------------------ optimisation / robustness (audit v2)
import importlib

from data import audit as audit_mod


def _many(tmp_path, n_xml=60, n_json=60, dirs=("Bottom_Up", "Horizontal", "Top_Down")):
    r = str(tmp_path / "big")
    for d in dirs:
        for i in range(n_xml):
            _xml(os.path.join(r, d, f"{i:04d}.xml"), f"{i:04d}.jpg")
        os.makedirs(os.path.join(r, "J", d), exist_ok=True)
        for i in range(n_json):
            json.dump({"shapes": []}, open(os.path.join(r, "J", d, f"{i:04d}.json"), "w"))
        os.makedirs(os.path.join(r, d, "junk"), exist_ok=True)
    _img(os.path.join(r, "Bottom_Up", "0000.jpg"))
    return r


def test_sample_even_and_select_are_deterministic_and_representative():
    items = [f"d/{i:03d}" for i in range(100)]
    s = audit_mod.sample_even(items, 5)
    assert s == audit_mod.sample_even(items, 5) and s[0] == items[0] and s[-1] == items[-1] and len(set(s)) == 5
    assert audit_mod.sample_even(items[:3], 10) == items[:3]
    files = [f"{d}/{i}.xml" for d in ("A", "B", "C") for i in range(50)]
    sel = audit_mod.select(files, per_group=20, cap=9)
    assert len(sel) == 9 and {os.path.dirname(f) for f in sel} == {"A", "B", "C"}          # cap keeps every directory represented
    assert len(audit_mod.select(files, 20, None)) == 60 and len(audit_mod.select(files, None, None)) == 150


def test_limits_are_honoured_and_report_says_sampled(tmp_path):
    r = _many(tmp_path)
    rep = audit(r, per_group=5, max_xml=12, max_json=7)
    assert rep["xml"]["sampled"] == 12 and rep["xml"]["of_total"] == 180 and rep["json"]["sampled"] == 7 and rep["json"]["of_total"] == 180
    assert set(rep["xml"]["sampled_per_directory"]) == {"Bottom_Up", "Horizontal", "Top_Down"}      # every viewpoint folder represented
    assert "SAMPLED 12 of 180" in rep["scope"]["xml_content"] and "EXHAUSTIVE" in rep["scope"]["inventory"]
    assert "EXHAUSTIVE" in rep["matching"]["scope"] and "sampled" in rep["capabilities"]["evidence_scope"]
    assert rep["counts"]["xml"] == 180 and rep["status"] == "complete"                                # counts remain exhaustive


def test_exhaustive_flag_lifts_limits(tmp_path):
    r = _many(tmp_path, n_xml=40, n_json=40)
    rep = audit(r, exhaustive=True)
    assert rep["xml"]["sampled"] == 120 and rep["json"]["sampled"] == 120 and rep["limits"]["exhaustive"] and rep["limits"]["max_xml"] is None


def test_junk_never_opened(tree, monkeypatch):
    opened = []
    for name in ("scan_xml", "scan_json", "image_size"):
        orig = getattr(audit_mod, name)
        monkeypatch.setattr(audit_mod, name, (lambda o: lambda p, *a, **k: (opened.append(p), o(p, *a, **k))[1])(orig))
    audit(tree)
    assert opened and not any(is_junk_path(os.path.relpath(p, tree)) for p in opened)


def test_oversize_and_malformed_files_are_recorded_not_fatal(tmp_path):
    r = str(tmp_path / "d")
    os.makedirs(r)
    open(os.path.join(r, "bad.json"), "w").write("{oops")
    open(os.path.join(r, "bad.xml"), "w").write("<a>")
    open(os.path.join(r, "empty.json"), "w").write("")
    open(os.path.join(r, "huge.json"), "w").write('{"a": "' + "x" * 2_000_000 + '"}')
    json.dump({"ok": 1}, open(os.path.join(r, "good.json"), "w"))
    rep = audit(r, max_file_mb=1.0)
    f = rep["json"]["failed"]
    assert set(f) == {"bad.json", "empty.json", "huge.json"} and "exceeds" in f["huge.json"] and rep["json"]["parsed_ok"] == 1
    assert "bad.xml" in rep["xml"]["failed"] and rep["status"] == "complete" and not rep["stage_errors"]


def test_stage_failure_is_isolated_and_partial_callbacks_fire(tree, monkeypatch):
    monkeypatch.setattr(audit_mod, "select", lambda *a, **k: (_ for _ in ()).throw(RuntimeError("boom")))
    seen = []
    rep = audit(tree, on_stage=lambda n, r: seen.append(n))
    assert set(rep["stage_errors"]) == {"xml", "json", "modality"} and rep["status"] == "complete_with_stage_errors"
    assert rep["counts"]["images"] == 8 and "matching" in rep and "capabilities" in rep        # later stages still ran
    assert seen[:3] == ["inventory", "xml", "json"] and seen[-1] == "final"


def test_progress_names_each_category(tree):
    msgs = []
    audit(tree, progress=msgs.append)
    text = "\n".join(msgs)
    for tag in ("[inventory]", "[xml]", "[json]", "[matching]", "[images]", "[capabilities]"):
        assert tag in text


def test_cli_partial_then_atomic_final_and_preserved_args(tree, tmp_path, capsys):
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "scripts"))
    mod = importlib.import_module("audit_dataset")
    out = str(tmp_path / "rep.json")
    json.dump({"previous": True}, open(out, "w"))
    # simulated Ctrl+C after the xml stage: previous report untouched, partial holds finished stages
    real = mod.audit

    def interrupted(*a, on_stage=None, **k):
        def cb(n, r):
            on_stage(n, r)
            if n == "xml":
                raise KeyboardInterrupt
        return real(*a, on_stage=cb, **k)
    mod.audit = interrupted
    try:
        assert mod.main(["--root", tree, "--out", out, "--quiet"]) == 130
    finally:
        mod.audit = real
    assert json.load(open(out)) == {"previous": True}
    part = json.load(open(out + ".partial"))
    assert "counts" in part and "xml" in part and "json" not in part and part["status"].startswith("interrupted")
    # normal run with the ORIGINAL arguments only
    assert mod.main(["--root", tree, "--out", out, "--max-size-checks", "5", "--quiet"]) == 0
    full = json.load(open(out))
    assert full["status"] == "complete" and full["limits"]["max_size_checks"] == 5 and not os.path.exists(out + ".partial")
    assert mod.main(["--root", str(tmp_path / "nope"), "--out", out]) == 2
