import numpy as np
import pytest
import torch

from data.keypoints import (KEYPOINT_NAMES, HEAD, BODY, LEFT_WING, RIGHT_WING, TAIL_UNIT, NUM_KEYPOINTS)
from data.transforms import CropTransform, square_crop_from_bbox, transform_keypoints
from data.heatmaps import (generate_heatmaps, soft_argmax, decode_argmax,
                           heatmap_to_input, input_to_heatmap, heatmap_coords_to_normalized)
from losses.heatmap_loss import masked_heatmap_mse, masked_point_mse
from losses.structural import structural_geometric_loss, total_loss

S, HM = 256, 64
STRIDE = S / HM


def _skeleton(batch=1):
    """Anatomically valid skeleton in normalised coords: head left, tail right, wings up/down."""
    k = torch.zeros(batch, NUM_KEYPOINTS, 2)
    k[:, HEAD] = torch.tensor([0.2, 0.5])
    k[:, BODY] = torch.tensor([0.5, 0.5])
    k[:, LEFT_WING] = torch.tensor([0.5, 0.2])
    k[:, RIGHT_WING] = torch.tensor([0.5, 0.8])
    k[:, 4] = torch.tensor([0.7, 0.5])
    k[:, TAIL_UNIT] = torch.tensor([0.85, 0.5])
    return k


def test_keypoint_order_is_fixed():
    assert KEYPOINT_NAMES == ("head", "body", "left_wing", "right_wing", "tail_joint", "tail_unit")
    assert (HEAD, BODY, LEFT_WING, RIGHT_WING, TAIL_UNIT) == (0, 1, 2, 3, 5)


# ---------- coordinate transforms ----------
def test_crop_roundtrip_and_known_values():
    tf = square_crop_from_bbox((100, 50, 300, 150), out_size=S, margin=0.1)
    assert tf.side == pytest.approx(200 * 1.2)
    pts = np.random.default_rng(0).uniform(0, 600, size=(10, 2))
    assert np.allclose(tf.to_original(tf.to_input(pts)), pts, atol=1e-9)
    # centre of the box maps to centre of the input
    c = tf.to_input(np.array([[200.0, 100.0]]))
    assert np.allclose(c, [[(S - 1) / 2, (S - 1) / 2]], atol=1e-6)


def test_identity_transform():
    tf = CropTransform(-0.5, -0.5, float(S), S)  # window = exactly the SxS image
    p = np.array([[10.3, 99.9]])
    assert np.allclose(tf.to_input(p), p)


def test_heatmap_input_coordinate_roundtrip():
    x = torch.rand(4, 6, 2) * S
    assert torch.allclose(heatmap_to_input(input_to_heatmap(x, STRIDE), STRIDE), x, atol=1e-4)


# ---------- visibility masking ----------
def test_out_of_crop_keypoint_becomes_invisible():
    tf = CropTransform(0.0, 0.0, 100.0, S)
    kps = np.array([[50, 50], [150, 50], [-10, 20], [99, 99], [0, 0], [50, 120]], dtype=float)
    _, vis = transform_keypoints(kps, np.ones(6), tf)
    assert vis.tolist() == [1, 0, 0, 1, 1, 0]


def test_already_missing_stays_missing():
    tf = CropTransform(0.0, 0.0, 100.0, S)
    _, vis = transform_keypoints(np.full((6, 2), 50.0), np.array([1, 0, 1, 0, 1, 0]), tf)
    assert vis.tolist() == [1, 0, 1, 0, 1, 0]


# ---------- heatmap generation ----------
def test_heatmap_peak_location_and_value():
    kps = torch.tensor([[[100.0, 60.0]] * NUM_KEYPOINTS])
    vis = torch.ones(1, NUM_KEYPOINTS)
    hm = generate_heatmaps(kps, vis, HM, S, sigma=2.0)
    assert hm.shape == (1, NUM_KEYPOINTS, HM, HM)
    c = input_to_heatmap(kps, STRIDE)[0, 0]
    iy, ix = np.unravel_index(hm[0, 0].argmax().item(), (HM, HM))
    assert (ix, iy) == (round(c[0].item()), round(c[1].item()))
    assert hm.max() <= 1.0 + 1e-6 and hm.max() > 0.9


def test_exact_cell_centre_peak_is_one():
    # input pixel that maps exactly onto heatmap cell (10, 20)
    xin = heatmap_to_input(torch.tensor([[[10.0, 20.0]]]), STRIDE)
    hm = generate_heatmaps(xin, torch.ones(1, 1), HM, S, 2.0)
    assert hm[0, 0, 20, 10].item() == pytest.approx(1.0, abs=1e-6)


def test_invisible_keypoint_gives_zero_heatmap():
    kps = torch.full((1, NUM_KEYPOINTS, 2), 100.0)
    vis = torch.tensor([[1, 0, 1, 0, 1, 0]])
    hm = generate_heatmaps(kps, vis, HM, S, 2.0)
    assert hm[0, 1].abs().sum() == 0 and hm[0, 0].abs().sum() > 0


def test_softargmax_and_argmax_recover_gaussian_centre():
    kps = torch.tensor([[[120.3, 77.7], [40.0, 200.0], [10.0, 10.0], [250.0, 250.0], [128.0, 128.0], [64.0, 190.0]]])
    hm = generate_heatmaps(kps, torch.ones(1, 6), HM, S, 2.0)
    sa = heatmap_to_input(soft_argmax(hm, beta=200.0), STRIDE)
    assert (sa - kps).abs().max() < STRIDE * 0.5  # within half a heatmap cell
    ar, conf = decode_argmax(hm, refine=True)
    assert (heatmap_to_input(ar, STRIDE) - kps).abs().max() < STRIDE * 0.75
    assert (conf > 0.8).all()


# ---------- heatmap loss ----------
def test_heatmap_loss_zero_on_perfect_and_masked():
    gt = torch.rand(2, 6, 8, 8)
    vis = torch.ones(2, 6)
    assert masked_heatmap_mse(gt.clone(), gt, vis).item() == 0.0
    pred = gt.clone()
    pred[:, 1] += 5.0  # corrupt channel 1
    vis_masked = vis.clone()
    vis_masked[:, 1] = 0
    assert masked_heatmap_mse(pred, gt, vis_masked).item() == 0.0   # blocked by mask
    assert masked_heatmap_mse(pred, gt, vis).item() > 0.0


def test_heatmap_loss_no_visible_is_zero_not_nan():
    p = torch.rand(1, 6, 4, 4, requires_grad=True)
    l = masked_heatmap_mse(p, torch.rand(1, 6, 4, 4), torch.zeros(1, 6))
    assert l.item() == 0.0
    l.backward()
    assert torch.isfinite(p.grad).all() and p.grad.abs().sum() == 0


def test_masked_channel_gets_no_gradient():
    p = torch.rand(1, 6, 4, 4, requires_grad=True)
    vis = torch.tensor([[1, 0, 1, 1, 1, 1]])
    masked_heatmap_mse(p, torch.rand(1, 6, 4, 4), vis).backward()
    assert p.grad[0, 1].abs().sum() == 0 and p.grad[0, 0].abs().sum() > 0


def test_point_mse_matches_manual():
    gt = torch.rand(2, 6, 2)
    pred = gt + 0.1
    vis = torch.ones(2, 6)
    assert masked_point_mse(pred, gt, vis).item() == pytest.approx(0.01, rel=1e-4)


# ---------- SGL ----------
def test_sgl_zero_for_valid_skeleton():
    assert structural_geometric_loss(_skeleton(), torch.ones(1, 6)).item() == 0.0


def test_sgl_positive_when_head_and_tail_same_side():
    k = _skeleton()
    k[:, HEAD] = torch.tensor([0.8, 0.5])  # head now on same side of body as tail
    # V_bh=(0.3,0), V_bt=(0.35,0) -> dot = 0.105
    assert structural_geometric_loss(k, torch.ones(1, 6)).item() == pytest.approx(0.105, abs=1e-6)


def test_sgl_positive_when_wings_same_side():
    k = _skeleton()
    k[:, RIGHT_WING] = torch.tensor([0.5, 0.1])  # both wings above body
    # V_bwL=(0,-0.3), V_bwR=(0,-0.4) -> 0.12
    assert structural_geometric_loss(k, torch.ones(1, 6)).item() == pytest.approx(0.12, abs=1e-6)


def test_sgl_both_terms_add():
    k = _skeleton()
    k[:, HEAD] = torch.tensor([0.8, 0.5])
    k[:, RIGHT_WING] = torch.tensor([0.5, 0.1])
    assert structural_geometric_loss(k, torch.ones(1, 6)).item() == pytest.approx(0.105 + 0.12, abs=1e-6)


def test_sgl_visibility_masking():
    k = _skeleton()
    k[:, HEAD] = torch.tensor([0.8, 0.5])
    vis = torch.ones(1, 6)
    vis[0, HEAD] = 0  # violating keypoint is unlabelled -> term skipped
    assert structural_geometric_loss(k, vis).item() == 0.0


def test_sgl_batch_mean():
    k = torch.cat([_skeleton(), _skeleton()])
    k[1, HEAD] = torch.tensor([0.8, 0.5])
    assert structural_geometric_loss(k, torch.ones(2, 6)).item() == pytest.approx(0.105 / 2, abs=1e-6)


def test_sgl_cosine_option_is_scale_free():
    k = _skeleton()
    k[:, HEAD] = torch.tensor([0.8, 0.5])
    assert structural_geometric_loss(k, torch.ones(1, 6), normalize_vectors=True).item() == pytest.approx(1.0, abs=1e-4)


def test_sgl_differentiable_through_heatmaps():
    # Heatmaps whose soft-argmax violates the constraint must receive gradient from SGL.
    gt_xy = _skeleton()[0] * S
    gt_xy[HEAD] = torch.tensor([0.8 * S, 0.5 * S])
    hm = generate_heatmaps(gt_xy.unsqueeze(0), torch.ones(1, 6), HM, S, 2.0).clone().requires_grad_(True)
    coords = heatmap_coords_to_normalized(soft_argmax(hm, beta=50.0), STRIDE, S)
    l = structural_geometric_loss(coords, torch.ones(1, 6))
    assert l.item() > 0
    l.backward()
    assert hm.grad is not None and torch.isfinite(hm.grad).all() and hm.grad.abs().sum() > 0


def test_total_loss_combination_and_ablation_switch():
    a, b = torch.tensor(0.5), torch.tensor(2.0)
    assert total_loss(a, b, 0.1).item() == pytest.approx(0.7)
    assert total_loss(a, b, 0.0).item() == pytest.approx(0.5)


def test_warp_matches_point_transform():
    """Image resampling and point transform must agree (a marker pixel lands where the points say)."""
    cv2 = pytest.importorskip("cv2")
    from data.transforms import crop_pad_resize
    img = np.zeros((200, 300), dtype=np.uint8)
    img[80:85, 150:155] = 255   # blob centred at (152, 82) in pixel-centre coords
    tf = square_crop_from_bbox((100, 40, 220, 120), out_size=128, margin=0.2)
    out = crop_pad_resize(img, tf, pad_value=0)
    ys, xs = np.nonzero(out > 127)
    cx_img, cy_img = xs.mean(), ys.mean()
    exp = tf.to_input(np.array([[152.0, 82.0]]))[0]
    assert abs(cx_img - exp[0]) < 0.75 and abs(cy_img - exp[1]) < 0.75
