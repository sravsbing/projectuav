import json
import os

import pytest

from data.annotations import read_annotations  # noqa: F401
from data.manifest import read_manifest
from data.splits import group_split, save_splits
from data.synthetic import make_synthetic_dataset
from experiments.plan import Trial, check_plan, ir_plan, rgb_plan
from experiments.report import markdown, summarize
from experiments.runner import run_trial, select_winners, winners_for_ir


def test_rgb_plan_equal_budget_and_literal_present():
    p = rgb_plan(100)
    check_plan(p, 100)
    per = {}
    for t in p:
        per[t.tags["arch"]] = per.get(t.tags["arch"], 0) + 1
    assert len(set(per.values())) == 1 and set(per) == {"point_net", "pg_vdnet", "sg_vdnet"}
    sg_lit = [t for t in p if t.method == "sg_vdnet" and t.literal]
    assert len(sg_lit) == 1 and "loss.hm_loss_scale" not in sg_lit[0].overrides and "loss.sg_warmup_epochs" not in sg_lit[0].overrides
    assert all(t.overrides["loss.type"] != "heatmap_mse_sgl" for t in p if t.method != "sg_vdnet")


def test_unequal_budget_is_rejected():
    p = rgb_plan(100)
    with pytest.raises(ValueError, match="unequal tuning budget"):
        check_plan(p[:-1], 100)


def test_transfer_must_freeze_backbone():
    bad = [Trial("m", "t", {"transfer.init_from": "x.pt", "transfer.freeze_backbone": False}, tags={"phase": "ir", "arch": "a", "kind": "k"})]
    with pytest.raises(ValueError, match="freeze"):
        check_plan(bad, 10)


def test_ir_plan_differs_only_in_initialisation():
    w = {a: {"overrides": {"loss.hm_loss_scale": 50.0}, "ckpt": f"{a}.pt"} for a in ("pg_vdnet", "sg_vdnet", "point_net")}
    p = ir_plan(w, (1e-3, 3e-4))
    check_plan(p, 100)
    sc = {t.name: t for t in p if t.method == "sg_vdnet__ir_scratch_random"}
    tr = {t.name: t for t in p if t.method == "sg_vdnet__ir_transfer"}
    for n in sc:
        a, b = dict(sc[n].overrides), dict(tr[n].overrides)
        for k in ("transfer.init_from", "transfer.freeze_backbone", "transfer.trainable"):
            b.pop(k)
        assert a == b                                  # same loss settings, lr, modality, arch: init is the only difference
    assert not any(t.method.startswith("point_net__ir_transfer") for t in p)
    assert all(t.overrides["data.modality"] == "ir" for t in p)


def test_select_winners_ignores_failures_and_keeps_literal():
    recs = [dict(status="ok", method="m", trial="a", best_val=5.0, literal=True, overrides={"train.lr": 1e-3, "x": 1}, best_ckpt="a.pt"),
            dict(status="ok", method="m", trial="b", best_val=3.0, literal=False, overrides={"train.lr": 3e-4, "x": 2}, best_ckpt="b.pt"),
            dict(status="failed", method="m", trial="c", error="boom", literal=False),
            dict(status="ok", method="n", trial="a", best_val=float("nan"), literal=False, overrides={}, best_ckpt="")]
    s = select_winners(recs)
    assert s["m"]["winner"]["trial"] == "b" and s["m"]["literal"]["trial"] == "a" and s["m"]["n_failed"] == 1
    assert "n" not in s or s["n"]["winner"] is None
    assert winners_for_ir(s)["m"] == {"overrides": {"x": 2}, "ckpt": "b.pt"}


@pytest.fixture(scope="module")
def tiny(tmp_path_factory):
    d = str(tmp_path_factory.mktemp("s5"))
    make_synthetic_dataset(d, n_groups=9, frames_per_group=3, seed=2, size=(320, 240))
    save_splits(os.path.join(d, "splits.json"), group_split(read_manifest(os.path.join(d, "manifest.csv")), seed=2), {"seed": 2})
    base = [f"data.root={d}", "train.epochs=2", "train.batch_size=8", "model.input_size=64",
            f"run.log_dir={d}/logs", f"run.ckpt_dir={d}/ck"]
    return d, base


def test_end_to_end_tiny_pipeline_resume_and_report(tiny):
    d, base = tiny
    rgb = rgb_plan(2, (1e-3,), archs=("pg_vdnet", "sg_vdnet"))
    check_plan(rgb, 2)
    recs = [run_trial(t, base, f"{d}/rgb", 7, "rgb") for t in rgb]
    assert all(r["status"] == "ok" for r in recs), [r.get("error") for r in recs]
    assert all(r["splits_used"] == ["train", "val"] and r["epochs_run"] == 2 for r in recs)
    again = run_trial(rgb[0], base, f"{d}/rgb", 7, "rgb")                 # resumed from JSON, not retrained
    assert again["best_val"] == recs[0]["best_val"]
    sel = select_winners(recs)
    ir = ir_plan(winners_for_ir(sel), (1e-3,), archs=("sg_vdnet",), include_imagenet_scratch=False)
    check_plan(ir, 2)
    irr = [run_trial(t, base, f"{d}/ir", 7, "ir") for t in ir]
    assert [r["status"] for r in irr] == ["ok", "ok"], [r.get("error") for r in irr]
    # frozen-backbone transfer really trains fewer parameters than scratch, same epochs
    tr = next(r for r in irr if r["method"].endswith("transfer")); sc = next(r for r in irr if r["method"].endswith("random"))
    assert tr["params"]["trainable"] < sc["params"]["trainable"] and tr["epochs_run"] == sc["epochs_run"] == 2
    md = markdown(summarize(sel, {}), summarize(select_winners(irr), {}))
    assert "NOT the paper's IoP/RMSE" in md and "VALIDATION" in md and "n/a" in md      # missing methods shown as n/a, not invented


def test_failed_pretrained_download_is_recorded_not_substituted(tiny, monkeypatch):
    d, base = tiny
    import models.vdnet as V
    def boom(*a, **k): raise OSError("blocked")
    monkeypatch.setattr(V.torchvision.models, "resnet18", boom, raising=False)
    t = Trial("sg_vdnet__ir_scratch_imagenet", "lr0.001", {"model.arch": "sg_vdnet", "loss.type": "heatmap_mse_sgl",
              "data.modality": "ir", "model.pretrained_backbone": True, "train.lr": 1e-3}, tags={"phase": "ir"})
    r = run_trial(t, base, f"{d}/irfail", 7, "ir")
    assert r["status"] == "failed" and "best_val" not in r
