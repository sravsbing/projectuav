import os

import numpy as np
import pytest
import torch

pytest.importorskip("cv2")

from data.annotation_session import AnnotationSession
from data.annotations import (Annotation, read_annotations, write_annotations, validate_annotation)
from data.bbox_parsers import parse_voc_xml, parse_center_txt, single_box
from data.dataset import SkeletonDataset, FLIP_PERMUTATION, load_image_rgb_u8
from data.heatmaps import decode_argmax, heatmap_to_input
from data.keypoints import LEFT_WING, RIGHT_WING, HEAD, NUM_KEYPOINTS
from data.manifest import (ManifestRow, read_manifest, validate_manifest, pairs, write_manifest)
from data.regions import (disc_region, distance_to_region, load_region_labels, region_for_keypoint)
from data.splits import group_split, verify_no_leakage, split_report, SPLITS
from data.synthetic import make_synthetic_dataset
from losses.structural import structural_geometric_loss
from visualization.keypoints import draw_skeleton, overlay_regions, make_grid


@pytest.fixture(scope="module")
def synth(tmp_path_factory):
    root = str(tmp_path_factory.mktemp("synth"))
    info = make_synthetic_dataset(root, n_groups=6, frames_per_group=4, seed=1)
    return root, info


# ---------------- annotations ----------------
def test_annotation_roundtrip_and_atomic_write(tmp_path):
    p = str(tmp_path / "a.jsonl")
    a = Annotation("s1", np.arange(12, dtype=float).reshape(6, 2), np.array([1, 1, 0, 1, 1, 1], np.uint8), "hard")
    write_annotations(p, {"s1": a})
    b = read_annotations(p)["s1"]
    assert np.allclose(b.keypoints, a.keypoints) and b.visibility.tolist() == [1, 1, 0, 1, 1, 1]
    assert b.difficulty == "hard"
    assert not [f for f in os.listdir(tmp_path) if f.endswith(".tmp")]


def test_duplicate_and_malformed_annotation_lines_are_loud(tmp_path):
    p = tmp_path / "a.jsonl"
    a = Annotation("s1", np.zeros((6, 2)), np.ones(6, np.uint8)).to_json()
    p.write_text(a + "\n" + a + "\n")
    with pytest.raises(ValueError, match="duplicate"):
        read_annotations(str(p))
    p.write_text("{not json}\n")
    with pytest.raises(ValueError, match="cannot parse"):
        read_annotations(str(p))


def test_validate_annotation_catches_problems():
    good = Annotation("s", np.tile([[100.0, 100.0]], (6, 1)) + np.arange(6)[:, None] * 20, np.ones(6, np.uint8), "easy")
    assert validate_annotation(good, 640, 480)[0] == []
    bad = Annotation("s", good.keypoints.copy(), np.ones(6, np.uint8), "medium")
    bad.keypoints[2] = (900, 100)
    errs, _ = validate_annotation(bad, 640, 480)
    assert any("outside" in e for e in errs) and any("difficulty" in e for e in errs)
    bad.visibility[2] = 0   # unlabelled keypoint may be anywhere: not an error
    bad.difficulty = None
    assert validate_annotation(bad, 640, 480)[0] == []
    nan = Annotation("s", np.full((6, 2), np.nan), np.ones(6, np.uint8))
    assert validate_annotation(nan)[0]
    wrong = Annotation("s", np.zeros((5, 2)), np.ones(5, np.uint8))
    assert validate_annotation(wrong)[0]


def test_far_outside_bbox_is_warning_only():
    a = Annotation("s", np.array([[10, 10]] * 5 + [[400, 400]], float), np.ones(6, np.uint8))
    errs, warns = validate_annotation(a, 640, 480, bbox_xyxy=(0, 0, 50, 50))
    assert errs == [] and any("far outside" in w for w in warns)


# ---------------- bbox parsers ----------------
def test_voc_and_center_parsers(tmp_path):
    xml = tmp_path / "a.xml"
    xml.write_text("<annotation><size><width>640</width><height>480</height></size><object><name>u</name>"
                   "<bndbox><xmin>10</xmin><ymin>20</ymin><xmax>110</xmax><ymax>70</ymax></bndbox></object></annotation>")
    boxes, wh = parse_voc_xml(str(xml))
    assert boxes == [(10.0, 20.0, 110.0, 70.0)] and wh == (640, 480)
    t = tmp_path / "a.txt"
    t.write_text("0 0.5 0.5 0.25 0.5\n")
    assert parse_center_txt(str(t), 640, 480) == [(240.0, 120.0, 400.0, 360.0)]
    t.write_text("0 200 100 100 50\n")      # pixel units auto-detected
    assert parse_center_txt(str(t)) == [(150.0, 75.0, 250.0, 125.0)]
    with pytest.raises(ValueError):
        single_box([(0, 0, 1, 1), (1, 1, 2, 2)], "x")


# ---------------- manifest / pairing ----------------
def test_manifest_roundtrip_validation_and_pairs(synth):
    root, info = synth
    rows = read_manifest(os.path.join(root, "manifest.csv"))
    assert len(rows) == len(info["rows"]) == 6 * 4 * 2
    errs, warns = validate_manifest(rows, root)
    assert errs == [] and warns == []
    pr = pairs(rows)
    assert len(pr) == 24 and set(pr["g0_f0"]) == {"rgb", "ir"}


def test_manifest_detects_problems(synth, tmp_path):
    root, _ = synth
    rows = read_manifest(os.path.join(root, "manifest.csv"))
    r0 = rows[0]
    bad = [r0, ManifestRow(r0.sample_id, "nope.png", "thermal", "g")]
    errs, _ = validate_manifest(bad, root)
    assert any("duplicate" in e for e in errs) and any("modality" in e for e in errs) and any("not found" in e for e in errs)
    a = ManifestRow("a", "rgb/g0_f0_rgb.png", "rgb", "g1", pair_id="p")
    b = ManifestRow("b", "ir/g0_f0_ir.png", "ir", "g2", pair_id="p")
    assert any("different groups" in e for e in validate_manifest([a, b], root)[0])
    c = ManifestRow("c", "rgb/g0_f0_rgb.png", "rgb", "g1", pair_id="p")
    assert any("same modality" in e for e in validate_manifest([a, c], root)[0])
    per_image = [ManifestRow(f"s{i}", "x", "rgb", f"g{i}") for i in range(10)]
    assert validate_manifest(per_image, check_files=False)[1]
    p = tmp_path / "m.csv"
    p.write_text("sample_id,image_path\na,b\n")
    with pytest.raises(ValueError, match="missing required"):
        read_manifest(str(p))


# ---------------- splits ----------------
def test_group_split_is_leakage_free_deterministic_and_stratified(tmp_path):
    info = make_synthetic_dataset(str(tmp_path), n_groups=12, frames_per_group=2, seed=2, with_regions=False)
    rows = info["rows"]
    s1 = group_split(rows, (0.5, 0.17, 0.33), seed=7)
    assert s1 == group_split(rows, (0.5, 0.17, 0.33), seed=7)           # deterministic
    verify_no_leakage(s1, rows)
    assert sum(len(v) for v in s1.values()) == len(rows)                 # every sample assigned once
    rep = split_report(s1, rows)
    assert all(rep["counts"][s] > 0 for s in SPLITS)
    assert rep["warnings"] == []                                         # all 3 aircraft in all 3 splits


def test_split_report_warns_when_data_too_small_to_stratify(synth):
    root, _ = synth                                                      # only 2 groups per aircraft
    rows = read_manifest(os.path.join(root, "manifest.csv"))
    s = group_split(rows, (0.5, 0.17, 0.33), seed=7)
    verify_no_leakage(s, rows)                                           # still leak-free
    rep = split_report(s, rows)
    assert any("no samples in val" in w or "empty" in w for w in rep["warnings"])


def test_verify_no_leakage_detects_violations(synth):
    root, _ = synth
    rows = read_manifest(os.path.join(root, "manifest.csv"))
    s = group_split(rows, (0.5, 0.17, 0.33), seed=7)
    # move one frame of a train group into test -> group leak
    sid = s["train"][0]
    leaked = {k: list(v) for k, v in s.items()}
    leaked["train"].remove(sid)
    leaked["test"].append(sid)
    with pytest.raises(AssertionError, match="spans splits"):
        verify_no_leakage(leaked, rows)
    dup = {k: list(v) for k, v in s.items()}
    dup["val"].append(s["train"][0])
    with pytest.raises(AssertionError):
        verify_no_leakage(dup, rows)


def test_rgb_ir_pairs_never_straddle_splits(synth):
    root, _ = synth
    rows = read_manifest(os.path.join(root, "manifest.csv"))
    s = group_split(rows, seed=3)
    where = {sid: k for k, v in s.items() for sid in v}
    for pid, d in pairs(rows).items():
        assert where[d["rgb"].sample_id] == where[d["ir"].sample_id]


# ---------------- regions ----------------
def test_distance_to_region_exact():
    reg = np.zeros((20, 20), bool)
    reg[5:10, 5:10] = True        # pixel squares cover [4.5, 9.5]
    assert distance_to_region(reg, (7, 7)) == 0.0
    assert distance_to_region(reg, (9.4, 7)) == 0.0
    assert distance_to_region(reg, (12.5, 7)) == pytest.approx(3.0)           # 3 px from edge 9.5
    assert distance_to_region(reg, (12.5, 12.5)) == pytest.approx(np.hypot(3, 3))  # corner distance
    assert distance_to_region(reg, (-5.5, 7)) == pytest.approx(10.0)          # outside the image
    assert distance_to_region(np.zeros((5, 5), bool), (1, 1)) == float("inf")


def test_region_labels_roundtrip_and_disc(synth):
    root, info = synth
    sid = "g0_f0_rgb"
    ann = info["annotations"][sid]
    labels = load_region_labels(os.path.join(root, ann.region_mask))
    for k in range(6):
        reg = region_for_keypoint(labels, k)
        assert reg.any() and distance_to_region(reg, ann.keypoints[k]) == 0.0
    d = disc_region((50, 50), (25, 25), 5)
    assert d[25, 25] and d[25, 30] and not d[25, 31]


# ---------------- dataset ----------------
def _ds(root, rows, anns, **kw):
    return SkeletonDataset(root, rows, anns, **kw)


def test_dataset_item_shapes_and_roundtrip(synth):
    root, _ = synth
    rows = read_manifest(os.path.join(root, "manifest.csv"))
    anns = read_annotations(os.path.join(root, "annotations.jsonl"))
    ds = _ds(root, rows, anns, modality="rgb", input_size=256, heatmap_size=64)
    assert len(ds) == 24
    it = ds[0]
    assert it["image"].shape == (3, 256, 256) and it["heatmaps"].shape == (6, 64, 64)
    assert it["keypoints_in"].shape == (6, 2) and it["visibility"].shape == (6,)
    tf = ds.transform_of(it)
    orig = anns[it["sample_id"]].keypoints
    assert np.allclose(tf.to_original(it["keypoints_in"].numpy()), orig, atol=1e-3)   # back to original coords
    assert it["visibility"].sum() == 6
    # heatmap peaks decode to the keypoints within one heatmap cell
    dec, _ = decode_argmax(it["heatmaps"][None])
    assert (heatmap_to_input(dec[0], 4.0) - it["keypoints_in"]).abs().max() < 4.0


def test_dataset_crop_pixels_align_with_keypoints(synth):
    """The synthetic aircraft is drawn through every keypoint, so the crop pixel there must be dark (rgb)."""
    root, _ = synth
    rows = read_manifest(os.path.join(root, "manifest.csv"))
    anns = read_annotations(os.path.join(root, "annotations.jsonl"))
    ds = _ds(root, rows, anns, modality="rgb")
    mean, std = torch.tensor([0.485, 0.456, 0.406]).view(3, 1, 1), torch.tensor([0.229, 0.224, 0.225]).view(3, 1, 1)
    for i in range(0, len(ds), 5):
        it = ds[i]
        px = (it["image"] * std + mean).mean(0)       # 0..1 grey
        bg = px[0, 0].item()
        for k in range(6):
            x, y = (int(round(float(v))) for v in it["keypoints_in"][k])
            assert px[y, x] < bg - 0.3, f"sample {i} kp {k}: keypoint not on aircraft pixels"


def test_ir_loading_and_modality_filter(synth):
    root, _ = synth
    rows = read_manifest(os.path.join(root, "manifest.csv"))
    anns = read_annotations(os.path.join(root, "annotations.jsonl"))
    ds = _ds(root, rows, anns, modality="ir")
    assert len(ds) == 24 and all(m == "ir" for m in (ds[i]["modality"] for i in range(3)))
    img = load_image_rgb_u8(os.path.join(root, rows[1].image_path), "ir")
    assert img.shape[2] == 3 and (img[..., 0] == img[..., 1]).all()


def test_missing_annotation_is_skipped_and_missing_bbox_is_error(synth):
    root, _ = synth
    rows = read_manifest(os.path.join(root, "manifest.csv"))
    anns = read_annotations(os.path.join(root, "annotations.jsonl"))
    anns.pop(rows[0].sample_id)
    assert len(_ds(root, rows, anns)) == len(rows) - 1
    nb = [ManifestRow(r.sample_id, r.image_path, r.modality, r.group_id) for r in rows]
    with pytest.raises(ValueError, match="no bbox"):
        _ds(root, nb, read_annotations(os.path.join(root, "annotations.jsonl")))


def test_keypoint_leaving_window_becomes_invisible(synth):
    root, _ = synth
    rows = read_manifest(os.path.join(root, "manifest.csv"))
    anns = read_annotations(os.path.join(root, "annotations.jsonl"))
    r = rows[0]
    x1, y1, x2, y2 = r.bbox
    tight = [ManifestRow(r.sample_id, r.image_path, r.modality, r.group_id, bbox=(x1 + 40, y1 + 40, x1 + 80, y1 + 80))]
    ds = SkeletonDataset(root, tight, anns, margin=0.0)
    assert ds[0]["visibility"].sum() < 6
    assert ds[0]["heatmaps"][ds[0]["visibility"] == 0].abs().sum() == 0


def test_jitter_is_reproducible_and_changes_crop(synth):
    root, _ = synth
    rows = read_manifest(os.path.join(root, "manifest.csv"))
    anns = read_annotations(os.path.join(root, "annotations.jsonl"))
    a = _ds(root, rows, anns, box_jitter=0.15, seed=5)
    b = _ds(root, rows, anns, box_jitter=0.15, seed=5)
    n = _ds(root, rows, anns, box_jitter=0.0)
    assert torch.equal(a[3]["crop"], b[3]["crop"])
    assert not torch.equal(a[3]["crop"], n[3]["crop"])
    a.set_epoch(1)
    assert not torch.equal(a[3]["crop"], b[3]["crop"])


def test_hflip_swaps_wings_and_keeps_skeleton_valid(synth):
    root, _ = synth
    rows = read_manifest(os.path.join(root, "manifest.csv"))
    anns = read_annotations(os.path.join(root, "annotations.jsonl"))
    base = _ds(root, rows, anns)[2]
    fl = _ds(root, rows, anns, hflip_prob=1.0)[2]
    assert fl["flipped"] and FLIP_PERMUTATION[LEFT_WING] == RIGHT_WING and FLIP_PERMUTATION[HEAD] == HEAD
    S = 256
    assert torch.allclose(fl["keypoints_in"][HEAD, 0], (S - 1) - base["keypoints_in"][HEAD, 0], atol=1e-4)
    assert torch.allclose(fl["keypoints_in"][LEFT_WING], torch.stack([(S - 1) - base["keypoints_in"][RIGHT_WING, 0],
                                                                       base["keypoints_in"][RIGHT_WING, 1]]), atol=1e-4)
    # flipped image still has the aircraft under the flipped keypoints
    px = (fl["image"] * torch.tensor([0.229, 0.224, 0.225]).view(3, 1, 1) + torch.tensor([0.485, 0.456, 0.406]).view(3, 1, 1)).mean(0)
    x, y = (int(round(float(v))) for v in fl["keypoints_in"][HEAD])
    assert px[y, x] < px[0, 0] - 0.3
    # the synthetic skeleton satisfies the SGL constraint in both orientations
    for it in (base, fl):
        assert structural_geometric_loss(it["keypoints_norm"][None], it["visibility"][None]).item() == 0.0


# ---------------- annotation session ----------------
def test_annotation_session_flow():
    anns = {}
    s = AnnotationSession(["a", "b"], anns, annotator="me")
    assert s.next_keypoint_name == "head"
    s.click(10, 20); s.click(30, 40); s.mark_missing(); s.click(1, 2)
    assert s.ptr == 4 and s.vis.tolist() == [1, 1, 0, 1, 0, 0]
    with pytest.raises(RuntimeError, match="unplaced"):
        s.commit()
    s.undo()
    assert s.ptr == 3 and s.vis.tolist() == [1, 1, 0, 0, 0, 0]
    s.click(5, 5); s.click(6, 6); s.click(7, 7)
    with pytest.raises(RuntimeError):
        s.click(0, 0)
    s.set_difficulty("hard")
    with pytest.raises(ValueError):
        s.set_difficulty("medium")
    a = s.commit()
    assert anns["a"] is a and a.difficulty == "hard" and a.annotator == "me"
    assert validate_annotation(a, 640, 480)[0] == []
    assert s.next_unlabelled() and s.sample_id == "b" and s.ptr == 0
    s.goto(0)
    assert s.ptr == NUM_KEYPOINTS and np.allclose(s.kps[0], (10, 20))   # existing labels reload for editing


# ---------------- visualisation ----------------
def test_draw_skeleton_and_overlays(synth):
    root, info = synth
    img = load_image_rgb_u8(os.path.join(root, "rgb/g0_f0_rgb.png"), "rgb")
    ann = info["annotations"]["g0_f0_rgb"]
    out = draw_skeleton(img, ann.keypoints, ann.visibility, labels=True, highlight=5)
    assert out.shape == img.shape and out.dtype == np.uint8 and (out != img).any() and out is not img
    vis = ann.visibility.copy(); vis[:] = 0
    assert np.array_equal(draw_skeleton(img, ann.keypoints, vis), img)       # nothing visible -> unchanged
    lab = load_region_labels(os.path.join(root, ann.region_mask))
    assert (overlay_regions(img, lab) != img).any()
    g = make_grid([out, out, out], ncols=2)
    assert g.shape[0] > out.shape[0] and g.shape[1] > out.shape[1]


# ---------------- validator + manifest builder ----------------
def test_validate_dataset_clean_and_with_injected_errors(synth, tmp_path):
    from data.validate import validate_dataset
    from data.splits import save_splits
    root, info = synth
    rows = read_manifest(os.path.join(root, "manifest.csv"))
    sp = group_split(rows, (0.5, 0.17, 0.33), seed=7)
    spath = str(tmp_path / "splits.json")
    save_splits(spath, sp, {})
    rep = validate_dataset(root, os.path.join(root, "manifest.csv"), os.path.join(root, "annotations.jsonl"),
                           spath, check_images=10)
    assert rep["ok"], rep["errors"]
    assert rep["annotations"]["coverage"] == 1.0 and rep["annotations"]["per_keypoint_labelled"] == [48] * 6
    assert rep["rgb_ir_label_offset_px"]["max"] == 0.0           # synthetic pairs share keypoints exactly
    assert rep["n_pairs_complete"] == 24
    # inject: out-of-image keypoint, unknown sample, leaking split
    anns = read_annotations(os.path.join(root, "annotations.jsonl"))
    anns["g0_f0_rgb"].keypoints[1] = (9999, 5)
    anns["ghost"] = Annotation("ghost", np.zeros((6, 2)), np.ones(6, np.uint8))
    bad_a = str(tmp_path / "bad.jsonl")
    write_annotations(bad_a, anns)
    leak = {k: list(v) for k, v in sp.items()}
    moved = leak["train"].pop(0)
    leak["test"].append(moved)
    lpath = str(tmp_path / "leak.json")
    save_splits(lpath, leak, {})
    rep = validate_dataset(root, os.path.join(root, "manifest.csv"), bad_a, lpath)
    assert not rep["ok"]
    txt = "\n".join(rep["errors"])
    assert "outside" in txt and "unknown sample ghost" in txt and "split leakage" in txt


def test_manifest_builder_from_regex_rules(synth, tmp_path):
    from data.manifest_builder import build_manifest
    root, info = synth
    lab = tmp_path / "lab"
    lab.mkdir()
    for r in info["rows"]:                                     # one VOC xml per image, stem-matched
        x1, y1, x2, y2 = r.bbox
        (lab / f"{os.path.splitext(os.path.basename(r.image_path))[0]}.xml").write_text(
            f"<annotation><size><width>640</width><height>480</height></size><object><bndbox><xmin>{x1}</xmin>"
            f"<ymin>{y1}</ymin><xmax>{x2}</xmax><ymax>{y2}</ymax></bndbox></object></annotation>")
    import shutil
    shutil.copytree(os.path.join(root, "rgb"), tmp_path / "rgb")
    shutil.copytree(os.path.join(root, "ir"), tmp_path / "ir")
    rx = r"(?P<pair>g(?P<group>\d+)_f\d+)_(?:rgb|ir)\.png"
    out, problems = build_manifest(str(tmp_path), [("rgb", "rgb/*.png", rx), ("ir", "ir/*.png", rx)],
                                   bbox_template="lab/{stem}.xml", read_sizes=False)
    assert len(out) == 48 and not problems["unmatched"] and not problems["no_bbox"]
    assert all(r.bbox is not None and r.width == 640 for r in out)       # size taken from the VOC <size>
    errs, _ = validate_manifest(out, str(tmp_path))
    assert errs == []
    assert len(pairs(out)) == 24
    # a file whose name does not fit the regex is reported, not dropped silently
    (tmp_path / "rgb" / "weird.png").write_bytes((tmp_path / "rgb" / "g0_f0_rgb.png").read_bytes())
    _, problems = build_manifest(str(tmp_path), [("rgb", "rgb/*.png", rx)])
    assert problems["unmatched"] == ["rgb/weird.png"]
