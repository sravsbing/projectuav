import json
import os
import types

import numpy as np
import pytest
import torch
import torchvision
import yaml
from torch.utils.data import default_collate

pytest.importorskip("cv2")

from data.annotations import read_annotations
from data.dataset import SkeletonDataset, load_image_rgb_u8
from data.heatmaps import generate_heatmaps
from data.keypoints import BODY, HEAD, TAIL_UNIT, NUM_KEYPOINTS
from data.manifest import read_manifest
from data.splits import group_split, save_splits
from data.synthetic import make_synthetic_dataset
from data.transforms import CropTransform, square_crop_from_bbox, transform_keypoints
from models.detector import Detection, FixedBoxDetector, YoloV8Detector
from models.pipeline import VulnerabilityPipeline
from models.postprocess import (adjacency_matrix, decode_batch_original, decode_points_to_input,
                                inputs_to_original_torch, original_to_inputs_torch)
from models.vdnet import PGVDNet, PointRegressionNet, SGVDNet, VDNet, build_model
from training.config import apply_overrides, load_config, validate_config
from training.trainer import compute_loss, run_training
from training.utils import load_checkpoint
from training.yolo_export import export_yolo_dataset


# ------------------------------------------------------------------ models
@pytest.mark.parametrize("S", [64, 128, 256])
def test_vdnet_output_shapes(S):
    m = SGVDNet().eval()
    x = torch.randn(2, 3, S, S)
    with torch.no_grad():
        assert m.backbone(x).shape == (2, 512, S // 32, S // 32)
        assert m(x).shape == (2, NUM_KEYPOINTS, S // 4, S // 4)
    assert VDNet.heatmap_size(S) == S // 4
    with pytest.raises(ValueError):
        VDNet.heatmap_size(100)


def test_point_net_shape_and_initial_prediction_is_crop_centre():
    m = PointRegressionNet().eval()
    with torch.no_grad():
        out = m(torch.randn(3, 3, 64, 64))
    assert out.shape == (3, NUM_KEYPOINTS, 2) and torch.allclose(out, torch.full_like(out, 0.5))


def test_backbone_is_resnet18_and_head_has_three_transposed_convs():
    m = SGVDNet()
    ref = torchvision.models.resnet18(weights=None)
    ref_params = sum(p.numel() for n, p in ref.named_parameters() if not n.startswith("fc."))
    assert sum(p.numel() for p in m.backbone.parameters()) == ref_params
    assert len([x for x in m.head.deconv if isinstance(x, torch.nn.ConvTranspose2d)]) == 3
    assert m.head.final.out_channels == NUM_KEYPOINTS


def test_pg_and_sg_are_the_same_network_with_different_declared_loss():
    pg, sg = PGVDNet(), SGVDNet()
    assert {k: v.shape for k, v in pg.state_dict().items()} == {k: v.shape for k, v in sg.state_dict().items()}
    assert (pg.default_sg_weight, sg.default_sg_weight) == (0.0, 0.1) and pg.name != sg.name
    with pytest.raises(ValueError):
        build_model("resnet50")


def test_pretrained_failure_is_loud_not_silent(monkeypatch):
    def boom(*a, **k):
        raise OSError("blocked")
    monkeypatch.setattr(torchvision.models, "resnet18", boom)
    with pytest.raises(RuntimeError, match="ImageNet"):
        SGVDNet(pretrained_backbone=True)


# ------------------------------------------------------------------ freezing (transfer)
def _bn_snapshot(mod):
    return {k: v.clone() for k, v in mod.state_dict().items()}


def test_frozen_backbone_does_not_change_weights_or_bn_statistics():
    torch.manual_seed(0)
    m = SGVDNet()
    m.set_trainable(["head"])
    assert not any(p.requires_grad for p in m.backbone.parameters())
    assert all(p.requires_grad for p in m.head.parameters())
    before_bb, before_head = _bn_snapshot(m.backbone), _bn_snapshot(m.head)
    opt = torch.optim.Adam(m.trainable_parameters(), lr=1e-2)
    m.train()
    assert not any(b.training for b in m.modules() if isinstance(b, torch.nn.BatchNorm2d) and b in m._frozen_bn)
    for _ in range(2):
        loss = m(torch.randn(4, 3, 64, 64)).pow(2).mean()
        opt.zero_grad()
        loss.backward()
        opt.step()
    after_bb = _bn_snapshot(m.backbone)
    assert all(torch.equal(before_bb[k], after_bb[k]) for k in before_bb)      # weights AND running stats
    assert not all(torch.equal(before_head[k], v) for k, v in _bn_snapshot(m.head).items())
    assert m.count_parameters()["trainable"] < m.count_parameters()["total"]


def test_partial_unfreeze_and_prefix_matching():
    m = SGVDNet()
    m.set_trainable(["head", "backbone.layer4"])
    assert all(p.requires_grad for p in m.backbone.layer4.parameters())
    assert not any(p.requires_grad for p in m.backbone.layer3.parameters())
    m.train()
    assert m.backbone.layer4[0].bn1.training and not m.backbone.layer3[0].bn1.training
    m.set_trainable(["hea"])                                     # prefix must match whole name components
    assert not m.trainable_parameters()


# ------------------------------------------------------------------ postprocess
def test_torch_crop_maths_matches_numpy_crop_transform():
    S = 256
    tf = CropTransform(37.5, 12.25, 310.0, S)
    pts = np.random.default_rng(0).uniform(0, 600, size=(2, 6, 2))
    crop = torch.tensor([[tf.x0, tf.y0, tf.side]] * 2, dtype=torch.float64)
    xin = original_to_inputs_torch(torch.from_numpy(pts), crop, S)
    assert np.allclose(xin.numpy(), tf.to_input(pts), atol=1e-9)
    assert np.allclose(inputs_to_original_torch(xin, crop, S).numpy(), pts, atol=1e-9)


def test_decode_gt_heatmaps_recovers_original_coordinates():
    S = 128
    rng = np.random.default_rng(1)
    tf = square_crop_from_bbox((100, 80, 380, 260), S, 0.1)
    kp_orig = rng.uniform([150, 100], [330, 240], size=(6, 2))
    kp_in, vis = transform_keypoints(kp_orig, np.ones(6), tf)
    hm = generate_heatmaps(torch.from_numpy(kp_in)[None], torch.from_numpy(vis)[None].float(), S // 4, S, 1.5)
    crop = torch.tensor([[tf.x0, tf.y0, tf.side]], dtype=torch.float64)
    xo, conf, _ = decode_batch_original(hm.double(), crop, S)
    tol = 0.6 * 4 * tf.side / S                                  # within ~half a heatmap cell, in original px
    assert np.abs(xo[0].numpy() - kp_orig).max() < tol and (conf > 0.7).all()


def test_point_decode_inverse_of_normalisation():
    xin = torch.rand(2, 6, 2) * 255
    assert torch.allclose(decode_points_to_input((xin + 0.5) / 256, 256), xin, atol=1e-4)


def test_adjacency_matrix_is_symmetric_skeleton():
    a = adjacency_matrix()
    assert (a == a.T).all() and a.sum() == 10 and a[HEAD, BODY] == 1 and a[HEAD, TAIL_UNIT] == 0


# ------------------------------------------------------------------ detector + pipeline
def test_detector_selection_and_fixed_box():
    fake = types.SimpleNamespace(boxes=types.SimpleNamespace(
        conf=torch.tensor([0.2, 0.9, 0.5]),
        xyxy=torch.tensor([[0., 0, 1, 1], [10., 20, 30, 40], [5., 5, 6, 6]]),
        __len__=lambda self=None: 3))

    class Boxes:
        conf = torch.tensor([0.2, 0.9, 0.5])
        xyxy = torch.tensor([[0., 0, 1, 1], [10., 20, 30, 40], [5., 5, 6, 6]])
        def __len__(self): return 3
    d = YoloV8Detector._best(types.SimpleNamespace(boxes=Boxes()))
    assert d.box_xyxy == (10.0, 20.0, 30.0, 40.0) and d.conf == pytest.approx(0.9)

    class Empty:
        def __len__(self): return 0
    assert YoloV8Detector._best(types.SimpleNamespace(boxes=Empty())) is None
    assert YoloV8Detector._best(types.SimpleNamespace(boxes=None)) is None
    assert FixedBoxDetector((1, 2, 3, 4)).detect(np.zeros((5, 5, 3), np.uint8)).box_xyxy == (1.0, 2.0, 3.0, 4.0)


def test_untrained_yolov8_runs_end_to_end_without_error():
    pytest.importorskip("ultralytics")
    det = YoloV8Detector("yolov8n.yaml", conf=0.001, imgsz=320)       # architecture only, random weights
    r = det.detect(np.random.default_rng(0).integers(0, 255, (240, 320, 3), dtype=np.uint8))
    assert r is None or (len(r.box_xyxy) == 4 and 0.0 <= r.conf <= 1.0)


@pytest.fixture(scope="module")
def synth(tmp_path_factory):
    root = str(tmp_path_factory.mktemp("synth3"))
    make_synthetic_dataset(root, n_groups=9, frames_per_group=2, seed=3, with_regions=False)
    rows = read_manifest(os.path.join(root, "manifest.csv"))
    anns = read_annotations(os.path.join(root, "annotations.jsonl"))
    sp = group_split(rows, (0.5, 0.17, 0.33), seed=1)
    save_splits(os.path.join(root, "splits.json"), sp, {})
    return root, rows, anns, sp


class _Oracle(torch.nn.Module):
    """Pretends to be a perfect network: returns the ground-truth heatmaps of the crop the pipeline will make."""
    def __init__(self, hm, output_type="heatmap"):
        super().__init__()
        self.hm, self.output_type = hm, output_type

    def forward(self, x):
        return self.hm


def test_pipeline_full_chain_recovers_ground_truth_with_oracle_network(synth):
    root, rows, anns, _ = synth
    r = next(x for x in rows if x.modality == "rgb")
    img = load_image_rgb_u8(os.path.join(root, r.image_path), "rgb")
    S = 128
    tf = square_crop_from_bbox(r.bbox, S, 0.1)
    kp_in, vis = transform_keypoints(anns[r.sample_id].keypoints, anns[r.sample_id].visibility, tf)
    hm = generate_heatmaps(torch.from_numpy(kp_in)[None], torch.from_numpy(vis)[None].float(), S // 4, S, 1.5)
    pipe = VulnerabilityPipeline(_Oracle(hm), FixedBoxDetector(r.bbox), input_size=S, margin=0.1, device="cpu")
    sk = pipe.predict(img)
    assert sk.keypoints.shape == (6, 2) and sk.adjacency.shape == (6, 6) and sk.box == tuple(r.bbox)
    assert np.abs(sk.keypoints - anns[r.sample_id].keypoints).max() < 0.6 * 4 * tf.side / S
    # the point-regression head goes through the same chain
    norm = torch.from_numpy((kp_in + 0.5) / S).float()[None]
    sk2 = VulnerabilityPipeline(_Oracle(norm, "points"), FixedBoxDetector(r.bbox), S, 0.1, "cpu").predict(img)
    assert np.abs(sk2.keypoints - anns[r.sample_id].keypoints).max() < 1e-3


def test_pipeline_returns_none_when_nothing_detected(synth):
    class NoDet:
        def detect(self, img): return None
    root, rows, _, _ = synth
    img = load_image_rgb_u8(os.path.join(root, rows[0].image_path), "rgb")
    pipe = VulnerabilityPipeline(SGVDNet(), NoDet(), 64, device="cpu")
    assert pipe.predict(img) is None                              # a miss, never a fallback box
    assert pipe.predict(img, box_xyxy=rows[0].bbox) is not None   # explicit GT-box mode still works


# ------------------------------------------------------------------ config
def test_config_overrides_and_validation():
    cfg = load_config(None, ["train.lr=3e-4", "model.arch=pg_vdnet", "loss.type=heatmap_mse",
                             "transfer.trainable=[head,backbone.layer4]", "data.splits=null"])
    assert cfg["train"]["lr"] == pytest.approx(3e-4) and cfg["transfer"]["trainable"] == ["head", "backbone.layer4"]
    with pytest.raises(KeyError):
        load_config(None, ["train.nonexistent=1"])
    with pytest.raises(KeyError):
        load_config(None, ["trian.lr=1"])
    for bad in (["model.input_size=100"], ["loss.type=point_mse"], ["model.arch=point_net"],
                ["model.arch=pg_vdnet"], ["loss.sg_weight=0"], ["transfer.freeze_backbone=true", "transfer.trainable=[]"]):
        with pytest.raises(ValueError):
            load_config(None, bad)
    assert load_config(None, ["model.arch=point_net", "loss.type=point_mse"])["model"]["arch"] == "point_net"


# ------------------------------------------------------------------ loss dispatch
@pytest.fixture(scope="module")
def batch(synth):
    root, rows, anns, _ = synth
    ds = SkeletonDataset(root, rows, anns, modality="rgb", input_size=64, heatmap_size=16, sigma=1.5)
    return default_collate([ds[i] for i in range(4)])


def _violating_output(batch):
    k = batch["keypoints_in"].clone()
    k[:, HEAD] = k[:, BODY] + 0.8 * (k[:, TAIL_UNIT] - k[:, BODY])      # head on the tail's side of the body
    return generate_heatmaps(k, batch["visibility"], 16, 64, 1.5)


def test_loss_dispatch_pg_sg_and_point(batch):
    out = _violating_output(batch)
    pg = load_config(None, ["model.input_size=64", "model.arch=pg_vdnet", "loss.type=heatmap_mse"])
    sg = load_config(None, ["model.input_size=64"])
    m = SGVDNet()
    t_pg, p_pg = compute_loss(m, out, batch, pg)
    t_sg, p_sg = compute_loss(m, out, batch, sg)
    assert p_sg["l_sg"] > 0 and torch.allclose(p_pg["l_sg"], p_sg["l_sg"])           # SGL measured in both...
    assert torch.allclose(t_pg, p_pg["l_main"])                                      # ...but only SG adds it
    assert torch.allclose(t_sg, p_sg["l_main"] + 0.1 * p_sg["l_sg"], atol=1e-7)
    pt = load_config(None, ["model.arch=point_net", "loss.type=point_mse", "model.input_size=64"])
    pm = PointRegressionNet()
    t_pt, _ = compute_loss(pm, torch.full((4, 6, 2), 0.5, requires_grad=True), batch, pt)
    assert torch.isfinite(t_pt) and t_pt > 0


def test_sgl_gradient_reaches_network_parameters(batch):
    cfg = load_config(None, ["model.input_size=64"])
    m = SGVDNet().train()
    out = m(batch["image"])
    # make SGL the only loss term to prove it back-propagates through soft-argmax into the weights
    cfg["loss"]["hm_loss_scale"] = 0.0
    loss, parts = compute_loss(m, out, batch, cfg)
    loss.backward()
    assert m.head.final.weight.grad is not None and torch.isfinite(m.head.final.weight.grad).all()


# ------------------------------------------------------------------ YOLO export
def test_yolo_export_layout_and_label_math(synth, tmp_path):
    root, rows, _, sp = synth
    info = export_yolo_dataset(root, rows, sp, str(tmp_path / "y"))
    by_id = {r.sample_id: r for r in rows}
    for s in ("train", "val", "test"):
        assert info["counts"][s] == len(sp[s])
        assert len(os.listdir(tmp_path / "y" / "labels" / s)) == len(sp[s])
    sid = sp["train"][0]
    r = by_id[sid]
    vals = [float(v) for v in open(tmp_path / "y" / "labels" / "train" / f"{sid}.txt").read().split()]
    x1, y1, x2, y2 = r.bbox
    assert vals[0] == 0 and vals[1] == pytest.approx((x1 + x2) / 2 / r.width, abs=1e-5)
    assert vals[4] == pytest.approx((y2 - y1) / r.height, abs=1e-5)
    assert all(0 <= v <= 1 for v in vals[1:])
    y = yaml.safe_load(open(info["yaml"]))
    assert y["names"] == {0: "uav"} and y["train"] == "images/train" and y["val"] == "images/val"
    assert only_rgb(export_yolo_dataset(root, rows, sp, str(tmp_path / "y2"), ("rgb",)), sp, by_id)


def only_rgb(info, sp, by_id):
    return info["counts"]["train"] == sum(by_id[i].modality == "rgb" for i in sp["train"])


# ------------------------------------------------------------------ trainer
def _cfg(synth, tmp_path, name, **over):
    root = synth[0]
    sets = [f"data.root={root}", "data.modality=rgb", "model.input_size=64", "train.epochs=2", "train.batch_size=4",
            "train.box_jitter=0.0", f"run.name={name}", f"run.log_dir={tmp_path}/logs", f"run.ckpt_dir={tmp_path}/ckpt",
            "heatmap.sigma=1.5"] + [f"{k}={v}" for k, v in over.items()]
    return load_config(None, sets)


def test_training_writes_logs_checkpoints_and_selects_on_val(synth, tmp_path):
    s = run_training(_cfg(synth, tmp_path, "a"), device="cpu", verbose=False)
    ld, cd = s["log_dir"], os.path.dirname(s["best_ckpt"])
    for f in ("config.yaml", "env.json", "metrics.jsonl"):
        assert os.path.isfile(os.path.join(ld, f))
    assert os.path.isfile(s["best_ckpt"]) and os.path.isfile(s["last_ckpt"]) and not [f for f in os.listdir(cd) if f.endswith(".tmp")]
    hist = [json.loads(l) for l in open(os.path.join(ld, "metrics.jsonl"))]
    assert [h["epoch"] for h in hist] == [0, 1]
    assert all(np.isfinite(h["train_loss"]) and np.isfinite(h["val_kp_error_px"]) for h in hist)
    assert len(hist[0]["val_kp_error_per_keypoint_px"]) == 6
    assert s["best_epoch"] == int(np.argmin([h["val_kp_error_px"] for h in hist]))
    ck = load_checkpoint(s["best_ckpt"])
    assert ck["arch"] == "sg_vdnet" and ck["cfg"]["seed"] == 42
    SGVDNet().load_state_dict(ck["model"])
    env = json.load(open(os.path.join(ld, "env.json")))
    assert env["splits_used"] == ["train", "val"] and env["seed"] == 42


def test_training_never_reads_the_test_split(synth, tmp_path, monkeypatch):
    import training.trainer as T
    real = T.load_splits

    class NoTest(dict):
        def __getitem__(self, k):
            assert k != "test", "trainer touched the test split"
            return super().__getitem__(k)
    monkeypatch.setattr(T, "load_splits", lambda p: NoTest(real(p)))
    run_training(_cfg(synth, tmp_path, "notest", **{"train.epochs": 1}), device="cpu", verbose=False)


def test_same_seed_reproduces_and_different_seed_differs(synth, tmp_path):
    a = run_training(_cfg(synth, tmp_path, "s1", **{"train.epochs": 1, "deterministic": "true"}), "cpu", False)
    b = run_training(_cfg(synth, tmp_path, "s2", **{"train.epochs": 1, "deterministic": "true"}), "cpu", False)
    c = run_training(_cfg(synth, tmp_path, "s3", **{"train.epochs": 1, "seed": 7}), "cpu", False)
    assert a["history"][0]["train_loss"] == pytest.approx(b["history"][0]["train_loss"], rel=1e-5, abs=1e-9)
    assert a["history"][0]["train_loss"] != pytest.approx(c["history"][0]["train_loss"], rel=1e-6)


def test_resume_continues_from_last_epoch(synth, tmp_path):
    first = run_training(_cfg(synth, tmp_path, "r"), "cpu", False)
    cfg = _cfg(synth, tmp_path, "r", **{"train.epochs": 3, "train.resume": first["last_ckpt"]})
    second = run_training(cfg, "cpu", False)
    hist = [json.loads(l) for l in open(os.path.join(second["log_dir"], "metrics.jsonl"))]
    assert [h["epoch"] for h in hist] == [0, 1, 2]


def test_ir_transfer_with_frozen_backbone_changes_only_the_head(synth, tmp_path):
    pre = run_training(_cfg(synth, tmp_path, "rgbpre"), "cpu", False)
    cfg = _cfg(synth, tmp_path, "irft", **{"data.modality": "ir", "transfer.init_from": pre["best_ckpt"],
                                          "transfer.freeze_backbone": "true"})
    ft = run_training(cfg, "cpu", False)
    before, after = load_checkpoint(pre["best_ckpt"])["model"], load_checkpoint(ft["last_ckpt"])["model"]
    bb = [k for k in before if k.startswith("backbone.")]
    assert bb and all(torch.equal(before[k], after[k]) for k in bb)                  # weights + BN stats untouched
    assert any(not torch.equal(before[k], after[k]) for k in before if k.startswith("head."))
    assert ft["params"]["trainable"] < ft["params"]["total"]
    assert len(ft["history"]) == len(pre["history"]) == 2                            # equal epochs, as required
    wrong_arch = _cfg(synth, tmp_path, "bad", **{"model.arch": "point_net", "loss.type": "point_mse",
                                                "transfer.init_from": pre["best_ckpt"]})
    with pytest.raises(ValueError, match="arch"):
        run_training(wrong_arch, "cpu", False)


def test_sgl_warmup_scales_only_the_structural_term(batch):
    out = _violating_output(batch)
    cfg = load_config(None, ["model.input_size=64", "loss.sg_warmup_epochs=10"])
    m = SGVDNet()
    t0, p0 = compute_loss(m, out, batch, cfg, sg_scale=0.0)
    t5, p5 = compute_loss(m, out, batch, cfg, sg_scale=0.5)
    t1, p1 = compute_loss(m, out, batch, cfg, sg_scale=1.0)
    assert torch.allclose(t0, p0["l_main"]) and p0["l_sg"] > 0                   # SGL still measured/logged at scale 0
    assert torch.allclose(t5, p5["l_main"] + 0.05 * p5["l_sg"], atol=1e-7)
    assert torch.allclose(t1, p1["l_main"] + 0.10 * p1["l_sg"], atol=1e-7)
    with pytest.raises(ValueError):
        load_config(None, ["loss.sg_warmup_epochs=-1"])


def test_warmup_schedule_is_logged_per_epoch(synth, tmp_path):
    s = run_training(_cfg(synth, tmp_path, "warm", **{"train.epochs": 3, "loss.sg_warmup_epochs": 2}), "cpu", False)
    assert [h["sg_scale"] for h in s["history"]] == [0.0, 0.5, 1.0]
    s0 = run_training(_cfg(synth, tmp_path, "nowarm", **{"train.epochs": 2}), "cpu", False)
    assert [h["sg_scale"] for h in s0["history"]] == [1.0, 1.0]                  # default = paper-faithful constant


def _memorise(synth, tmp_path, name, overrides):
    """Train on 8 images (train==val) with the REAL trainer; return (final kp error px, centre baseline px)."""
    root, rows, anns, _ = synth
    ids = [r.sample_id for r in rows if r.modality == "rgb"][:8]
    spl = str(tmp_path / f"{name}_splits.json")
    save_splits(spl, {"train": ids, "val": ids, "test": []}, {})
    cfg = _cfg(synth, tmp_path, name, **{"data.splits": spl, "model.input_size": 96, "train.epochs": 100,
                                        "train.batch_size": 8, "train.lr": 1e-3, **overrides})
    s = run_training(cfg, "cpu", verbose=False)
    ds = SkeletonDataset(root, rows, anns, sample_ids=ids, modality="rgb", input_size=96, heatmap_size=24, sigma=1.5)
    b = default_collate([ds[i] for i in range(len(ds))])
    gt = inputs_to_original_torch(b["keypoints_in"].double(), b["crop"], 96)
    centre = inputs_to_original_torch(torch.full_like(b["keypoints_in"], 47.5).double(), b["crop"], 96)
    return s["history"][-1]["val_kp_error_px"], float((centre - gt).norm(dim=-1).mean())


@pytest.mark.slow
@pytest.mark.parametrize("name,overrides", [
    ("hm_only", {"loss.type": "heatmap_mse"}),
    ("sgl_warmup", {"loss.type": "heatmap_mse_sgl", "loss.sg_warmup_epochs": 30}),
    ("sgl_hm_scale50", {"loss.type": "heatmap_mse_sgl", "loss.hm_loss_scale": 50}),
])
def test_memorisation_sanity_for_loss_settings_that_can_learn(synth, tmp_path, name, overrides):
    """Sanity check of the whole training path (NOT a scientific result): on 8 synthetic images these
    loss settings must fit far better than 'predict the crop centre'. The paper-literal SGL setting is
    deliberately NOT asserted here: it collapses in this setup (scripts/loss_balance_check.py, docs/LOSS_BALANCE.md)."""
    err, base = _memorise(synth, tmp_path, name, overrides)
    assert err < 0.25 * base, (name, err, base)
