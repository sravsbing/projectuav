"""Evidence-only audit of the REAL dataset (run where the data is; works on Windows paths).

  python scripts/audit_dataset.py --root "D:\\Datasets\\MMFW-UAV" --out results/dataset_audit.json

Fast by default: file NAMES are scanned exhaustively (._*, __MACOSX, .DS_Store, Thumbs.db are excluded before anything is opened), but
file CONTENTS are only SAMPLED - up to --per-group evenly spaced XML/JSON/image files from EACH directory (viewpoint/sensor folder),
capped by --max-xml / --max-json / --max-images, skipping any file larger than --max-file-mb. The report marks every block as
EXHAUSTIVE or SAMPLED. Use --exhaustive to open everything (slow). Malformed files are recorded in the report, never fatal.
Progress goes to the console. During the run the report is saved to <out>.partial after every stage; <out> itself is replaced
atomically only when the audit finishes, so Ctrl+C never destroys an earlier report (the partial file keeps what was done).
Creates no labels; a bounding box is never treated as a keypoint.
"""
import _path  # noqa: F401
import argparse
import json
import os
import sys
import time

from data.audit import audit


def _write(path: str, rep: dict) -> None:
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(rep, f, indent=1, ensure_ascii=False, default=str)
    os.replace(tmp, path)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True)
    ap.add_argument("--out", default="results/dataset_audit.json")
    ap.add_argument("--max-size-checks", type=int, default=300, help="max XML-declared-size vs real-image-size comparisons")
    ap.add_argument("--max-json", type=int, default=None, help="max JSON files opened (default 300)")
    ap.add_argument("--max-xml", type=int, default=None, help="max XML files opened (default 300)")
    ap.add_argument("--max-images", type=int, default=None, help="max images opened for size/greyscale evidence (default 300)")
    ap.add_argument("--per-group", type=int, default=None, help="max files sampled per directory (default 25)")
    ap.add_argument("--max-file-mb", type=float, default=None, help="skip XML/JSON files larger than this (default 50)")
    ap.add_argument("--exhaustive", action="store_true", help="open every XML/JSON/image; no limits (slow)")
    ap.add_argument("--quiet", action="store_true")
    a = ap.parse_args(argv)
    if not os.path.isdir(a.root):
        print(f"not a directory: {a.root}", file=sys.stderr)
        return 2
    partial = a.out + ".partial"
    rep: dict = {}
    t0 = time.time()

    def say(m):
        if not a.quiet:
            print(f"{time.time() - t0:7.1f}s  {m}", flush=True)

    def on_stage(name, r):
        r["elapsed_seconds"] = round(time.time() - t0, 1)
        _write(partial, r)

    try:
        audit(a.root, a.max_size_checks, a.max_json, max_xml=a.max_xml, max_images=a.max_images, per_group=a.per_group,
              max_file_mb=a.max_file_mb, exhaustive=a.exhaustive, report=rep, on_stage=on_stage, progress=say)
    except KeyboardInterrupt:
        if str(rep.get("status", "running")) == "running":
            rep["status"] = "interrupted (partial: only the stages present in this file finished)"
        _write(partial, rep)
        print(f"\nInterrupted. Everything finished so far is in {partial} (stages done: {[k for k in ('counts','xml','json','matching','modality_evidence','capabilities') if k in rep]}). "
              f"{a.out} was NOT modified.", file=sys.stderr)
        return 130
    _write(a.out, rep)
    if os.path.exists(partial):
        os.remove(partial)
    m, c, lim = rep.get("matching", {}), rep.get("capabilities", {}), rep["limits"]
    print("\nstatus:", rep["status"], "| stage errors:", rep["stage_errors"] or "none")
    print("clean file counts (exhaustive):", rep.get("counts"))
    for k, v in rep["scope"].items():
        print(f"  {k}: {v}")
    if "xml" in rep:
        print(f"xml: opened {rep['xml']['sampled']}, ok {rep['xml']['parsed_ok']}, failed {len(rep['xml']['failed'])}, names {rep['xml']['object_names']}")
    if "json" in rep:
        print(f"json: opened {rep['json']['sampled']}, ok {rep['json']['parsed_ok']}, failed {len(rep['json']['failed'])}, "
              f"keypoint fields {rep['json']['keypoint_fields']}, shapes {rep['json']['shape_types']}")
    if m:
        print("images with xml:", m["images_with_xml"], "| json:", m["images_with_json"], "| neither:", m["images_with_neither"],
              "| xml w/o image:", m["xml_without_image"], "| duplicate image stems:", m["duplicate_image_stems"])
    if c:
        print("keypoints supported as-is:", c["supports_structural_pose_training_as_is"], "| scope:", c["evidence_scope"])
    print("limits used:", lim)
    print("wrote", a.out)
    return 0


if __name__ == "__main__":
    sys.exit(main())
