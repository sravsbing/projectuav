"""Describe an unknown dataset folder WITHOUT assuming a layout: tree, extension counts, annotation-file
candidates and the dataset README. Run this first on the downloaded MMFW-UAV, then write the manifest rules.

  python scripts/inspect_dataset.py --root /path/to/MMFW-UAV --depth 3 --out results/dataset_inspection.json
"""
import _path  # noqa: F401
import argparse
import json
import os
from collections import Counter, defaultdict

from data.fs_filter import walk_clean


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True)
    ap.add_argument("--depth", type=int, default=3)
    ap.add_argument("--out", default=None)
    ap.add_argument("--readme-lines", type=int, default=80)
    a = ap.parse_args()
    if not os.path.isdir(a.root):
        raise SystemExit(f"not a directory: {a.root}")
    n_junk = sum(len(fn) for _, _, fn in os.walk(a.root)) - sum(len(fn) for _, _, fn in walk_clean(a.root))
    ext_total, per_dir, examples = Counter(), defaultdict(Counter), defaultdict(list)
    for dp, dn, fn in walk_clean(a.root):
        rel = os.path.relpath(dp, a.root)
        depth = 0 if rel == "." else rel.count(os.sep) + 1
        key = rel if depth <= a.depth else os.sep.join(rel.split(os.sep)[:a.depth])
        for f in sorted(fn):
            e = os.path.splitext(f)[1].lower() or "<none>"
            ext_total[e] += 1
            per_dir[key][e] += 1
            if len(examples[(key, e)]) < 3:
                examples[(key, e)].append(f)
    print(f"(ignored {n_junk} junk files/files inside junk folders: ._*, __MACOSX, .DS_Store ...)")
    print(f"== extensions under {a.root}")
    for e, n in ext_total.most_common():
        print(f"  {e:10s} {n}")
    print(f"== directories (depth<={a.depth}): file counts by extension, with example names")
    tree = {}
    for d in sorted(per_dir):
        print(f"  {d}")
        tree[d] = {}
        for e, n in per_dir[d].most_common():
            ex = examples[(d, e)]
            print(f"      {e:8s} {n:8d}   e.g. {', '.join(ex)}")
            tree[d][e] = {"count": n, "examples": ex}
    cands = [os.path.relpath(os.path.join(dp, f), a.root) for dp, _, fn in walk_clean(a.root) for f in fn
             if f.lower().endswith((".xml", ".json", ".csv")) and "readme" not in f.lower()][:20]
    print("== annotation-file candidates (first 20):", *cands, sep="\n  ")
    for dp, _, fn in walk_clean(a.root):
        for f in fn:
            if f.lower().startswith("readme"):
                p = os.path.join(dp, f)
                print(f"== {os.path.relpath(p, a.root)} (first {a.readme_lines} lines)")
                with open(p, encoding="utf-8", errors="replace") as fh:
                    for i, line in enumerate(fh):
                        if i >= a.readme_lines:
                            break
                        print("  " + line.rstrip())
    if a.out:
        os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
        json.dump({"extensions": dict(ext_total), "tree": tree, "annotation_candidates": cands},
                  open(a.out, "w"), indent=1)
        print("wrote", a.out)


if __name__ == "__main__":
    main()
