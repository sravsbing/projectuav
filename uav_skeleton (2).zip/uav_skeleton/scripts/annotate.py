"""Interactive keypoint annotator (OpenCV window; needs a desktop, NOT usable over a headless SSH).

  python scripts/annotate.py --root R --manifest R/manifest.csv --annotations R/annotations.jsonl \
      --annotator abhiram [--modality rgb] [--split-file R/splits.json --split train] [--only-unlabelled]

Click the 6 keypoints in order (head, body, left_wing, right_wing, tail_joint, tail_unit; wings are the
AIRCRAFT's own left/right - see docs/ANNOTATION_GUIDE.md). The view is a zoomed crop of the target box.
Keys: m=mark current keypoint missing  u=undo  e/h=easy/hard  ENTER=save+next unlabelled
      n/p=next/previous  q=save+quit. Labels are written atomically after every commit.
STATUS: the state machine (data/annotation_session.py) is unit-tested; this GUI shell has not been
exercised in a headless sandbox.
"""
import _path  # noqa: F401
import argparse
import os

import cv2
import numpy as np

from data.annotation_session import AnnotationSession
from data.annotations import read_annotations, write_annotations
from data.dataset import load_image_rgb_u8
from data.manifest import read_manifest
from data.splits import load_splits
from data.transforms import crop_pad_resize, square_crop_from_bbox
from visualization.keypoints import draw_skeleton

VIEW = 900


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True)
    ap.add_argument("--manifest", required=True)
    ap.add_argument("--annotations", required=True)
    ap.add_argument("--annotator", default="")
    ap.add_argument("--modality", choices=["rgb", "ir"], default=None)
    ap.add_argument("--split-file", default=None)
    ap.add_argument("--split", default="train")
    ap.add_argument("--only-unlabelled", action="store_true")
    ap.add_argument("--margin", type=float, default=0.25)
    a = ap.parse_args()

    rows = {r.sample_id: r for r in read_manifest(a.manifest)}
    anns = read_annotations(a.annotations)
    ids = sorted(rows)
    if a.split_file:
        keep = set(load_splits(a.split_file)[a.split])
        ids = [i for i in ids if i in keep]
    ids = [i for i in ids if a.modality in (None, rows[i].modality) and rows[i].bbox is not None]
    if a.only_unlabelled:
        ids = [i for i in ids if i not in anns]
    sess = AnnotationSession(ids, anns, a.annotator)
    state = {"tf": None, "img": None}

    def load():
        r = rows[sess.sample_id]
        img = load_image_rgb_u8(os.path.join(a.root, r.image_path), r.modality)
        state["tf"] = square_crop_from_bbox(r.bbox, VIEW, a.margin)
        state["img"] = crop_pad_resize(img, state["tf"])

    def on_mouse(ev, x, y, flags, _):
        if ev == cv2.EVENT_LBUTTONDOWN and sess.next_keypoint_name:
            ox, oy = state["tf"].to_original(np.array([x, y], float))
            sess.click(float(ox), float(oy))

    def render():
        tf = state["tf"]
        canvas = state["img"].copy()
        kp_view = tf.to_input(sess.kps)
        vis = sess.vis.copy()
        canvas = draw_skeleton(canvas, kp_view, vis, radius=6, labels=True)
        nxt = sess.next_keypoint_name or "ALL PLACED - ENTER to save"
        r = rows[sess.sample_id]
        hud = f"{sess.idx + 1}/{len(sess.sample_ids)} {r.sample_id} [{r.modality}] next: {nxt} | diff: {sess.difficulty}"
        cv2.putText(canvas, hud, (10, 24), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 0), 3)
        cv2.putText(canvas, hud, (10, 24), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 1)
        cv2.imshow("annotate", canvas[..., ::-1])

    cv2.namedWindow("annotate")
    cv2.setMouseCallback("annotate", on_mouse)
    load()
    while True:
        render()
        k = cv2.waitKey(30) & 0xFF
        if k == ord("m") and sess.next_keypoint_name:
            sess.mark_missing()
        elif k == ord("u"):
            sess.undo()
        elif k == ord("e"):
            sess.set_difficulty("easy")
        elif k == ord("h"):
            sess.set_difficulty("hard")
        elif k in (13, 10):
            try:
                sess.commit()
                write_annotations(a.annotations, anns)
                if not sess.next_unlabelled():
                    print("no more unlabelled samples")
                    break
                load()
            except RuntimeError as e:
                print("cannot save:", e)
        elif k == ord("n"):
            sess.goto(sess.idx + 1); load()
        elif k == ord("p"):
            sess.goto(sess.idx - 1); load()
        elif k == ord("q"):
            break
    cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
