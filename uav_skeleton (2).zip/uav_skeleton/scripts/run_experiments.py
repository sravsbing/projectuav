"""Stage 5 driver: RGB tuning -> select winners (validation) -> IR scratch / ImageNet-scratch / transfer -> tables.

  python scripts/run_experiments.py --root R --epochs 100 --out results/measured/stage5          # full run (GPU machine)
  python scripts/run_experiments.py --root R --dry-run                                           # list the plan, run nothing
  python scripts/run_experiments.py ... --phases rgb          # run only RGB, resume later with --phases ir report
  python scripts/run_experiments.py ... --extra-seeds 1 2     # re-run the selected configs with more seeds
Resumable: finished trials (JSON files in --out) are skipped. Trials that fail (e.g. ImageNet weights unreachable) are recorded as
failed and reported as such - nothing is substituted. Only train/val splits are read.
"""
import _path  # noqa: F401
import argparse
import json
import os

from experiments.plan import check_plan, ir_plan, rgb_plan
from experiments.report import markdown, summarize
from experiments.runner import run_plan, run_trial, select_winners, winners_for_ir


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True)
    ap.add_argument("--out", default="results/measured/stage5")
    ap.add_argument("--epochs", type=int, default=100)
    ap.add_argument("--batch-size", type=int, default=32)
    ap.add_argument("--input-size", type=int, default=256)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--extra-seeds", type=int, nargs="*", default=[])
    ap.add_argument("--lrs", type=float, nargs="+", default=[1e-3, 3e-4])
    ap.add_argument("--rgb-pretrained-backbone", action="store_true", help="ImageNet-init the RGB models (assumption A18)")
    ap.add_argument("--no-imagenet-scratch", action="store_true")
    ap.add_argument("--phases", nargs="+", default=["rgb", "ir", "report"], choices=["rgb", "ir", "report"])
    ap.add_argument("--set", nargs="*", default=[], help="extra shared config overrides, e.g. data.manifest=... train.num_workers=4")
    ap.add_argument("--device", default=None)
    ap.add_argument("--dry-run", action="store_true")
    a = ap.parse_args()

    base = [f"data.root={a.root}", f"train.epochs={a.epochs}", f"train.batch_size={a.batch_size}",
            f"model.input_size={a.input_size}", f"run.log_dir={os.path.join(a.out, 'logs')}",
            f"run.ckpt_dir={os.path.join(a.out, 'checkpoints')}", *a.set]
    rgb = rgb_plan(a.epochs, a.lrs, pretrained_backbone=a.rgb_pretrained_backbone)
    check_plan(rgb, a.epochs)
    d_rgb, d_ir = os.path.join(a.out, "rgb"), os.path.join(a.out, "ir")
    if a.dry_run:
        for t in rgb:
            print("rgb", t.run_name, t.overrides)
        print(f"{len(rgb)} RGB trials; the IR plan (~{(3 + 3 + 2) * len(a.lrs)} trials) depends on the RGB winners.")
        return

    rgb_recs = []
    if "rgb" in a.phases:
        rgb_recs = run_plan(rgb, base, d_rgb, a.seed, "rgb", a.device)
    else:
        rgb_recs = [json.load(open(os.path.join(d_rgb, f))) for f in sorted(os.listdir(d_rgb)) if f.endswith(f"seed{a.seed}.json")] \
            if os.path.isdir(d_rgb) else []
    rgb_sel = select_winners(rgb_recs)

    ir_recs = []
    if "ir" in a.phases or "report" in a.phases:
        winners = winners_for_ir(rgb_sel)
        ir = ir_plan(winners, a.lrs, include_imagenet_scratch=not a.no_imagenet_scratch)
        check_plan(ir, a.epochs)
        ir_recs = run_plan(ir, base, d_ir, a.seed, "ir", a.device) if "ir" in a.phases else \
            [json.load(open(os.path.join(d_ir, f))) for f in sorted(os.listdir(d_ir)) if f.endswith(f"seed{a.seed}.json")] \
            if os.path.isdir(d_ir) else []
    ir_sel = select_winners(ir_recs)

    extra = {}
    for s in a.extra_seeds:
        for sel, plan_trials, d, ph in ((rgb_sel, rgb, d_rgb, "rgb"), (ir_sel, ir if ir_recs else [], d_ir, "ir")):
            for method, m in sel.items():
                if m["winner"] is None:
                    continue
                t = next(t for t in plan_trials if t.method == method and t.name == m["winner"]["trial"])
                extra.setdefault(method, []).append(run_trial(t, base, d, s, ph, a.device))

    if "report" in a.phases:
        r, i = summarize(rgb_sel, extra), summarize(ir_sel, extra)
        os.makedirs(a.out, exist_ok=True)
        json.dump({"rgb": r, "ir": i, "split": "validation", "metric": "plain mean keypoint error, original px, GT-box crops",
                   "not_comparable_to_paper": True}, open(os.path.join(a.out, "summary.json"), "w"), indent=1)
        md = markdown(r, i)
        open(os.path.join(a.out, "summary.md"), "w").write(md)
        print(md)


if __name__ == "__main__":
    main()
