"""Validate manifest + annotations + region masks + splits. Exit code 1 if any error.

  python scripts/validate_dataset.py --root R --manifest R/manifest.csv --annotations R/annotations.jsonl \
      --splits R/splits.json --check-images 200 --out results/validation_report.json
"""
import _path  # noqa: F401
import argparse
import json
import os

from data.validate import validate_dataset


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True)
    ap.add_argument("--manifest", required=True)
    ap.add_argument("--annotations", default=None)
    ap.add_argument("--splits", default=None)
    ap.add_argument("--check-images", type=int, default=0, help="decode this many images (and region masks)")
    ap.add_argument("--out", default=None)
    a = ap.parse_args()
    rep = validate_dataset(a.root, a.manifest, a.annotations, a.splits, a.check_images)
    if a.out:
        os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
        json.dump(rep, open(a.out, "w"), indent=1, default=str)
    show = {k: v for k, v in rep.items() if k not in ("errors", "warnings")}
    print(json.dumps(show, indent=1, default=str))
    print(f"errors: {len(rep['errors'])}  warnings: {len(rep['warnings'])}")
    for m in rep["errors"][:20]:
        print("  ERROR", m)
    for m in rep["warnings"][:10]:
        print("  warn ", m)
    raise SystemExit(0 if rep["ok"] else 1)


if __name__ == "__main__":
    main()
