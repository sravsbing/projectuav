"""Fine-tune the YOLOv8 single-class UAV detector on the manifest boxes (same group splits as the keypoint net).

  python scripts/train_detector.py --root R --manifest R/manifest.csv --splits R/splits.json \
      --out-dir results/yolo_data --weights yolov8n.pt --epochs 50 --imgsz 640 --batch 16 --seed 42
Use --weights yolov8n.yaml to train from random init (no download). Pretrained .pt needs GitHub access.
Output: <project>/<name>/weights/best.pt  -> pass to scripts/predict.py --yolo-weights
"""
import _path  # noqa: F401
import argparse

from data.manifest import read_manifest
from data.splits import load_splits
from training.yolo_export import export_yolo_dataset


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True)
    ap.add_argument("--manifest", required=True)
    ap.add_argument("--splits", required=True)
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--weights", default="yolov8n.pt")
    ap.add_argument("--modalities", nargs="+", default=["rgb", "ir"])
    ap.add_argument("--epochs", type=int, default=50)
    ap.add_argument("--imgsz", type=int, default=640)
    ap.add_argument("--batch", type=int, default=16)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--device", default=None)
    ap.add_argument("--project", default="checkpoints/yolo")
    ap.add_argument("--name", default="uav_detector")
    a = ap.parse_args()
    info = export_yolo_dataset(a.root, read_manifest(a.manifest), load_splits(a.splits), a.out_dir, tuple(a.modalities))
    print("exported:", info)
    from ultralytics import YOLO
    kw = dict(data=info["yaml"], epochs=a.epochs, imgsz=a.imgsz, batch=a.batch, seed=a.seed, deterministic=True,
              project=a.project, name=a.name, plots=False, exist_ok=True)
    if a.device:
        kw["device"] = a.device
    YOLO(a.weights).train(**kw)


if __name__ == "__main__":
    main()
