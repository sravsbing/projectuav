"""Run the full pipeline (detector -> crop -> SG-VDNet -> skeleton) on images and save overlays + JSON.

  python scripts/predict.py --checkpoint checkpoints/sg_rgb/best.pt --yolo-weights checkpoints/yolo/uav_detector/weights/best.pt \
        --images a.png b.png --out results/predictions
  # GT-box mode (isolates the keypoint net; label it as such in any report):
  python scripts/predict.py --checkpoint ... --manifest R/manifest.csv --root R --images rgb/x.png --use-manifest-box --out ...
Images with no detection are reported as MISSED (never given a fallback box).
"""
import _path  # noqa: F401
import argparse
import json
import os

import cv2

from data.dataset import load_image_rgb_u8
from data.manifest import read_manifest
from models.detector import YoloV8Detector
from models.pipeline import VulnerabilityPipeline
from models.vdnet import build_model
from training.utils import load_checkpoint
from visualization.keypoints import draw_skeleton


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--checkpoint", required=True)
    ap.add_argument("--images", nargs="+", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--modality", choices=["rgb", "ir"], default="rgb")
    ap.add_argument("--yolo-weights", default=None)
    ap.add_argument("--use-manifest-box", action="store_true")
    ap.add_argument("--manifest", default=None)
    ap.add_argument("--root", default=None)
    ap.add_argument("--device", default=None)
    a = ap.parse_args()

    ck = load_checkpoint(a.checkpoint)
    cfg = ck["cfg"]
    model = build_model(ck["arch"], False, cfg["model"]["deconv_channels"])
    model.load_state_dict(ck["model"])
    det = YoloV8Detector(a.yolo_weights, device=a.device) if a.yolo_weights else None
    if det is None and not a.use_manifest_box:
        raise SystemExit("give --yolo-weights, or --use-manifest-box (GT-box mode)")
    pipe = VulnerabilityPipeline(model, det, cfg["model"]["input_size"], cfg["data"]["margin"], a.device)
    boxes = {}
    if a.use_manifest_box:
        boxes = {r.image_path: r.bbox for r in read_manifest(a.manifest)}
    os.makedirs(a.out, exist_ok=True)
    results = {}
    for p in a.images:
        full = os.path.join(a.root, p) if a.root else p
        img = load_image_rgb_u8(full, a.modality)
        sk = pipe.predict(img, boxes.get(p) if a.use_manifest_box else None)
        if sk is None:
            results[p] = {"detected": False}
            print("MISSED (no detection):", p)
            continue
        results[p] = {"detected": True, "box_xyxy": sk.box, "keypoints_xy": sk.keypoints.round(2).tolist(),
                      "confidence": sk.confidence.round(4).tolist(), "gt_box_mode": a.use_manifest_box}
        out = draw_skeleton(img, sk.keypoints, radius=5, labels=True)
        cv2.imwrite(os.path.join(a.out, os.path.basename(p) + ".pred.png"), out[..., ::-1])
    json.dump(results, open(os.path.join(a.out, "predictions.json"), "w"), indent=1)
    print("wrote", os.path.join(a.out, "predictions.json"))


if __name__ == "__main__":
    main()
