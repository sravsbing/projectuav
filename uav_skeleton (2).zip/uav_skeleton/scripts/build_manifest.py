"""Build manifest.csv from regex layout rules (see data/manifest_builder.py). Unmatched files are listed.

  python scripts/build_manifest.py --root R --out R/manifest.csv \
      --rule rgb "wide/**/*.jpg" "(?P<group>sortie\\d+)/.*?(?P<pair>\\d{6})\\.jpg" \
      --rule ir  "thermal/**/*.jpg" "(?P<group>sortie\\d+)/.*?(?P<pair>\\d{6})\\.jpg" \
      --bbox-template "labels_voc/{stem}.xml" --bbox-format voc --read-sizes
(the rule strings above are PLACEHOLDERS - derive real ones from scripts/inspect_dataset.py output.)
"""
import _path  # noqa: F401
import argparse

from data.manifest import validate_manifest, write_manifest
from data.manifest_builder import build_manifest


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--rule", nargs=3, action="append", metavar=("MODALITY", "GLOB", "REGEX"), required=True)
    ap.add_argument("--bbox-template", default=None)
    ap.add_argument("--bbox-format", choices=["voc", "center"], default="voc")
    ap.add_argument("--read-sizes", action="store_true")
    a = ap.parse_args()
    rows, problems = build_manifest(a.root, a.rule, a.bbox_template, a.bbox_format, a.read_sizes)
    write_manifest(a.out, rows)
    errs, warns = validate_manifest(rows, a.root)
    print(f"{len(rows)} rows -> {a.out}")
    for k, v in problems.items():
        if v:
            print(f"  {k}: {len(v)} (first 5: {v[:5]})")
    for m in warns + errs[:20]:
        print("  !", m)
    raise SystemExit(1 if errs else 0)


if __name__ == "__main__":
    main()
