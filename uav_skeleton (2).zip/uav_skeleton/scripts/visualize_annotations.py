"""Render a grid of annotated samples (skeleton + optional region overlay) for visual QA of labels.

  python scripts/visualize_annotations.py --root R --manifest R/manifest.csv --annotations R/annotations.jsonl \
      --n 12 --modality rgb --out results/figures/annotation_check.png
"""
import _path  # noqa: F401
import argparse
import os
import random

import cv2

from data.annotations import read_annotations
from data.dataset import load_image_rgb_u8
from data.manifest import read_manifest
from data.regions import load_region_labels
from visualization.keypoints import draw_skeleton, make_grid, overlay_regions


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True)
    ap.add_argument("--manifest", required=True)
    ap.add_argument("--annotations", required=True)
    ap.add_argument("--n", type=int, default=12)
    ap.add_argument("--modality", choices=["rgb", "ir"], default=None)
    ap.add_argument("--regions", action="store_true")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    rows = [r for r in read_manifest(a.manifest) if a.modality in (None, r.modality)]
    anns = read_annotations(a.annotations)
    rows = [r for r in rows if r.sample_id in anns]
    random.Random(a.seed).shuffle(rows)
    tiles = []
    for r in rows[:a.n]:
        img = load_image_rgb_u8(os.path.join(a.root, r.image_path), r.modality)
        ann = anns[r.sample_id]
        if a.regions and ann.region_mask:
            img = overlay_regions(img, load_region_labels(os.path.join(a.root, ann.region_mask)))
        img = draw_skeleton(img, ann.keypoints, ann.visibility)
        if r.bbox:
            x1, y1, x2, y2 = (int(round(v)) for v in r.bbox)
            cv2.rectangle(img, (x1, y1), (x2, y2), (255, 255, 0), 1)
        tiles.append(cv2.resize(img, (320, 240)))
    if not tiles:
        raise SystemExit("no annotated samples to draw")
    os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
    cv2.imwrite(a.out, make_grid(tiles, 4)[..., ::-1])
    print(f"wrote {a.out} ({len(tiles)} tiles)")


if __name__ == "__main__":
    main()
