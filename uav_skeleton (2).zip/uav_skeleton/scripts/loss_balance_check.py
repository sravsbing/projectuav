"""DIAGNOSTIC (not an experiment): does the loss configuration let a tiny network memorise 8 synthetic images?

Why: with the paper's lambda=0.1 and a pixel-averaged heatmap MSE, the SGL term can dominate and collapse
the keypoints (see docs/LOSS_BALANCE.md). Run this BEFORE spending GPU hours on real data. It uses
SYNTHETIC stick-figure images, random-init ResNet-18 and train==val, so its numbers say nothing about the
paper or MMFW-UAV - only whether a loss setting can learn at all.

  python scripts/loss_balance_check.py --out results/diagnostics/loss_balance_synthetic.json
"""
import _path  # noqa: F401
import argparse
import json
import os
import tempfile

import torch
from torch.utils.data import default_collate

from data.annotations import read_annotations
from data.dataset import SkeletonDataset
from data.manifest import read_manifest
from data.splits import save_splits
from data.synthetic import make_synthetic_dataset
from evaluation.keypoint_error import keypoint_errors, summarize_errors
from models.postprocess import decode_batch_original, inputs_to_original_torch
from models.vdnet import build_model
from training.config import load_config
from training.trainer import run_training

VARIANTS = {
    "A heatmap MSE only": ["loss.type=heatmap_mse"],
    "B + SGL (paper-literal: lambda=0.1, pixel-mean MSE)": ["loss.type=heatmap_mse_sgl"],
    "C + SGL, heatmap term x50": ["loss.type=heatmap_mse_sgl", "loss.hm_loss_scale=50"],
    "D + SGL as cosine": ["loss.type=heatmap_mse_sgl", "loss.sgl_normalize_vectors=true"],
    "E + SGL, 30-epoch warm-up": ["loss.type=heatmap_mse_sgl", "loss.sg_warmup_epochs=30"],
}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="results/diagnostics/loss_balance_synthetic.json")
    ap.add_argument("--epochs", type=int, default=100)
    ap.add_argument("--only", nargs="*", default=None, help="variant letters, e.g. A B")
    a = ap.parse_args()
    S = 96
    res = {}
    with tempfile.TemporaryDirectory() as tmp:
        make_synthetic_dataset(tmp, n_groups=9, frames_per_group=2, seed=3, with_regions=False)
        rows = read_manifest(os.path.join(tmp, "manifest.csv"))
        anns = read_annotations(os.path.join(tmp, "annotations.jsonl"))
        ids = [r.sample_id for r in rows if r.modality == "rgb"][:8]
        spl = os.path.join(tmp, "s.json")
        save_splits(spl, {"train": ids, "val": ids, "test": []}, {})
        ds = SkeletonDataset(tmp, rows, anns, sample_ids=ids, modality="rgb", input_size=S, heatmap_size=S // 4, sigma=1.5)
        b = default_collate([ds[i] for i in range(len(ds))])
        gt = inputs_to_original_torch(b["keypoints_in"].double(), b["crop"], S)
        centre = inputs_to_original_torch(torch.full_like(b["keypoints_in"], (S - 1) / 2).double(), b["crop"], S)
        base = float((centre - gt).norm(dim=-1).mean())
        print(f"trivial 'predict crop centre' error: {base:.2f}px")
        for name, extra in VARIANTS.items():
            if a.only and name[0] not in a.only:
                continue
            tag = name[0]
            cfg = load_config(None, [f"data.root={tmp}", f"data.splits={spl}", "data.modality=rgb", f"model.input_size={S}",
                                     f"train.epochs={a.epochs}", "train.batch_size=8", "train.lr=1e-3", "train.box_jitter=0.0",
                                     "heatmap.sigma=1.5", f"run.name={tag}", f"run.log_dir={tmp}/l{tag}",
                                     f"run.ckpt_dir={tmp}/c{tag}", *extra])
            for kv in extra:                                   # the overrides must really be in the config used
                k, v = kv.split("=")
                node = cfg
                for part in k.split("."):
                    node = node[part]
                assert str(node).lower() == v.lower() or float(node) == float(v), (kv, node)
            s = run_training(cfg, "cpu", verbose=False)
            m = build_model("sg_vdnet")
            m.load_state_dict(torch.load(s["last_ckpt"], weights_only=False)["model"])
            m.eval()
            with torch.no_grad():
                po, _, _ = decode_batch_original(m(b["image"]).double(), b["crop"], S)
            err = summarize_errors(keypoint_errors(po, gt, b["visibility"]))["mean"]
            h = s["history"][-1]
            res[name] = {"final_kp_error_px": round(err, 2), "final_train_loss": round(h["train_loss"], 6),
                         "learned": bool(err < 0.5 * base), "overrides": extra}
            print(f"{name:55s} err {err:6.2f}px  loss {h['train_loss']:.5f}  {'LEARNS' if err < 0.5 * base else 'DOES NOT LEARN'}")
    os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
    json.dump({"note": "SYNTHETIC diagnostic: 8 stick-figure images, random-init ResNet-18, train==val, "
                       f"{a.epochs} full-batch steps. Says nothing about the paper or MMFW-UAV.",
               "centre_baseline_px": round(base, 2), "variants": res}, open(a.out, "w"), indent=1)
    print("wrote", a.out)


if __name__ == "__main__":
    main()
