"""Assemble measured-vs-published tables from scripts/evaluate.py output folders.

  python scripts/make_comparison.py --out results/measured/comparison.md \
      --eval orb:rgb:results/measured/eval/orb_rgb --eval orb:ir:... --eval pg_vdnet:rgb:... --eval sg_vdnet:ir:...
Each --eval is method:modality:dir (method in orb|pg_vdnet|sg_vdnet). Missing combinations show as n/a. Only measured numbers from
those folders are used; the published column is read from results/reference/published_results.json.
"""
import _path  # noqa: F401
import argparse
import json
import os

from evaluation.compare import CAVEAT, accuracy_table, speed_table


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--eval", action="append", default=[], required=True)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    meas, speed, notes = {}, {}, []
    for item in a.eval:
        m, mod, d = item.split(":", 2)
        s = json.load(open(os.path.join(d, "summary.json")))
        meas.setdefault(m, {})[mod] = s
        notes.append(f"{m}/{mod}: split={s['split']}, boxes={s['box_source']}, difficulty source={s['difficulty_sources']}, "
                     f"region masks {'used' if s['region_mode_available'] else 'ABSENT (region mode not computable)'}")
        tp = os.path.join(d, "timing.json")
        if os.path.exists(tp) and mod == "rgb":
            speed[m] = json.load(open(tp))
    mode = "region" if all(v.get("region") for per in meas.values() for v in per.values()) else "radius"
    md = ["# Measured vs published", "", CAVEAT, accuracy_table(meas, mode, "rmse_misses_px"),
          accuracy_table(meas, mode, "rmse_all_predicted_px"), speed_table(speed), "### Provenance", ""] + [f"- {n}" for n in notes]
    if mode == "radius":
        md.insert(3, "> **Region masks were not available for every evaluated set: the tables use the 15 px RADIUS test, not "
                     "vulnerability regions.**\n")
    os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
    open(a.out, "w").write("\n".join(md) + "\n")
    print("\n".join(md))


if __name__ == "__main__":
    main()
