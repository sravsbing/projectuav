"""Train any experiment from a config (PG-VDNet / SG-VDNet / point-MSE / RGB pretrain / IR scratch / transfer).

  python scripts/train.py --config configs/default.yaml --set data.root=/path/MMFW-UAV run.name=sg_rgb
  # RGB->IR transfer (Stage 5 wraps this): 
  python scripts/train.py --set data.root=... data.modality=ir run.name=sg_ir_transfer \
        transfer.init_from=checkpoints/sg_rgb/best.pt transfer.freeze_backbone=true
"""
import _path  # noqa: F401
import argparse
import json

from training.config import load_config
from training.trainer import run_training


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default=None)
    ap.add_argument("--set", nargs="*", default=[], metavar="KEY=VAL")
    ap.add_argument("--device", default=None)
    a = ap.parse_args()
    cfg = load_config(a.config, a.set)
    s = run_training(cfg, device=a.device)
    s.pop("history")
    print(json.dumps(s, indent=1))


if __name__ == "__main__":
    main()
