"""Group-level train/val/test split with leakage verification.

  python scripts/make_splits.py --manifest R/manifest.csv --out R/splits.json --seed 42 --fractions 0.7 0.1 0.2
"""
import _path  # noqa: F401
import argparse
import json

from data.manifest import read_manifest
from data.splits import group_split, save_splits, split_report, verify_no_leakage


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--manifest", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--fractions", type=float, nargs=3, default=[0.7, 0.1, 0.2])
    a = ap.parse_args()
    rows = read_manifest(a.manifest)
    sp = group_split(rows, tuple(a.fractions), a.seed)
    verify_no_leakage(sp, rows)
    rep = split_report(sp, rows)
    save_splits(a.out, sp, {"seed": a.seed, "fractions": a.fractions, "unit": "group_id", "manifest": a.manifest})
    print(json.dumps(rep, indent=1))
    print("wrote", a.out)


if __name__ == "__main__":
    main()
