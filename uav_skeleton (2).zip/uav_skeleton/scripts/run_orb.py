"""Build the ORB reference DB from the TRAIN split and predict keypoints on another split.

  python scripts/run_orb.py --root R --modality rgb --eval-split val --out results/orb_rgb_val
  python scripts/run_orb.py ... --yolo-weights W      # detector boxes (default: ground-truth manifest boxes, label it so)
  python scripts/run_orb.py ... --eval-split test --allow-test   # only for the final run; never tune on it
Writes predictions.json (every image; unpredicted keypoints are null, undetected images detected=false),
config.json and a plain keypoint-error summary. That summary is NOT the paper's IoP/RMSE (Stage 6).
"""
import _path  # noqa: F401
import argparse
import json
import os

import numpy as np

from baselines.orb import ORBBaseline, ORBConfig, ReferenceDB, build_reference_db
from data.annotations import read_annotations
from data.dataset import load_image_rgb_u8
from data.manifest import read_manifest
from data.splits import load_splits, verify_no_leakage


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True)
    ap.add_argument("--manifest"); ap.add_argument("--annotations"); ap.add_argument("--splits")
    ap.add_argument("--modality", choices=["rgb", "ir"], required=True)
    ap.add_argument("--eval-split", choices=["val", "test"], default="val")
    ap.add_argument("--allow-test", action="store_true")
    ap.add_argument("--yolo-weights", default=None)
    ap.add_argument("--db", default=None, help="reuse a saved DB instead of rebuilding")
    ap.add_argument("--out", required=True)
    ap.add_argument("--set", nargs="*", default=[], help="ORBConfig overrides, e.g. min_votes=4 ratio=0.8")
    a = ap.parse_args()
    if a.eval_split == "test" and not a.allow_test:
        raise SystemExit("the test split is reserved: pass --allow-test only for the final evaluation")
    man = a.manifest or os.path.join(a.root, "manifest.csv")
    rows = read_manifest(man)
    ann = read_annotations(a.annotations or os.path.join(a.root, "annotations.jsonl"))
    sp = load_splits(a.splits or os.path.join(a.root, "splits.json"))
    verify_no_leakage(sp, rows)
    cfg = ORBConfig()
    for kv in a.set:
        k, v = kv.split("=", 1)
        if not hasattr(cfg, k):
            raise SystemExit(f"unknown ORBConfig field {k!r}")
        setattr(cfg, k, type(getattr(cfg, k))(float(v) if isinstance(getattr(cfg, k), float) else int(v)))
    os.makedirs(a.out, exist_ok=True)
    db = ReferenceDB.load(a.db) if a.db else build_reference_db(a.root, rows, ann, sp["train"], a.modality, cfg,
                                                                 allowed_ids=sp["train"])
    if not a.db:
        db.save(os.path.join(a.out, "reference_db.pkl"))
    det = None
    if a.yolo_weights:
        from models.detector import YoloV8Detector
        det = YoloV8Detector(a.yolo_weights)
    method = ORBBaseline(db, det)
    by = {r.sample_id: r for r in rows}
    preds, errs, unpred, undetected, n_kp = {}, [], 0, 0, 0
    for sid in sp[a.eval_split]:
        r = by[sid]
        if r.modality != a.modality or sid not in ann:
            continue
        img = load_image_rgb_u8(os.path.join(a.root, r.image_path), r.modality)
        sk = method.predict(img, None if det else r.bbox)
        vis = ann[sid].visibility
        if sk is None:
            preds[sid] = {"detected": False}
            undetected += 1
            n_kp += int((vis > 0).sum())
            continue
        kp = sk.keypoints
        preds[sid] = {"detected": True, "box_xyxy": sk.box,
                      "keypoints_xy": [None if np.isnan(p[0]) else [round(float(p[0]), 2), round(float(p[1]), 2)] for p in kp],
                      "votes": sk.confidence.tolist()}
        for k in range(len(kp)):
            if vis[k] > 0:
                n_kp += 1
                if np.isnan(kp[k, 0]):
                    unpred += 1
                else:
                    errs.append(float(np.linalg.norm(kp[k] - ann[sid].keypoints[k])))
    summary = {"split": a.eval_split, "modality": a.modality, "box_source": "detector" if det else "ground-truth manifest box",
               "train_images_in_db": len(db.source_ids), "db_features": len(db), "labelled_keypoints": n_kp,
               "unpredicted_keypoints": unpred, "images_without_detection": undetected,
               "mean_error_px_of_predicted": float(np.mean(errs)) if errs else None,
               "median_error_px_of_predicted": float(np.median(errs)) if errs else None,
               "note": "plain Euclidean keypoint error, NOT the paper's IoP/RMSE; unpredicted keypoints excluded here "
                       "and counted as misses by the Stage 6 evaluation"}
    json.dump(preds, open(os.path.join(a.out, "predictions.json"), "w"))
    json.dump({"orb_config": cfg.__dict__ if not a.db else db.cfg.__dict__, "summary": summary},
              open(os.path.join(a.out, "config_and_summary.json"), "w"), indent=2)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
