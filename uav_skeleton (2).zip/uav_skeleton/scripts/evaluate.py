"""Evaluate one method on a split with the paper's metrics (IoP, region-boundary RMSE) + breakdowns + failure cases + FPS.

  # network (checkpoint from Stage 3/5), ground-truth boxes (isolates the keypoint model - label it so):
  python scripts/evaluate.py --root R --method net --checkpoint checkpoints/.../best.pt --modality ir --split val --use-gt-box --out results/measured/eval/sg_ir
  # full pipeline with the YOLO detector:           ... --yolo-weights W      (drop --use-gt-box)
  # ORB baseline (reference DB from run_orb.py):    --method orb --orb-db results/orb_ir/reference_db.pkl
  # final numbers only:                             --split test --allow-test
Outputs: summary.json, per_keypoint.csv (every labelled keypoint), failures/*.png, timing.json. Measured values only.
"""
import _path  # noqa: F401
import argparse
import json
import os

import cv2

from data.annotations import read_annotations
from data.dataset import load_image_rgb_u8
from data.manifest import read_manifest
from data.regions import load_region_labels
from data.splits import load_splits, verify_no_leakage
from evaluation.difficulty import fit_thresholds
from evaluation.evaluate import evaluate_split, summarize, worst_cases, write_csv
from evaluation.timing import benchmark
from visualization.keypoints import draw_skeleton, overlay_regions


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True)
    ap.add_argument("--manifest"); ap.add_argument("--annotations"); ap.add_argument("--splits")
    ap.add_argument("--method", choices=["net", "orb"], required=True)
    ap.add_argument("--checkpoint"); ap.add_argument("--orb-db"); ap.add_argument("--yolo-weights")
    ap.add_argument("--modality", choices=["rgb", "ir"], required=True)
    ap.add_argument("--split", choices=["val", "test"], default="val")
    ap.add_argument("--allow-test", action="store_true")
    ap.add_argument("--use-gt-box", action="store_true")
    ap.add_argument("--max-images", type=int, default=None)
    ap.add_argument("--n-failures", type=int, default=12)
    ap.add_argument("--timing-repeats", type=int, default=100)
    ap.add_argument("--device", default=None)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    if a.split == "test" and not a.allow_test:
        raise SystemExit("the test split is reserved: pass --allow-test only for the final evaluation")
    rows = read_manifest(a.manifest or os.path.join(a.root, "manifest.csv"))
    ann = read_annotations(a.annotations or os.path.join(a.root, "annotations.jsonl"))
    sp = load_splits(a.splits or os.path.join(a.root, "splits.json"))
    verify_no_leakage(sp, rows)
    det = None
    if a.yolo_weights:
        from models.detector import YoloV8Detector
        det = YoloV8Detector(a.yolo_weights, device=a.device)
    if not a.use_gt_box and det is None:
        raise SystemExit("give --yolo-weights, or --use-gt-box (and say so when reporting)")
    if a.method == "net":
        from models.pipeline import VulnerabilityPipeline
        from models.vdnet import build_model
        from training.utils import load_checkpoint
        ck = load_checkpoint(a.checkpoint)
        cfg = ck["cfg"]
        model = build_model(ck["arch"], False, cfg["model"]["deconv_channels"])
        model.load_state_dict(ck["model"])
        method = VulnerabilityPipeline(model, det, cfg["model"]["input_size"], cfg["data"]["margin"], a.device)
        meta = {"arch": ck["arch"], "checkpoint": a.checkpoint, "trained_modality": cfg["data"]["modality"]}
    else:
        from baselines.orb import ORBBaseline, ReferenceDB
        method = ORBBaseline(ReferenceDB.load(a.orb_db), det)
        meta = {"orb_db": a.orb_db}
    th = fit_thresholds(a.root, rows, sp["train"], a.modality)        # train split only
    res = evaluate_split(method, a.root, rows, ann, sp[a.split], a.modality, th, a.use_gt_box, a.max_images)
    summ = summarize(res["records"])
    summ.update(split=a.split, modality=a.modality, box_source="ground-truth manifest box" if a.use_gt_box else "YOLOv8 detector",
                method=meta, difficulty_thresholds=th, radius_note="15 px at 640 px width, scaled by image width",
                region_mode_available=summ["region"] is not None)
    os.makedirs(a.out, exist_ok=True)
    json.dump(summ, open(os.path.join(a.out, "summary.json"), "w"), indent=1)
    write_csv(os.path.join(a.out, "per_keypoint.csv"), res["records"])
    # failure cases: GT (green-ish) vs prediction overlays
    by = {r.sample_id: r for r in rows}
    os.makedirs(os.path.join(a.out, "failures"), exist_ok=True)
    for sid in worst_cases(res["records"], a.n_failures, "region" if summ["region"] else "radius"):
        r = by[sid]
        img = load_image_rgb_u8(os.path.join(a.root, r.image_path), r.modality)
        if ann[sid].region_mask:
            img = overlay_regions(img, load_region_labels(os.path.join(a.root, ann[sid].region_mask)), 0.3)
        out = draw_skeleton(img, ann[sid].keypoints, ann[sid].visibility, radius=4)
        sk = method.predict(load_image_rgb_u8(os.path.join(a.root, r.image_path), r.modality), r.bbox if a.use_gt_box else None)
        if sk is not None:
            import numpy as np
            ok = ~np.isnan(sk.keypoints[:, 0])
            out = draw_skeleton(out, np.nan_to_num(sk.keypoints), ok.astype(float), radius=7, edge_color=(255, 0, 0))
        cv2.imwrite(os.path.join(a.out, "failures", f"{sid.replace('/', '_')}.png"), cv2.cvtColor(out, cv2.COLOR_RGB2BGR))
    ids = [s for s in sp[a.split] if by[s].modality == a.modality and s in ann][:20]
    if ids and a.timing_repeats > 0:
        imgs = [load_image_rgb_u8(os.path.join(a.root, by[s].image_path), a.modality) for s in ids]
        scope = ("GT box + crop + network + decode" if a.use_gt_box else "YOLOv8 + crop + network + decode") if a.method == "net" \
            else ("GT box + crop + ORB + matching + voting" if a.use_gt_box else "YOLOv8 + crop + ORB + matching + voting")
        t = benchmark(method, imgs, [by[s].bbox if a.use_gt_box else None for s in ids], scope, repeats=a.timing_repeats)
        json.dump(t, open(os.path.join(a.out, "timing.json"), "w"), indent=1)
    print(json.dumps({k: summ[k] for k in ("n_images", "n_images_undetected", "difficulty_sources")}, indent=1))
    for mode in ("region", "radius"):
        if summ[mode]:
            print(mode, json.dumps(summ[mode]["overall"]))
        else:
            print(mode, "not computable (no region masks)")


if __name__ == "__main__":
    main()
