"""Keypoint / skeleton / region drawing (OpenCV, images are RGB uint8 HxWx3)."""
from __future__ import annotations

from typing import Optional

import numpy as np

from data.keypoints import KEYPOINT_NAMES, NUM_KEYPOINTS, SKELETON_EDGES

# RGB, one fixed colour per keypoint (same everywhere so plots are comparable).
KP_COLORS = {
    "head": (0, 200, 0), "body": (255, 215, 0), "left_wing": (30, 90, 255),
    "right_wing": (0, 200, 255), "tail_joint": (255, 140, 0), "tail_unit": (230, 30, 30),
}


def draw_skeleton(image: np.ndarray, keypoints: np.ndarray, visibility: Optional[np.ndarray] = None,
                  radius: int = 5, thickness: int = 2, edge_color=(255, 255, 255),
                  labels: bool = False, highlight: Optional[int] = None) -> np.ndarray:
    """Return a copy of `image` with the skeleton drawn. Missing keypoints (vis==0) and edges
    touching them are skipped. `highlight` enlarges one keypoint (paper Fig. 8/9 style)."""
    import cv2
    out = np.ascontiguousarray(image).copy()
    vis = np.ones(NUM_KEYPOINTS, bool) if visibility is None else np.asarray(visibility).astype(bool)
    pts = [tuple(int(round(v)) for v in p) for p in np.asarray(keypoints)]
    for a, b in SKELETON_EDGES:
        if vis[a] and vis[b]:
            cv2.line(out, pts[a], pts[b], edge_color, thickness, cv2.LINE_AA)
    for k, name in enumerate(KEYPOINT_NAMES):
        if not vis[k]:
            continue
        r = radius * 2 if highlight == k else radius
        cv2.circle(out, pts[k], r, KP_COLORS[name], -1, cv2.LINE_AA)
        cv2.circle(out, pts[k], r, (0, 0, 0), 1, cv2.LINE_AA)
        if labels:
            cv2.putText(out, name, (pts[k][0] + 6, pts[k][1] - 6), cv2.FONT_HERSHEY_SIMPLEX, 0.4,
                        (0, 0, 0), 2, cv2.LINE_AA)
            cv2.putText(out, name, (pts[k][0] + 6, pts[k][1] - 6), cv2.FONT_HERSHEY_SIMPLEX, 0.4,
                        KP_COLORS[name], 1, cv2.LINE_AA)
    return out


def overlay_regions(image: np.ndarray, labels: np.ndarray, alpha: float = 0.45) -> np.ndarray:
    """Blend the semantic region label mask (0=bg, k+1=keypoint k) over the image."""
    out = image.astype(np.float32).copy()
    for k, name in enumerate(KEYPOINT_NAMES):
        m = labels == (k + 1)
        if m.any():
            out[m] = (1 - alpha) * out[m] + alpha * np.array(KP_COLORS[name], np.float32)
    return out.round().astype(np.uint8)


def draw_heatmap_overlay(image: np.ndarray, heatmaps: np.ndarray, alpha: float = 0.5) -> np.ndarray:
    """Max-over-channels heatmap blended on `image` (resized to image size)."""
    import cv2
    h = heatmaps.max(axis=0)
    h = cv2.resize(h, (image.shape[1], image.shape[0]), interpolation=cv2.INTER_LINEAR)
    cm = cv2.applyColorMap((np.clip(h, 0, 1) * 255).astype(np.uint8), cv2.COLORMAP_JET)[..., ::-1]
    return ((1 - alpha) * image + alpha * cm).round().astype(np.uint8)


def make_grid(images, ncols: int = 4, pad: int = 4, bg: int = 255) -> np.ndarray:
    """Tile same-size images into one array."""
    n = len(images)
    h, w = images[0].shape[:2]
    nrows = (n + ncols - 1) // ncols
    grid = np.full((nrows * h + (nrows + 1) * pad, ncols * w + (ncols + 1) * pad, 3), bg, np.uint8)
    for i, im in enumerate(images):
        r, c = divmod(i, ncols)
        grid[pad + r * (h + pad): pad + r * (h + pad) + h, pad + c * (w + pad): pad + c * (w + pad) + w] = im
    return grid
