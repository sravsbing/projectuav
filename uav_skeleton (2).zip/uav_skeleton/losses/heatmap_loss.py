"""Visibility-aware heatmap MSE (paper Eq. 2) and point-MSE ablation loss.

Paper Eq. 2:  L_hm = (1/N) * sum M * (H_pred - H_gt)^2
with M a visibility mask that blocks unlabelled keypoints from back-prop.

Implementation choices (documented, assumption A5):
  * N = (number of visible keypoint channels) * H * W, i.e. a mean over all
    pixels of visible channels. Invisible channels contribute exactly 0 and are
    excluded from the denominator, so images with many missing keypoints are
    not down-weighted. If a batch has no visible keypoint the loss is 0 (with
    a grad path) rather than NaN.
  * `loss_scale` multiplies the result. Default 1.0 = paper-faithful. A plain
    pixel-mean MSE of sigma~2 Gaussians is O(1e-3..1e-2), which can be
    dominated by 0.1*L_sg; scaling is therefore exposed as a config option and
    must be reported if changed.
"""
from __future__ import annotations

import torch

from data.heatmaps import soft_argmax, heatmap_coords_to_normalized


def masked_heatmap_mse(pred: torch.Tensor, gt: torch.Tensor, vis: torch.Tensor,
                       loss_scale: float = 1.0) -> torch.Tensor:
    """pred, gt: (B,K,H,W); vis: (B,K) bool/0-1."""
    if pred.shape != gt.shape:
        raise ValueError(f"shape mismatch {pred.shape} vs {gt.shape}")
    B, K, H, W = pred.shape
    m = vis.to(pred.dtype).view(B, K, 1, 1)
    se = m * (pred - gt) ** 2
    denom = (m.sum() * H * W).clamp_min(1.0)
    return loss_scale * se.sum() / denom


def masked_point_mse(pred_heat_or_coords: torch.Tensor, gt_norm: torch.Tensor, vis: torch.Tensor,
                     stride: float | None = None, input_size: int | None = None,
                     beta: float = 100.0) -> torch.Tensor:
    """Point-MSE ablation (Table 5 "Point MSE"): MSE on normalised coordinates.

    If `pred_heat_or_coords` is 4-D it is treated as heatmaps and decoded with
    the differentiable soft-argmax (needs stride/input_size); if 3-D (B,K,2) it
    is taken as already-normalised coordinates (direct-regression head).
    gt_norm: (B,K,2) normalised [0,1] coords.
    """
    if pred_heat_or_coords.dim() == 4:
        assert stride is not None and input_size is not None
        xy = heatmap_coords_to_normalized(soft_argmax(pred_heat_or_coords, beta), stride, input_size)
    else:
        xy = pred_heat_or_coords
    m = vis.to(xy.dtype).unsqueeze(-1)
    se = m * (xy - gt_norm) ** 2
    denom = (m.sum() * 2).clamp_min(1.0)
    return se.sum() / denom
