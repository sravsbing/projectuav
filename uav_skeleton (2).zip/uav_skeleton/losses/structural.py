"""Structural Geometric Loss (paper Eq. 3-5) and the combined objective (Eq. 1).

    V_bh  = P_head  - P_body        V_bt  = P_tail  - P_body
    V_bwL = P_lwing - P_body        V_bwR = P_rwing - P_body
    L_sg  = max(0, V_bh . V_bt) + max(0, V_bwL . V_bwR)
    L_total = L_hm + lambda * L_sg          (lambda = 0.1)

Choices (documented):
  * P_tail = tail UNIT (paper Eq. 3 text), see data/keypoints.SGL_TAIL.
  * Points are the differentiable soft-argmax of the *predicted* heatmaps in
    normalised [0,1] image coordinates (A6). Hard argmax would give no gradient.
  * Each of the two terms is applied to a sample only if ALL three keypoints it
    involves are visible in the ground truth (A7); otherwise it is 0 for that
    sample. Sample losses are averaged over the batch size B (not over the
    number of active terms) so that missing labels never inflate the loss.
  * `normalize_vectors=False` is the paper-faithful raw dot product. With
    True, cosine similarity is used (scale-free); offered as a documented
    option, not the default.
  * A tail-only sign convention: a valid aircraft gives negative dot products,
    so the hinge max(0, .) is zero for anatomically plausible skeletons.
"""
from __future__ import annotations

import torch

from data.keypoints import HEAD, BODY, LEFT_WING, RIGHT_WING, SGL_TAIL


def structural_geometric_loss(coords: torch.Tensor, vis: torch.Tensor,
                              normalize_vectors: bool = False, eps: float = 1e-8) -> torch.Tensor:
    """coords: (B,K,2) differentiable normalised coords; vis: (B,K) bool/0-1."""
    v = vis.to(torch.bool)
    body = coords[:, BODY]
    v_bh = coords[:, HEAD] - body
    v_bt = coords[:, SGL_TAIL] - body
    v_bwl = coords[:, LEFT_WING] - body
    v_bwr = coords[:, RIGHT_WING] - body

    def dot(a, b):
        if normalize_vectors:
            a = a / (a.norm(dim=-1, keepdim=True) + eps)
            b = b / (b.norm(dim=-1, keepdim=True) + eps)
        return (a * b).sum(dim=-1)

    long_ok = v[:, HEAD] & v[:, BODY] & v[:, SGL_TAIL]
    trans_ok = v[:, LEFT_WING] & v[:, BODY] & v[:, RIGHT_WING]
    l_long = torch.clamp(dot(v_bh, v_bt), min=0.0) * long_ok.to(coords.dtype)
    l_trans = torch.clamp(dot(v_bwl, v_bwr), min=0.0) * trans_ok.to(coords.dtype)
    return (l_long + l_trans).mean()


def total_loss(l_hm: torch.Tensor, l_sg: torch.Tensor, sg_weight: float = 0.1) -> torch.Tensor:
    """Eq. 1. `sg_weight=0` reproduces the heatmap-MSE-only ablation / PG-VDNet."""
    return l_hm + sg_weight * l_sg
